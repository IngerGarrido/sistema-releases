// Utilidades de exportación CSV cliente-side.
// Excel abre CSV con BOM UTF-8 sin problemas de acentos.
//
// Uso:
//   exportCSV('cobros_pendientes_2026-05-16.csv',
//     ['Cliente','Proyecto','Monto','Días'],
//     rows.map(r => [r.cliente, r.proyecto, r.monto, r.dias])
//   )

function escapeCell(v) {
  if (v === null || v === undefined) return ''
  const s = String(v)
  // Escapamos comillas duplicándolas y envolvemos si tiene coma/quote/salto
  if (/[",\n;]/.test(s)) return '"' + s.replace(/"/g, '""') + '"'
  return s
}

export function buildCSV(headers, rows, sep = ';') {
  // ';' como separador es más amigable para Excel ES-LA que ','
  const lines = []
  if (headers && headers.length) lines.push(headers.map(escapeCell).join(sep))
  for (const r of rows) lines.push(r.map(escapeCell).join(sep))
  return lines.join('\r\n')
}

export function exportCSV(filename, headers, rows) {
  const csv = buildCSV(headers, rows)
  // BOM para que Excel detecte UTF-8 (acentos correctos)
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
  const url  = URL.createObjectURL(blob)
  const a    = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

export function hoy() {
  return new Date().toISOString().split('T')[0]
}
