import { useState, useEffect } from 'react'
import { api } from '../assets/js/api.js'
import { I } from '../assets/js/helpers.js'
import { Ic, Toast, useToast } from './UI.jsx'

export default function ActualizacionesPanel() {
  const [info, setInfo] = useState(null)
  const [loading, setLoading] = useState(false)
  const [running, setRunning] = useState(false)
  const [logs, setLogs] = useState([])
  const [showDetails, setShowDetails] = useState(false)
  const [tokenInput, setTokenInput] = useState('')
  const [savingToken, setSavingToken] = useState(false)
  const [toast, showToast] = useToast()

  const guardarToken = async () => {
    const t = tokenInput.trim()
    if (!t) { showToast('Ingresa un token', 'err'); return }
    setSavingToken(true)
    try {
      await api.guardarTokenGitHub(t)
      setTokenInput('')
      showToast('Token guardado')
      await cargar()
    } catch (e) {
      showToast(e.message || 'No se pudo guardar el token', 'err')
    } finally { setSavingToken(false) }
  }

  const cargar = async () => {
    setLoading(true)
    try { setInfo(await api.getActualizaciones()) }
    catch (e) { showToast(e.message, 'err') }
    finally   { setLoading(false) }
  }

  useEffect(() => { cargar() }, [])

  const ejecutar = async () => {
    if (!info?.behind && !info?.migraciones?.por_aplicar) return
    const msg = info.behind > 0
      ? `Se descargará la última versión y se aplicarán los cambios necesarios.\n\n⚠️ Antes de continuar, te recomendamos haber hecho un respaldo (backup) reciente de tu base de datos.\n\n¿Continuar con la actualización?`
      : `Se aplicarán ${info.migraciones.por_aplicar} cambio(s) pendientes a la base de datos.\n\n¿Continuar?`
    if (!confirm(msg)) return

    setRunning(true); setLogs([])
    try {
      const r = await api.ejecutarActualizacion()
      setLogs(r.logs || [])
      setInfo(r.status)
      showToast('Sistema actualizado correctamente')
    } catch (e) {
      if (e.message) showToast(e.message, 'err')
      cargar()
    } finally { setRunning(false) }
  }

  if (loading || !info) {
    return <div style={{ padding: 12, color: 'var(--txt2)', fontFamily: 'var(--font)', fontSize: 13 }}>Consultando estado del sistema…</div>
  }

  // No es git: actualización manual
  if (!info.es_git) {
    return (
      <div className="upd-panel">
        <UpdState
          status="manual"
          title="Actualización manual"
          desc="Este servidor no admite actualización automática. Cuando salga una versión nueva, sube los archivos por FTP/cPanel y luego corre las migraciones pendientes desde el panel de abajo."
        />
      </div>
    )
  }

  if (info.git_disponible === false) {
    const motivo = info.falta_zip || info.falta_curl
      ? `El servidor no tiene las extensiones PHP necesarias${info.falta_zip ? ' (zip)' : ''}${info.falta_curl ? ' (curl)' : ''}. Pide a tu proveedor de hosting que las habilite, o actualiza por FTP.`
      : 'Hay un problema en el servidor que impide actualizar automáticamente. Contacta a soporte o actualiza por FTP.'
    return (
      <div className="upd-panel">
        {toast && <Toast {...toast} />}
        <UpdState status="warn" title="Actualización automática no disponible" desc={motivo} />
      </div>
    )
  }

  // Falta el token de GitHub: pedirlo
  if (info.tiene_token === false) {
    return (
      <div className="upd-panel" style={{ fontFamily: 'var(--font)' }}>
        {toast && <Toast {...toast} />}
        <UpdState
          status="info"
          title="Configura el acceso a actualizaciones"
          desc="Para descargar las actualizaciones desde el repositorio privado se necesita un Personal Access Token de GitHub con permiso de lectura sobre el repositorio. Pídelo al equipo de desarrollo y pégalo aquí. Se guarda cifrado en el servidor y no se muestra de vuelta."
        />
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
          <input
            type="password"
            placeholder="ghp_..."
            value={tokenInput}
            onChange={e => setTokenInput(e.target.value)}
            disabled={savingToken}
            style={{
              flex: 1, minWidth: 240, padding: '8px 10px', borderRadius: 6,
              border: '1px solid var(--card-b)', fontFamily: 'var(--mono, monospace)', fontSize: 13
            }}
          />
          <button className="btn-pri" onClick={guardarToken} disabled={savingToken || !tokenInput.trim()}>
            {savingToken ? <><Ic d={I.loader} size={14}/> Guardando…</> : <>Guardar token</>}
          </button>
        </div>
        <div style={{ fontSize: 12, color: 'var(--txt2)', marginTop: 10 }}>
          Repositorio configurado: <code style={{ fontFamily: 'var(--mono, monospace)' }}>{info.repo}</code> · rama <code style={{ fontFamily: 'var(--mono, monospace)' }}>{info.branch}</code>
        </div>
      </div>
    )
  }

  const hayActualizacion = info.behind > 0
  const hayMigracionesPendientes = (info.migraciones?.por_aplicar || 0) > 0
  const dirty = info.dirty
  const puedeActualizar = (hayActualizacion || hayMigracionesPendientes) && !dirty && info.tiene_remoto

  return (
    <div className="upd-panel" style={{ fontFamily: 'var(--font)' }}>
      {toast && <Toast {...toast} />}

      {/* Estado principal */}
      {dirty ? (
        <UpdState
          status="warn"
          title="Cambios locales detectados"
          desc="Hay archivos modificados directamente en el servidor que bloquean la actualización. Contacta a soporte para resolverlos."
        />
      ) : hayActualizacion ? (
        <UpdState
          status="info"
          title={`Hay ${info.behind === 1 ? 'una actualización disponible' : `${info.behind} actualizaciones disponibles`}`}
          desc="Antes de actualizar te recomendamos haber hecho un respaldo de tu base de datos. La actualización descarga los archivos nuevos y aplica los cambios necesarios automáticamente."
        />
      ) : hayMigracionesPendientes ? (
        <UpdState
          status="info"
          title={`Hay ${info.migraciones.por_aplicar} cambio(s) pendientes en la base de datos`}
          desc="Tu código está al día pero falta aplicar algunos cambios al esquema de la base. Es seguro hacerlo."
        />
      ) : (
        <UpdState
          status="ok"
          title="Tu sistema está al día"
          desc={info.commit_fecha ? `Última actualización: ${fechaCorta(info.commit_fecha)}` : null}
        />
      )}

      {/* Acciones */}
      <div className="upd-actions">
        {puedeActualizar && (
          <button className="btn-pri" onClick={ejecutar} disabled={running}>
            {running
              ? <><Ic d={I.loader} size={14}/> Actualizando…</>
              : <><Ic d={I.refresh} size={14}/> Actualizar ahora</>}
          </button>
        )}
        <button className="btn-sec" onClick={cargar} disabled={running}>
          <Ic d={I.refresh} size={13}/> Revisar de nuevo
        </button>
        <button className="upd-link" onClick={() => setShowDetails(s => !s)}>
          {showDetails ? 'Ocultar detalles técnicos' : 'Ver detalles técnicos'}
        </button>
      </div>

      {/* Detalles técnicos (colapsables) */}
      {showDetails && (
        <div className="upd-tech">
          <Row k="Rama" v={info.branch} />
          <Row k="Versión instalada" v={info.commit_corto} mono />
          {info.commit_msg && <Row k="Último cambio" v={info.commit_msg} />}
          <Row k="Origen" v={info.upstream || '—'} mono />
          {info.archivos_modificados?.length > 0 && (
            <Row k="Archivos modificados" v={
              <ul style={{ margin: 0, paddingLeft: 16 }}>
                {info.archivos_modificados.slice(0, 8).map((f,i)=>(<li key={i} style={{ fontFamily: 'var(--mono, monospace)', fontSize: 12 }}>{f}</li>))}
                {info.archivos_modificados.length > 8 && <li>… y {info.archivos_modificados.length - 8} más</li>}
              </ul>
            } />
          )}
        </div>
      )}

      {/* Logs (solo si hubo ejecución) */}
      {logs.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <div style={{ fontSize: 12, color: 'var(--txt2)', marginBottom: 4 }}>Log de la actualización:</div>
          <pre style={{
            margin: 0, padding: 10, background: '#0f172a', color: '#cbd5e1',
            borderRadius: 6, fontSize: 12, maxHeight: 220, overflow: 'auto',
            fontFamily: 'var(--mono, ui-monospace, SFMono-Regular, monospace)'
          }}>{logs.join('\n')}</pre>
        </div>
      )}
    </div>
  )
}

// ─── Subcomponentes ─────────────────────────────────────────
function UpdState({ status, title, desc }) {
  const styles = {
    ok:     { bg: '#e6fcf5', bd: '#69db7c', ico: I.check, color: '#16a34a' },
    info:   { bg: '#e7f5ff', bd: '#74c0fc', ico: I.refresh, color: '#1971c2' },
    warn:   { bg: '#fff7e6', bd: '#fab005', ico: I.warn, color: '#b8860b' },
    manual: { bg: 'var(--card)', bd: 'var(--card-b)', ico: I.warn, color: 'var(--txt2)' },
  }[status] || {}
  return (
    <div style={{
      display: 'flex', gap: 14, alignItems: 'flex-start',
      padding: '14px 16px', borderRadius: 10,
      background: styles.bg, border: '1px solid ' + styles.bd,
      marginBottom: 14, fontFamily: 'var(--font)'
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: '50%', flexShrink: 0,
        background: '#fff', color: styles.color,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center'
      }}>
        <Ic d={styles.ico} size={16}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--txt)' }}>{title}</div>
        {desc && <div style={{ fontSize: 13, color: 'var(--txt2)', marginTop: 4, lineHeight: 1.5 }}>{desc}</div>}
      </div>
    </div>
  )
}

function Row({ k, v, mono }) {
  return (
    <div style={{ display: 'flex', gap: 10, padding: '6px 0', fontSize: 13, borderBottom: '1px dashed var(--card-b)' }}>
      <div style={{ width: 160, color: 'var(--txt2)', flexShrink: 0 }}>{k}</div>
      <div style={{ flex: 1, fontFamily: mono ? 'var(--mono, monospace)' : 'var(--font)', wordBreak: 'break-word' }}>{v}</div>
    </div>
  )
}

function fechaCorta(iso) {
  if (!iso) return null
  try {
    return new Date(iso).toLocaleString('es-CL', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
  } catch { return iso }
}
