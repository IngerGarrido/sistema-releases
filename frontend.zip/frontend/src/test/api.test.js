import { describe, it, expect } from 'vitest'
import { api } from '../assets/js/api.js'

describe('api module', () => {
  it('exports an object', () => {
    expect(api).toBeDefined()
    expect(typeof api).toBe('object')
  })

  it('exposes expected functions', () => {
    const expected = ['login', 'getClientes', 'dashboard', 'getConfig']
    for (const name of expected) {
      expect(typeof api[name]).toBe('function')
    }
  })
})
