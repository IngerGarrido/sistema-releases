import React from 'react'

/* ── EmptyState (Sprint 5) ──
   Estado vacío con icono SVG, título, descripción y CTA opcional.
   Si recibe `text` (string), lo usa como título (compatibilidad legacy). */
export function EmptyState({ icon, title, text, desc, description, cta, ctaLabel, onCta }) {
  const t = title || text || 'Sin registros'
  const d = desc || description
  const defaultIcon = (
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/>
      <line x1="3" y1="11" x2="21" y2="11"/>
    </svg>
  )
  return (
    <div className="empty-state" role="status">
      <div className="empty-state__icon" aria-hidden="true">{icon || defaultIcon}</div>
      <h4 className="empty-state__title">{t}</h4>
      {d && <p className="empty-state__desc">{d}</p>}
      {(cta || ctaLabel) && onCta && (
        <button type="button" className="btn btn-primary" onClick={onCta}>
          {cta || ctaLabel}
        </button>
      )}
    </div>
  )
}
