/**
 * Comprime una imagen client-side antes de subirla.
 *
 * - Re-encode con canvas a JPEG o PNG (si tiene transparencia).
 * - Reescala manteniendo proporción si supera `maxDim` en cualquier eje.
 * - Si el archivo original ya es chico (< minBytes) o no es imagen, lo devuelve tal cual.
 *
 * Devuelve un nuevo File (mantiene `name` y agrega `_compressed` al stem si
 * cambió el formato). Si algo falla, devuelve el original.
 */
export async function compressImage(file, { maxDim = 1200, quality = 0.82, minBytes = 200 * 1024 } = {}) {
  try {
    if (!file || !file.type || !file.type.startsWith('image/')) return file
    // SVG no se comprime con canvas, dejarlo pasar
    if (file.type === 'image/svg+xml') return file
    if (file.size < minBytes) return file

    const bitmap = await loadBitmap(file)
    const { width, height } = scaleDims(bitmap.width, bitmap.height, maxDim)

    const canvas = document.createElement('canvas')
    canvas.width = width
    canvas.height = height
    const ctx = canvas.getContext('2d')
    // Fondo blanco si el target es JPEG (evita negro en transparencia)
    const targetType = (file.type === 'image/png' || file.type === 'image/webp') ? file.type : 'image/jpeg'
    if (targetType === 'image/jpeg') {
      ctx.fillStyle = '#ffffff'
      ctx.fillRect(0, 0, width, height)
    }
    ctx.drawImage(bitmap, 0, 0, width, height)
    if (bitmap.close) bitmap.close()

    const blob = await new Promise(res => canvas.toBlob(res, targetType, quality))
    if (!blob || blob.size >= file.size) return file // si no ahorramos, devolver original

    const name = renameForType(file.name, targetType)
    return new File([blob], name, { type: targetType, lastModified: Date.now() })
  } catch {
    return file
  }
}

async function loadBitmap(file) {
  if (typeof createImageBitmap === 'function') {
    try { return await createImageBitmap(file) } catch { /* fallback */ }
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file)
    const img = new Image()
    img.onload = () => { URL.revokeObjectURL(url); resolve(img) }
    img.onerror = (e) => { URL.revokeObjectURL(url); reject(e) }
    img.src = url
  })
}

function scaleDims(w, h, maxDim) {
  if (w <= maxDim && h <= maxDim) return { width: w, height: h }
  const ratio = w > h ? maxDim / w : maxDim / h
  return { width: Math.round(w * ratio), height: Math.round(h * ratio) }
}

function renameForType(name, type) {
  const ext = type === 'image/png' ? '.png' : type === 'image/webp' ? '.webp' : '.jpg'
  return name.replace(/\.[^.]+$/, '') + ext
}
