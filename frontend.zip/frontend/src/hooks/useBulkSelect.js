import { useState, useEffect } from 'react'

export function useBulkSelect(items = [], resetDep = null) {
  const [seleccionados, setSeleccionados] = useState(new Set())

  useEffect(() => { setSeleccionados(new Set()) }, [resetDep])

  const toggle = (id) => {
    setSeleccionados(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }

  const toggleAll = () => {
    setSeleccionados(prev =>
      prev.size === items.length ? new Set() : new Set(items.map(i => i.id))
    )
  }

  const clear = () => setSeleccionados(new Set())
  const allSelected = items.length > 0 && seleccionados.size === items.length
  const count = seleccionados.size

  return { seleccionados, toggle, toggleAll, clear, allSelected, count, ids: Array.from(seleccionados) }
}
