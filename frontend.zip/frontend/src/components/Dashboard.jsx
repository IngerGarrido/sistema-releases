import { useState, useEffect, useRef, lazy, Suspense } from 'react'
import { api }               from '../assets/js/api.js'
import { clp, fecha, I }     from '../assets/js/helpers.js'
import { Badge, StatCard, Ic, Skeleton, Modal } from './UI.jsx'
import { useDashboard, useConfiguracion } from '../hooks/useQueryApi.js'

// Lazy-load de gráficos (recharts ~300KB). Reduce el bundle inicial del Dashboard.
const GraficoIngresos = lazy(() => import('./GraficosDashboard.jsx').then(m => ({ default: m.GraficoIngresos })))
const GraficoProyectosEstado = lazy(() => import('./GraficosDashboard.jsx').then(m => ({ default: m.GraficoProyectosEstado })))
const GraficoTiposPago = lazy(() => import('./GraficosDashboard.jsx').then(m => ({ default: m.GraficoTiposPago })))
const ChartFallback = () => <div className="card" style={{ padding: 16, minHeight: 200 }}><Skeleton className="skeleton-row" /></div>

// Definición de cards disponibles en el panel
const DASH_CARDS = [
  { id: 'ingreso',       label: 'Ingreso en Cuenta' },
  { id: 'directos',      label: 'Pagos Directos' },
  { id: 'meta',          label: 'Meta Mensual' },
  { id: 'cot_pend',      label: 'Cotizaciones Pendientes' },
  { id: 'proy_curso',    label: 'Proyectos en curso' },
  { id: 'por_cobrar',    label: 'Por cobrar' },
  { id: 'vencimientos',  label: 'Próximos Vencimientos' },
  { id: 'proy_rec',      label: 'Proyectos Recientes' },
  { id: 'eficiencia',    label: 'Eficiencia de Recaudación' },
  { id: 'g_ingresos',    label: 'Gráfico: Ingresos' },
  { id: 'g_tipos',       label: 'Gráfico: Tipos de Pago' },
  { id: 'g_estados',     label: 'Gráfico: Estado Proyectos' },
]

// Cards ocultas por defecto (info ya cubierta en Reportes o de bajo uso).
// Siguen disponibles desde el botón "Personalizar".
const HIDDEN_BY_DEFAULT = new Set(['g_ingresos', 'g_tipos', 'vencimientos'])

const DEFAULT_VISIBLE = DASH_CARDS.reduce(
  (acc, c) => ({ ...acc, [c.id]: !HIDDEN_BY_DEFAULT.has(c.id) }),
  {}
)

// Bump de versión: forzamos defaults nuevos una sola vez para que el dashboard
// quede "limpio" después de introducir Reportes. El usuario puede re-personalizar.
const CARDS_STORAGE_KEY = '_dashboard_cards_v2'

function loadVisibleCards() {
  try {
    const raw = localStorage.getItem(CARDS_STORAGE_KEY)
    if (!raw) {
      // Limpiar versión antigua si existía, para no acumular basura
      try { localStorage.removeItem('_dashboard_cards') } catch {}
      return DEFAULT_VISIBLE
    }
    const parsed = JSON.parse(raw)
    return { ...DEFAULT_VISIBLE, ...parsed }
  } catch {
    return DEFAULT_VISIBLE
  }
}

export default function Dashboard() {
  const [periodo, setPeriodo] = useState('mes_actual')
  const [quickOpen, setQuickOpen] = useState(false)
  const quickRef = useRef(null)
  const { data: d, isLoading: loading, error, refetch } = useDashboard(periodo)
  
  // --- 1. CONFIGURACIÓN (vía React Query, sin duplicar fetch) ---
  const { data: configRes } = useConfiguracion()
  const config = { meta_mensual: 500000, retencion_honorarios: 15.25, ...(configRes || {}) }

  // --- Cards visibles (persistido en localStorage) ---
  const [visibleCards, setVisibleCards] = useState(loadVisibleCards)
  const [showPersonalizar, setShowPersonalizar] = useState(false)
  const isVisible = (id) => visibleCards[id] !== false
  const toggleCard = (id) => setVisibleCards(prev => {
    const next = { ...prev, [id]: !isVisible(id) }
    try { localStorage.setItem(CARDS_STORAGE_KEY, JSON.stringify(next)) } catch {}
    return next
  })

  useEffect(() => {
    if (!quickOpen) return
    const onPointerDown = (e) => {
      if (quickRef.current && !quickRef.current.contains(e.target)) setQuickOpen(false)
    }
    const onKeyDown = (e) => {
      if (e.key === 'Escape') setQuickOpen(false)
    }
    window.addEventListener('pointerdown', onPointerDown)
    window.addEventListener('keydown', onKeyDown)
    return () => {
      window.removeEventListener('pointerdown', onPointerDown)
      window.removeEventListener('keydown', onKeyDown)
    }
  }, [quickOpen])

  // Verificar pagos vencidos y backup al cargar (con debounce 500ms para
  // evitar race condition cuando d/loading cambian rápidamente)
  useEffect(() => {
    if (loading || !d) return

    const timeout = setTimeout(() => {
      try {
        // 1. Verificar pagos vencidos (cuotas pendientes con fecha pasada)
        const hoy = new Date().toISOString().split('T')[0]
        const vencidos = (d.proximas_boletas || []).filter(b => b.boleta_fecha < hoy)
        if (vencidos.length > 0) {
          window.dispatchEvent(new CustomEvent('nueva-notificacion', {
            detail: {
              mensaje: `⚠️ ${vencidos.length} pago${vencidos.length > 1 ? 's' : ''} vencido${vencidos.length > 1 ? 's' : ''}`,
              tipo: 'warning'
            }
          }))
        }

        // 2. Verificar backup semanal
        const lastBackup = localStorage.getItem('_last_backup_reminder')
        const ahora = Date.now()
        const unaSemana = 7 * 24 * 60 * 60 * 1000

        if (!lastBackup || (ahora - parseInt(lastBackup)) > unaSemana) {
          window.dispatchEvent(new CustomEvent('nueva-notificacion', {
            detail: {
              mensaje: '💾 Recuerda: Haz backup de la base de datos semanalmente',
              tipo: 'info'
            }
          }))
          localStorage.setItem('_last_backup_reminder', ahora.toString())
        }
      } catch (e) {
        console.error('Error en notificaciones:', e)
      }
    }, 500)

    return () => clearTimeout(timeout)
  }, [d, loading])

  if (loading) return (
    <div className="card" style={{padding:'16px'}}>
      <div style={{marginBottom:'16px'}}>
        <Skeleton className="skeleton-title" />
      </div>
      <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'11px', marginBottom:'16px'}}>
        {[...Array(3)].map((_,i)=>(
          <Skeleton key={i} style={{height:'100px'}} />
        ))}
      </div>
      <Skeleton style={{height:'200px'}} />
    </div>
  )
  
  if (error || !d) return (
    <div className="tbl-loading" style={{textAlign: 'center', padding: 40}}>
      <p style={{color: 'var(--err)', marginBottom: 12}}>❌ Error al cargar datos</p>
      {error && <p style={{fontSize: 12, color: 'var(--txt3)', marginBottom: 20}}>{error.message}</p>}
      <button onClick={refetch} className="btn btn-primary">🔄 Reintentar</button>
    </div>
  )

  // --- 3. VARIABLES DINÁMICAS (Aquí está la magia) ---
  const META = Number(config.meta_mensual) || 500000
  const PCT_IMPUESTO = Number(config.retencion_honorarios) || 15.25
  const FACTOR_LIQUIDO = 1 - (PCT_IMPUESTO / 100)

  const totalCobrado   = Number(d?.total_cobrado  || 0)
  const totalPendiente = Number(d?.total_pendiente || 0)
  const boletas        = d?.boletas_pagadas || []
  const soloBol        = boletas.filter(b => b.tipo_pago !== 'directo')
  const montoSoloBol   = soloBol.reduce((a, b) => a + Number(b.pago_monto || 0), 0)
  const montoDirecto   = boletas.filter(b => b.tipo_pago === 'directo').reduce((a, b) => a + Number(b.pago_monto || 0), 0)
  
  // La retención ahora se calcula con el porcentaje dinámico de la BD
  const retencion      = montoSoloBol > 0 ? Math.round((montoSoloBol / FACTOR_LIQUIDO) - montoSoloBol) : 0
  const pctMeta        = Math.min(100, Math.round((totalCobrado / META) * 100))
  const faltante       = Math.max(0, META - totalCobrado)

  const promedio = () => {
    const r = soloBol.filter(b => b.boleta_fecha && b.pago_fecha && b.boleta_fecha !== '0000-00-00')
    if (!r.length) return 0
    const s = r.reduce((a, b) => { 
      const fB = new Date(b.boleta_fecha), fP = new Date(b.pago_fecha)
      return fP >= fB ? a + (fP - fB) / 86400000 : a 
    }, 0)
    return Math.round(s / r.length)
  }

  const quickNav = (panel) => {
    setQuickOpen(false)
    window.dispatchEvent(new CustomEvent('navegar', { detail: { panel } }))
  }

  return (
    <div>
      {/* Cabecera */}
      <div className="dash-hdr">
        <div>
          <div className="dash-title">Panel General</div>
          <div className="dash-date">{new Date().toLocaleDateString('es-CL', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>
          <select className="dash-periodo" value={periodo} onChange={e => setPeriodo(e.target.value)}>
            <option value="mes_actual">Este Mes</option>
            <option value="mes_pasado">Mes Pasado</option>
            <option value="anio">Este Año</option>
            <option value="todos">Todo el historial</option>
          </select>
        </div>
        <div style={{display:'flex', alignItems:'center', gap:10, flexWrap:'wrap', justifyContent:'flex-end'}}>
          <button type="button" className="btn btn-ghost" onClick={()=>setShowPersonalizar(true)} title="Personalizar panel">
            <Ic d={I.settings} size={14}/> Personalizar
          </button>
          <div className="dash-quick" ref={quickRef}>
            <button type="button" className="dash-quick-btn" onClick={()=>setQuickOpen(v=>!v)}>
              + Nuevo
            </button>
            {quickOpen&&(
              <div className="dash-quick-menu">
                <button type="button" onClick={()=>quickNav('clientes')}><Ic d={I.users} size={14}/> Cliente</button>
                <button type="button" onClick={()=>quickNav('cotizaciones')}><Ic d={I.pdf} size={14}/> Cotización</button>
                <button type="button" onClick={()=>quickNav('proyectos')}><Ic d={I.projects} size={14}/> Proyecto</button>
                <button type="button" onClick={()=>quickNav('pagos')}><Ic d={I.pay} size={14}/> Pago</button>
              </div>
            )}
          </div>
          <div className="sii-pill">
            {/* Mostramos el porcentaje real de la configuración */}
            <span className="sii-lbl">Impuesto SII ({PCT_IMPUESTO}%)</span>
            <span className="sii-val">{clp(retencion)}</span>
          </div>
        </div>
      </div>

      {/* Fila 1: Finanzas */}
      <div className="g-213">
        {isVisible('ingreso') && <StatCard label="Ingreso en Cuenta" value={clp(totalCobrado)} icon={I.download} color="var(--acc3)" sub="Líquido total recibido"/>}
        {isVisible('directos') && <StatCard label="Pagos Directos"    value={clp(montoDirecto)} icon={I.arrowRight}  color="var(--accent)" sub="Sin boleta"/>}
        {isVisible('meta') && <div className="meta-card">
          <div className="meta-top">
            <span className="meta-lbl">Meta Mensual</span>
            <span className="meta-pct">{pctMeta}%</span>
          </div>
          <div className="progress"><div className="progress-fill" style={{ width: `${pctMeta}%` }}/></div>
          <div className="meta-nums">
            <span className="meta-big">{clp(totalCobrado)}</span>
            <span className="meta-of">/ {clp(META)}</span>
          </div>
          <div className="meta-hint">{faltante > 0 ? `Faltan ${clp(faltante)} para el objetivo` : '¡Meta alcanzada! 🚀'}</div>
        </div>}
      </div>

      {/* Estadísticas principales */}
      <div className="g-3">
        {isVisible('cot_pend')   && <StatCard label="Cotizaciones Pendientes"   value={d?.total_cotizaciones   || 0} icon={I.quotes}  color="var(--accent)" sub="Registradas"/>}
        {isVisible('proy_curso') && <StatCard label="Proyectos en curso"   value={d?.proyectos_activos || 0} icon={I.projects} color="var(--acc3)"   sub="Activos"/>}
        {isVisible('por_cobrar') && <StatCard label="Por cobrar" value={clp(totalPendiente)}      icon={I.pay}      color="var(--acc2)"   sub="Pendiente"/>}
      </div>

      {/* (Se mantiene el resto del código que ya tenías) */}
      {isVisible('vencimientos') && <div className="card" style={{ padding: '16px', marginBottom: 13 }}>
        <div className="venc-title"><span className="venc-amber">●</span>Próximos Vencimientos</div>
        <div className="venc-wrap">
          {(!d?.proyectos_por_vencer?.length)
            ? <div className="venc-empty">No hay vencimientos pendientes</div>
            : d.proyectos_por_vencer.map((v, i) => (
              <div key={i} className="venc-chip">
                <div className="venc-name">{v.nombre}</div>
                <div className="venc-cli">{v.cliente_nombre}</div>
                <div className="venc-footer">
                  <Badge s={v.estado}/>
                  <span className={`venc-dias${v.dias_restantes > 7 ? ' venc-dias-ok' : ''}`}>{v.dias_restantes} días</span>
                </div>
              </div>
            ))
          }
        </div>
      </div>}

      <div className="g-213b">
        {isVisible('proy_rec') && <div className="card">
          <div className="panel-hdr"><div className="panel-title">Proyectos Recientes</div></div>
          {!d?.proyectos_recientes?.length
            ? <p className="tbl-empty">Sin actividad</p>
            : d.proyectos_recientes.slice(0, 4).map(p => (
              <div key={p.id} className="panel-row">
                <div className="panel-name">{p.nombre}</div>
                <Badge s={p.estado}/>
              </div>
            ))
          }
        </div>}

        {isVisible('eficiencia') && <div className="card">
          <div className="ef-box">
            <div className="ef-num">
              <span className="ef-big">{promedio()}</span>
              <span className="ef-lbl">DÍAS</span>
            </div>
            <div>
              <div className="panel-title" style={{ marginBottom: 6 }}>Eficiencia de Recaudación</div>
              <div className="ef-text">Tiempo promedio desde emisión de boleta hasta pago efectivo.</div>
              <div className="ef-status" style={{ color: promedio() === 0 ? 'var(--txt2)' : promedio() <= 7 ? 'var(--acc3)' : promedio() <= 30 ? 'var(--acc2)' : 'var(--err)' }}>
                <span>●</span>
                {promedio() === 0 ? 'Sin datos aún' : promedio() <= 7 ? 'Excelente ritmo' : promedio() <= 30 ? 'Ritmo normal' : 'Cobro lento'}
              </div>
            </div>
          </div>
        </div>}
      </div>

      {/* GRÁFICOS - Al final del Dashboard (lazy-loaded para reducir bundle inicial) */}
      <div className="graficos-grid">
        <Suspense fallback={<ChartFallback />}>
          {isVisible('g_ingresos') && <GraficoIngresos datos={d?.ingresos_mensuales || []} />}
          {isVisible('g_tipos')    && <GraficoTiposPago boletas={montoSoloBol} directos={montoDirecto} />}
          {isVisible('g_estados')  && <GraficoProyectosEstado datos={d?.proyectos_por_estado || []} />}
        </Suspense>
      </div>

      {/* Acceso a Reportes detallados */}
      <div
        className="card"
        style={{
          padding: 14,
          marginTop: 13,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 12,
          flexWrap: 'wrap'
        }}
      >
        <div>
          <div style={{ fontWeight: 600, marginBottom: 2 }}>¿Quieres ver el detalle?</div>
          <div style={{ fontSize: 13, color: 'var(--txt2)' }}>
            Ingresos 12 meses, cobros pendientes con aging y cotizaciones por estado.
          </div>
        </div>
        <button
          className="btn btn-primary"
          type="button"
          onClick={() => window.dispatchEvent(new CustomEvent('navegar', { detail: { panel: 'reportes' } }))}
        >
          <Ic d={I.barChart} size={14}/> Ver Reportes
        </button>
      </div>

      {showPersonalizar && (
        <Modal title="Personalizar panel" onClose={() => setShowPersonalizar(false)}>
          <p style={{ fontSize: 13, color: 'var(--txt2)', marginBottom: 14 }}>
            Selecciona qué tarjetas quieres mostrar en el panel.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {DASH_CARDS.map(c => (
              <label key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 4px', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={isVisible(c.id)}
                  onChange={() => toggleCard(c.id)}
                />
                <span style={{ fontSize: 13 }}>{c.label}</span>
              </label>
            ))}
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
            <button className="btn btn-primary" onClick={() => setShowPersonalizar(false)}>Listo</button>
          </div>
        </Modal>
      )}
    </div>
  )
}