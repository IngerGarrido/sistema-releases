import { useState, useEffect } from 'react'
import { useLocalState, useSort } from '../hooks/useLocalState.js'
import { useUnsavedWarning } from '../hooks/useUnsavedWarning.js'
import { useBulkSelect } from '../hooks/useBulkSelect.js'
import { useDebouncedValue } from '../hooks/useDebouncedValue.js'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { api } from '../assets/js/api.js'
import { clp, fecha } from '../assets/js/helpers.js'
import { Badge, DataPanel, Acciones, Modal, Confirm, Toast, Field, InpCLP, BotonesGuardar, SelCliente, useToast, Skeleton } from './UI.jsx'
import { useProyectos, useCrearProyecto, useEditarProyecto, useBorrarProyecto, useSitios, useCrearSitio } from '../hooks/useQueryApi.js'
import { proyectoSchema } from '../schemas/validation.js'

// --- 1. FORMULARIO AISLADO (Control de foco y autocompletado) ---
const FormularioInterno = ({ editando, clientes, servicios, onSave, onCancel, isPending }) => {
  const { register, handleSubmit, formState: { errors, isDirty }, watch, setValue } = useForm({
    resolver: zodResolver(proyectoSchema),
    defaultValues: editando || {
      cliente_id: '',
      sitio_id: '',
      nombre: '',
      descripcion: '',
      estado: 'En curso',
      fecha_inicio: '',
      fecha_termino: '',
      presupuesto: 0,
      notas: ''
    }
  })

  

  const servicioIdWatch = watch('servicio_id')
  const clienteIdWatch  = watch('cliente_id')
  useUnsavedWarning(isDirty)

  // Sitios filtrados por cliente seleccionado
  const { data: sitiosCliente = [] } = useSitios(
    { cliente_id: clienteIdWatch },
    { enabled: !!clienteIdWatch }
  )
  const crearSitioMut = useCrearSitio()
  const [creandoSitio, setCreandoSitio] = useState(false)
  const [nuevoSitioNombre, setNuevoSitioNombre] = useState('')

  const crearSitioInline = async () => {
    const nombre = nuevoSitioNombre.trim()
    if (!nombre || !clienteIdWatch) return
    try {
      const r = await crearSitioMut.mutateAsync({ cliente_id: clienteIdWatch, nombre })
      // setValue espera string para selects
      setValue('sitio_id', String(r.id), { shouldDirty: true })
      setCreandoSitio(false); setNuevoSitioNombre('')
    } catch (e) { alert(e.message) }
  }

  useEffect(() => {
    if (servicioIdWatch) {
      const svc = (servicios || []).find(s => String(s.id) === String(servicioIdWatch))
      if (svc) {
        setValue('tipo_proyecto', svc.nombre)
        setValue('presupuesto', svc.precio)
      }
    }
  }, [servicioIdWatch, servicios, setValue])

  return (
    <form onSubmit={handleSubmit(onSave)} style={{ padding: '4px' }}>
      <div className="form-row">
        <Field label="Nombre del proyecto" required>
          <input className="inp" {...register('nombre')} />
          {errors.nombre && <span className="field-err">{errors.nombre.message}</span>}
        </Field>
        <Field label="Cliente" required>
          <SelCliente clientes={clientes} value={watch('cliente_id')} onChange={v => { setValue('cliente_id', v); setValue('sitio_id', '') }} />
          {errors.cliente_id && <span className="field-err">{errors.cliente_id.message}</span>}
        </Field>
        <Field label="Sitio">
          {!creandoSitio ? (
            <div style={{ display: 'flex', gap: 6 }}>
              <select className="sel" {...register('sitio_id')} disabled={!clienteIdWatch} style={{ flex: 1 }}>
                <option value="">{clienteIdWatch ? '— Sin sitio asociado —' : '— Selecciona cliente primero —'}</option>
                {sitiosCliente.map(s => <option key={s.id} value={s.id}>{s.nombre}</option>)}
              </select>
              <button type="button" className="btn-sec" onClick={()=>setCreandoSitio(true)} disabled={!clienteIdWatch} title="Crear nuevo sitio para este cliente">+ Nuevo</button>
            </div>
          ) : (
            <div style={{ display: 'flex', gap: 6 }}>
              <input className="inp" value={nuevoSitioNombre} onChange={e=>setNuevoSitioNombre(e.target.value)} placeholder="Nombre del sitio (ej: Marchant)" autoFocus style={{ flex: 1 }} />
              <button type="button" className="btn-pri" onClick={crearSitioInline} disabled={!nuevoSitioNombre.trim() || crearSitioMut.isPending}>Crear</button>
              <button type="button" className="btn-sec" onClick={()=>{ setCreandoSitio(false); setNuevoSitioNombre('') }}>Cancelar</button>
            </div>
          )}
          <small style={{ color: 'var(--txt2)' }}>El sitio agrupa proyectos repetidos del mismo cliente final y guarda los accesos (WP/FTP/etc).</small>
        </Field>
        <Field label="Servicio">
          <select className="sel" {...register('servicio_id')}>
            <option value="">— Seleccionar servicio —</option>
            {(servicios || []).filter(s => s.activo).map(s => <option key={s.id} value={s.id}>{s.nombre} — {clp(s.precio)}</option>)}
          </select>
        </Field>
        
        {/* Usamos half para que en desktop vayan de a dos, pero en móvil el CSS de form-row los apila */}
        <Field label="Tipo de proyecto" half>
          <input className="inp" {...register('tipo_proyecto')} placeholder="Ej: Ecommerce…" />
        </Field>
        <Field label="Estado" half>
          <select className="sel" {...register('estado')}>
            {['Cotizado', 'En curso', 'Terminado', 'Pausado', 'Cancelado'].map(s => <option key={s}>{s}</option>)}
          </select>
        </Field>
        <Field label="Presupuesto (CLP)" half>
          <InpCLP value={watch('presupuesto')} onChange={v => setValue('presupuesto', v)} />
          {errors.presupuesto && <span className="field-err">{errors.presupuesto.message}</span>}
        </Field>
        <Field label="Fecha inicio" half>
          <input className="inp" type="date" {...register('fecha_inicio')} />
          {errors.fecha_inicio && <span className="field-err">{errors.fecha_inicio.message}</span>}
        </Field>
        <Field label="Fecha término" half>
          <input className="inp" type="date" {...register('fecha_termino')} />
          {errors.fecha_termino && <span className="field-err">{errors.fecha_termino.message}</span>}
        </Field>
        <Field label="Descripción">
          <textarea className="tex" {...register('descripcion')} rows="3" />
        </Field>
      </div>
      <div style={{ marginTop: 20 }}>
        <BotonesGuardar onCancel={onCancel} isPending={isPending} />
      </div>
    </form>
  )
}

// --- 2. COMPONENTE PRINCIPAL ---
export default function Proyectos({ clientes, servicios }) {
  const [modal, setModal] = useState(false)
  const [editando, setEditando] = useState(null)
  const [del, setDel] = useState(null)
  const [delMultiple, setDelMultiple] = useState(false)
  const [toast, showToast] = useToast()

  const crearProyecto = useCrearProyecto()
  const editarProyecto = useEditarProyecto()
  const borrarProyecto = useBorrarProyecto()

  const [pagina, setPagina] = useState(1)
  const [perPage, setPerPage] = useLocalState('proyectos:perPage', 10)
  const [busqueda, setBusqueda] = useLocalState('proyectos:busqueda', '')

  // Búsqueda server-side con debounce (hook reutilizable)
  const qDebounced = useDebouncedValue(busqueda, 300)
  useEffect(() => { setPagina(1) }, [qDebounced])

  const { data: respuesta, isLoading: loading } = useProyectos({ page: pagina, per_page: perPage, q: qDebounced })
  const lista = Array.isArray(respuesta?.data) ? respuesta.data : []

  const abrir = (s) => {
    setEditando(s)
    setModal(true)
  }

  const guardar = async (data) => {
    try {
      if (data.id) await editarProyecto.mutateAsync({ id: data.id, data })
      else await crearProyecto.mutateAsync(data)
      setModal(false)
      showToast('Proyecto guardado')
    } catch (err) { showToast(err.message, 'err') }
  }

  // Búsqueda ahora es server-side (param q). Solo dejamos la lista tal cual viene.
  // NOTA: sort sigue client-side y por tanto ordena solo la página actual.
  const filtrados = (lista || [])

  const { sorted: filtradosOrdenados, sortKey, sortDir, toggle: sortToggle } = useSort(filtrados)

  const {
    seleccionados,
    toggle: toggleSeleccion,
    toggleAll: seleccionarTodos,
    clear: clearSeleccion,
  } = useBulkSelect(filtrados, busqueda)

  return (
    <div>
      {toast && <Toast {...toast} />}

      {loading && (
        <div className="card" style={{ padding: '16px' }}>
          <div style={{ marginBottom: '16px' }}><Skeleton className="skeleton-title" /></div>
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="skeleton-row" />)}
        </div>
      )}

      {!loading && (
        <>
          {filtrados.length > 0 && (
            <div className="bulk-actions-bar">
              <label>
                <input type="checkbox" checked={seleccionados.size === filtrados.length && filtrados.length > 0} onChange={seleccionarTodos} aria-label="Seleccionar todos" />
                <span>Todos</span>
              </label>
              {seleccionados.size > 0 && (
                <>
                  <span className="selection-count">| {seleccionados.size} seleccionados</span>
                  <button onClick={() => setDelMultiple(true)} className="btn-bulk-delete">
                    🗑️ Eliminar ({seleccionados.size})
                  </button>
                </>
              )}
            </div>
          )}

          <DataPanel
            title="Proyectos" count={lista?.length || 0}
            busqueda={busqueda} setBusqueda={setBusqueda}
            pagination={{
              actual: pagina,
              totalPaginas: respuesta?.pagination?.total_pages || 1,
              total: respuesta?.pagination?.total || 0,
              perPage: respuesta?.pagination?.per_page || perPage,
              onChange: (n) => setPagina(n)
            }}
            placeholder="Buscar proyecto, cliente..."
            onAdd={() => abrir(null)} addLabel="Nuevo proyecto"
            onExcel={() => api.exportar('proyectos')}
            loading={loading}
            onPerPageChange={n => { setPerPage(n); setPagina(1) }}
            sort={{ key: sortKey, dir: sortDir, toggle: sortToggle }}
            cols={[
              { l: <input type="checkbox" checked={seleccionados.size === filtrados.length && filtrados.length > 0} onChange={seleccionarTodos} aria-label="Seleccionar todos los proyectos" />, w: 40 },
              { l: 'Proyecto', sortKey: 'nombre' },
              { l: 'Cliente', sortKey: 'cliente_nombre' },
              { l: 'Tipo', sortKey: 'tipo_proyecto' },
              { l: 'Estado', sortKey: 'estado' },
              { l: 'Presupuesto', r: true, sortKey: 'presupuesto' },
              { l: 'Acciones', r: true }
            ]}
            rows={filtradosOrdenados.map(p => [
              <input type="checkbox" checked={seleccionados.has(p.id)} onChange={() => toggleSeleccion(p.id)} aria-label={`Seleccionar proyecto ${p.nombre}`} />,
              <div>
                <div style={{ fontWeight: 700, color: 'var(--txt)' }}>{p.nombre}</div>
                <div className="tbl-muted" style={{ fontSize: '11px' }}>{fecha(p.fecha_inicio)} → {fecha(p.fecha_termino)}</div>
              </div>,
              <div>
                <div style={{ fontWeight: 600, color: 'var(--txt)' }}>{p.cliente_nombre || '—'}</div>
                {p.cliente_tipo === 'Agencia' && <div className="tbl-muted" style={{ fontSize: '11px' }}>{p.nombre_agencia}</div>}
              </div>,
              <span className="tbl-muted">{p.tipo_proyecto || '—'}</span>,
              <Badge s={p.estado} />,
              <strong style={{ color: 'var(--txt)' }}>{clp(p.presupuesto)}</strong>,
              <Acciones onEdit={() => abrir(p)} onDel={() => setDel(p.id)} />,
            ])}
            vacio="No se encontraron proyectos"
          />
        </>
      )}

      {modal && (
        <Modal title={editando ? 'Editar proyecto' : 'Nuevo proyecto'} onClose={() => setModal(false)}>
          <FormularioInterno
            editando={editando}
            clientes={clientes}
            servicios={servicios}
            onSave={guardar}
            onCancel={() => setModal(false)}
            isPending={crearProyecto.isPending || editarProyecto.isPending}
          />
        </Modal>
      )}

      {del && <Confirm msg="¿Eliminar este proyecto?" onSi={async () => { await borrarProyecto.mutateAsync(del); setDel(null); showToast('Eliminado') }} onNo={() => setDel(null)} />}
      
      {delMultiple && (
        <Confirm 
          msg={`¿Eliminar ${seleccionados.size} proyectos?`} 
          onSi={async () => {
            for (const id of seleccionados) await borrarProyecto.mutateAsync(id)
            clearSeleccion(); setDelMultiple(false); showToast('Eliminados')
          }}
          onNo={() => setDelMultiple(false)} 
        />
      )}
    </div>
  )
}