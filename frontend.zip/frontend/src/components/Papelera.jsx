import { useState, useEffect } from 'react'
import { api } from '../assets/js/api.js'
import { DataPanel, Toast, useToast, Confirm, Skeleton } from './UI.jsx'
import { useLocalState } from '../hooks/useLocalState.js'

export default function Papelera() {
  const [tab, setTab] = useState('todos')
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [toast, showToast] = useToast()
  const [busqueda, setBusqueda] = useState('')
  const [seleccionados, setSeleccionados] = useState(new Set())
  const [pagina, setPagina] = useState(1)
  const [perPage, setPerPage] = useLocalState('papelera:perPage', 10)
  
  const [modalRestore, setModalRestore] = useState(null)
  const [modalDelete, setModalDelete] = useState(null)
  const [modalVaciar, setModalVaciar] = useState(false)

  const tabs = [
    { id: 'todos', label: 'Todos' },
    { id: 'clientes', label: 'Clientes' },
    { id: 'proyectos', label: 'Proyectos' },
    { id: 'sitios', label: 'Sitios' },
    { id: 'cotizaciones', label: 'Cotizaciones' },
    { id: 'pagos', label: 'Pagos' },
    { id: 'servicios', label: 'Servicios' },
  ]

  const [contadores, setContadores] = useState({
    clientes: 0, proyectos: 0, sitios: 0, cotizaciones: 0, pagos: 0, servicios: 0, total: 0
  })

  const cargarContadores = async () => {
    try {
      const [c, p, sit, cot, pag, svc] = await Promise.all([
        api.getClientes({ papelera: true, per_page: 1000 }),
        api.getProyectos({ papelera: true, per_page: 1000 }),
        api.getSitios({ papelera: true, per_page: 1000 }),
        api.getCotizaciones({ papelera: true, per_page: 1000 }),
        api.getPagos({ papelera: true, per_page: 1000 }),
        api.getServicios({ papelera: true, per_page: 1000 })
      ])

      const dC   = c?.data || [];
      const dP   = p?.data || [];
      const dSit = sit?.data || [];
      const dCot = cot?.data || [];
      const dPag = pag?.data || [];
      const dSvc = svc?.data || [];

      setContadores({
        clientes: dC.length,
        proyectos: dP.length,
        sitios: dSit.length,
        cotizaciones: dCot.length,
        pagos: dPag.length,
        servicios: dSvc.length,
        total: dC.length + dP.length + dSit.length + dCot.length + dPag.length + dSvc.length
      })
    } catch { }
  }

  const cargarPapelera = async () => {
    setLoading(true)
    try {
      let raw = []
      switch(tab) {
        case 'todos':
          const [c, p, sit, cot, pag, svc] = await Promise.all([
            api.getClientes({ papelera: true, per_page: 1000 }),
            api.getProyectos({ papelera: true, per_page: 1000 }),
            api.getSitios({ papelera: true, per_page: 1000 }),
            api.getCotizaciones({ papelera: true, per_page: 1000 }),
            api.getPagos({ papelera: true, per_page: 1000 }),
            api.getServicios({ papelera: true, per_page: 1000 })
          ])
          raw = [
            ...(c?.data || []).map(x => ({ ...x, _tipo: 'cliente' })),
            ...(p?.data || []).map(x => ({ ...x, _tipo: 'proyecto' })),
            ...(sit?.data || []).map(x => ({ ...x, _tipo: 'sitio' })),
            ...(cot?.data || []).map(x => ({ ...x, _tipo: 'cotizacion' })),
            ...(pag?.data || []).map(x => ({ ...x, _tipo: 'pago' })),
            ...(svc?.data || []).map(x => ({ ...x, _tipo: 'servicio' }))
          ]
          break
        default:
          const res = await api[`get${tab.charAt(0).toUpperCase() + tab.slice(1)}`]({ papelera: true, per_page: 1000 });
          raw = res?.data || [];
      }
      setItems(raw)
    } catch(e) { showToast(e.message, 'err') }
    setLoading(false)
  }

  useEffect(() => {
    setSeleccionados(new Set())
    setModalRestore(null)
    setModalDelete(null)
    setModalVaciar(false)
    setPagina(1)
    cargarPapelera()
  }, [tab])

  // Resetear página al buscar
  useEffect(() => { setPagina(1) }, [busqueda])
  
  useEffect(() => {
    cargarContadores()
  }, [])

  const [tipoRestaurar, setTipoRestaurar] = useState(null)
  const [tipoEliminar, setTipoEliminar] = useState(null)
  
  const restaurar = async (id, tipo) => {
    setModalRestore(id)
    setTipoRestaurar(tipo || tab)
  }
  
  const confirmarRestaurar = async () => {
    const id = modalRestore
    const tipo = tipoRestaurar
    setModalRestore(null)
    setTipoRestaurar(null)
    if (!id || !tipo) return
    
    setLoading(true)
    try {
      switch(tipo) {
        case 'clientes': case 'cliente': await api.restaurarCliente(id); break
        case 'proyectos': case 'proyecto': await api.restaurarProyecto(id); break
        case 'sitios': case 'sitio': await api.restaurarSitio(id); break
        case 'cotizaciones': case 'cotizacion': await api.restaurarCotizacion(id); break
        case 'pagos': case 'pago': await api.restaurarPago(id); break
        case 'servicios': case 'servicio': await api.restaurarServicio(id); break
      }
      showToast('Restaurado')
      cargarPapelera(); cargarContadores()
    } catch(e) { showToast(e.message, 'err') }
    setLoading(false)
  }

  const eliminarDefinitivo = async (id, nombre, tipo) => {
    setModalDelete({id, nombre})
    setTipoEliminar(tipo || tab)
  }
  
  const confirmarEliminar = async () => {
    const {id} = modalDelete || {}
    setModalDelete(null)
    if (!id) return
    
    setLoading(true)
    try {
      const tipo = tipoEliminar || tab
      switch(tipo) {
        case 'clientes': case 'cliente': await api.eliminarClienteDefinitivo(id); break
        case 'proyectos': case 'proyecto': await api.eliminarProyectoDefinitivo(id); break
        case 'sitios': case 'sitio': await api.eliminarSitioDefinitivo(id); break
        case 'cotizaciones': case 'cotizacion': await api.eliminarCotizacionDefinitivo(id); break
        case 'pagos': case 'pago': await api.eliminarPagoDefinitivo(id); break
        case 'servicios': case 'servicio': await api.eliminarServicioDefinitivo(id); break
      }
      showToast('Eliminado permanentemente')
      setTipoEliminar(null)
      cargarPapelera(); cargarContadores()
    } catch(e) { showToast(e.message, 'err') }
    setLoading(false)
  }

  const getNombre = (item) => {
    if(!item) return '—';
    return item.nombre || item.razon_social || item.titulo || item.numero || item.descripcion || `ID ${item.id}`;
  }
  
  const getTipoOInfo = (item) => {
    const t = item._tipo || tab;
    if (t === 'clientes' || t === 'cliente') return item.tipo || '—'
    if (t === 'proyectos' || t === 'proyecto') return item.cliente_nombre || '—'
    if (t === 'sitios' || t === 'sitio') return item.cliente_display || item.cliente_nombre || '—'
    if (t === 'cotizaciones' || t === 'cotizacion') return item.cliente_nombre || '—'
    if (t === 'pagos' || t === 'pago') return item.cliente_nombre || '—'
    if (t === 'servicios' || t === 'servicio') return item.categoria || '—'
    return '—'
  }

  const formatearFecha = (fecha) => {
    if (!fecha) return '—'
    return new Date(fecha).toLocaleString('es-CL', {
      day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'
    })
  }

  const filtrados = (items || []).filter(item =>
    getNombre(item).toLowerCase().includes(busqueda.toLowerCase())
  )

  // Paginación cliente
  const totalPaginas = Math.max(1, Math.ceil(filtrados.length / perPage))
  const paginaSegura = Math.min(pagina, totalPaginas)
  const inicio = (paginaSegura - 1) * perPage
  const paginados = filtrados.slice(inicio, inicio + perPage)

  const toggleSeleccion = (id) => {
    const nuevo = new Set(seleccionados)
    if (nuevo.has(id)) nuevo.delete(id)
    else nuevo.add(id)
    setSeleccionados(nuevo)
  }

  const seleccionarTodos = () => {
    // Selecciona/deselecciona solo los de la página actual
    const idsPagina = paginados.map(item => item.id)
    const todosSeleccionados = idsPagina.every(id => seleccionados.has(id))
    const nuevo = new Set(seleccionados)
    if (todosSeleccionados) {
      idsPagina.forEach(id => nuevo.delete(id))
    } else {
      idsPagina.forEach(id => nuevo.add(id))
    }
    setSeleccionados(nuevo)
  }

  const restaurarSeleccionados = async () => {
    if (seleccionados.size === 0) return
    setModalRestore('multiple')
  }
  
  const confirmarRestaurarMultiple = async () => {
    setModalRestore(null)
    if (seleccionados.size === 0) return
    setLoading(true)
    try {
      for (const id of Array.from(seleccionados)) {
        const item = items.find(i => String(i.id) === String(id))
        const tipo = item?._tipo || tab
        switch(tipo) {
          case 'clientes': case 'cliente': await api.restaurarCliente(id); break
          case 'proyectos': case 'proyecto': await api.restaurarProyecto(id); break
          case 'cotizaciones': case 'cotizacion': await api.restaurarCotizacion(id); break
          case 'pagos': case 'pago': await api.restaurarPago(id); break
          case 'servicios': case 'servicio': await api.restaurarServicio(id); break
        }
      }
      showToast(`${seleccionados.size} restaurados`)
      setSeleccionados(new Set()); cargarPapelera(); cargarContadores()
    } catch(e) { showToast(e.message, 'err') }
    setLoading(false)
  }

  const eliminarSeleccionados = async () => {
    if (seleccionados.size === 0) return
    setModalDelete('multiple')
  }
  
  const confirmarEliminarMultiple = async () => {
    setModalDelete(null)
    if (seleccionados.size === 0) return
    setLoading(true)
    try {
      for (const id of Array.from(seleccionados)) {
        const item = items.find(i => String(i.id) === String(id))
        const tipo = item?._tipo || tab
        switch(tipo) {
          case 'clientes': case 'cliente': await api.eliminarClienteDefinitivo(id); break
          case 'proyectos': case 'proyecto': await api.eliminarProyectoDefinitivo(id); break
          case 'cotizaciones': case 'cotizacion': await api.eliminarCotizacionDefinitivo(id); break
          case 'pagos': case 'pago': await api.eliminarPagoDefinitivo(id); break
          case 'servicios': case 'servicio': await api.eliminarServicioDefinitivo(id); break
        }
      }
      showToast(`${seleccionados.size} eliminados permanentemente`)
      setSeleccionados(new Set()); cargarPapelera(); cargarContadores()
    } catch(e) { showToast(e.message, 'err') }
    setLoading(false)
  }

  const vaciarPapelera = async () => {
    if (items.length === 0) return
    setModalVaciar(true)
  }

  const confirmarVaciarPapelera = async () => {
    setModalVaciar(false)
    setLoading(true)
    try {
      for (const item of items) {
        const tipo = item._tipo || tab
        switch(tipo) {
          case 'clientes': case 'cliente': await api.eliminarClienteDefinitivo(item.id); break
          case 'proyectos': case 'proyecto': await api.eliminarProyectoDefinitivo(item.id); break
          case 'sitios': case 'sitio': await api.eliminarSitioDefinitivo(item.id); break
          case 'cotizaciones': case 'cotizacion': await api.eliminarCotizacionDefinitivo(item.id); break
          case 'pagos': case 'pago': await api.eliminarPagoDefinitivo(item.id); break
          case 'servicios': case 'servicio': await api.eliminarServicioDefinitivo(item.id); break
        }
      }
      showToast(`Papelera vaciada`)
      setSeleccionados(new Set()); cargarPapelera(); cargarContadores()
    } catch(e) { showToast(e.message, 'err') }
    setLoading(false)
  }

  return (
    <div>
      {toast && <Toast {...toast} />}

      {loading && (
        <div className="card" style={{padding:'16px'}}>
          <div style={{marginBottom:'16px'}}><Skeleton className="skeleton-title" /></div>
          {[...Array(5)].map((_,i)=>(<Skeleton key={i} className="skeleton-row" />))}
        </div>
      )}

      {!loading && (
        <div className="data-panel__filters mb-3">
        {tabs.map(t => {
          const count = t.id === 'todos' ? contadores.total : contadores[t.id]
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`data-panel__filter-btn${tab===t.id?' data-panel__filter-btn--on':''}`}
              style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
            >
              {t.label}
              {count > 0 && <span className="tab-badge">{count > 99 ? '99+' : count}</span>}
            </button>
          )
        })}
      </div>
      )}

      {!loading && filtrados.length > 0 && (
        <div className="bulk-actions-bar">
          <label>
            <input type="checkbox"
              checked={paginados.length > 0 && paginados.every(item => seleccionados.has(item.id))}
              onChange={seleccionarTodos}
              aria-label="Seleccionar todos los elementos de la página" />
            <span>Todos (página)</span>
          </label>
          {seleccionados.size > 0 && (
            <>
              <span className="selection-count">| {seleccionados.size} seleccionados</span>
              <button onClick={restaurarSeleccionados} className="btn-bulk-restore">↩️ Restaurar ({seleccionados.size})</button>
              <button onClick={eliminarSeleccionados} className="btn-bulk-delete">🗑️ Eliminar ({seleccionados.size})</button>
            </>
          )}
          {seleccionados.size === 0 && (
            <button onClick={vaciarPapelera} className="btn-bulk-empty">🗑️ Vaciar Papelera ({items.length})</button>
          )}
        </div>
      )}

      <DataPanel
        title={`Papelera: ${tabs.find(t=>t.id===tab)?.label}`}
        count={filtrados.length}
        total={items?.length || 0}
        busqueda={busqueda}
        setBusqueda={setBusqueda}
        placeholder="Buscar..."
        loading={loading}
        pagination={{
          actual: paginaSegura,
          totalPaginas: totalPaginas,
          total: filtrados.length,
          perPage: perPage,
          onChange: (n) => setPagina(n)
        }}
        onPerPageChange={n => { setPerPage(n); setPagina(1) }}
        cols={[
          {l:<input type="checkbox"
            checked={paginados.length > 0 && paginados.every(item => seleccionados.has(item.id))}
            onChange={seleccionarTodos}
            aria-label="Seleccionar todos"/>, w:40},
          {l:'Nombre'},
          {l:tab==='clientes'?'Tipo':'Cliente/Info'},
          {l:'Fecha Eliminación'},
          {l:'Acciones',r:true}
        ]}
        rows={paginados.map(item => [
          <input type="checkbox" checked={seleccionados.has(item.id)} onChange={() => toggleSeleccion(item.id)} aria-label={`Seleccionar ${getNombre(item)}`} />,
          <span className="txt-bold">{getNombre(item)}</span>,
          <span className="tbl-muted">{getTipoOInfo(item)}</span>,
          <span className="tbl-muted txt-small">{formatearFecha(item.deleted_at)}</span>,
          <div className="acts">
            <button onClick={() => restaurar(item.id, item._tipo || tab)} className="btn-row-restore">↩️ Restaurar</button>
            <button onClick={() => eliminarDefinitivo(item.id, getNombre(item), item._tipo || tab)} className="btn-row-delete">🗑️ Eliminar</button>
          </div>
        ])}
        vacio="No hay elementos en la papelera"
      />
      
      {modalRestore && modalRestore !== 'multiple' && (
        <Confirm
          msg={`¿Restaurar "${getNombre(items.find(i => i.id === modalRestore))}"?`}
          onSi={confirmarRestaurar}
          onNo={() => setModalRestore(null)}
          okLabel="Restaurar" icon="↩️" color="#2e7d32"
        />
      )}
      
      {modalRestore === 'multiple' && (
        <Confirm
          msg={`¿Restaurar ${seleccionados.size} elementos seleccionados?`}
          onSi={confirmarRestaurarMultiple}
          onNo={() => setModalRestore(null)}
          okLabel="Restaurar" icon="↩️" color="#2e7d32"
        />
      )}
      
      {modalDelete && modalDelete !== 'multiple' && (
        <Confirm
          msg={`¿ELIMINAR DEFINITIVAMENTE "${modalDelete.nombre}"?\n\nEsta acción NO se puede deshacer.`}
          onSi={confirmarEliminar}
          onNo={() => setModalDelete(null)}
          okLabel="Eliminar" icon="🗑️" color="var(--acc2)"
          requireText="ELIMINAR"
        />
      )}

      {modalDelete === 'multiple' && (
        <Confirm
          msg={`¿ELIMINAR DEFINITIVAMENTE ${seleccionados.size} elementos?\n\nEsta acción NO se puede deshacer.`}
          onSi={confirmarEliminarMultiple}
          onNo={() => setModalDelete(null)}
          okLabel="Eliminar" icon="🗑️" color="var(--acc2)"
          requireText="ELIMINAR"
        />
      )}

      {modalVaciar && (
        <Confirm
          msg={`¿VACIAR TODA LA PAPELERA?\n\nSe eliminarán PERMANENTEMENTE ${items.length} elementos de ${tabs.find(t=>t.id===tab)?.label}.\n\n⚠️ Esta acción NO se puede deshacer.`}
          onSi={confirmarVaciarPapelera}
          onNo={() => setModalVaciar(false)}
          okLabel="Vaciar Papelera" icon="🗑️" color="#c62828"
          requireText="VACIAR"
        />
      )}
    </div>
  )
}