import { useState, useEffect, useCallback } from 'react'
import { Ic } from './UI.jsx'
import { I } from '../assets/js/helpers.js'
import { api, session } from '../assets/js/api.js'

const POLL_MS = 60_000

export default function Notificaciones() {
  const [items, setItems] = useState([])
  const [noLeidas, setNoLeidas] = useState(0)
  const [abierto, setAbierto] = useState(false)
  const [loading, setLoading] = useState(false)

  const cargar = useCallback(async () => {
    if (!session.logged()) return
    setLoading(true)
    try {
      const r = await api.getNotificaciones()
      setItems(Array.isArray(r?.items) ? r.items : [])
      setNoLeidas(Number(r?.no_leidas) || 0)
    } catch { /* silencioso — backend puede no estar */ }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { cargar() }, [cargar])
  useEffect(() => {
    const id = setInterval(cargar, POLL_MS)
    return () => clearInterval(id)
  }, [cargar])

  // Permite que el resto del sistema cree notificaciones locales que también se persistan
  useEffect(() => {
    const handler = (e) => {
      const { mensaje, tipo, link } = e.detail || {}
      if (!mensaje) return
      api.crearNotificacion({ mensaje, tipo: tipo || 'info', link: link || null })
         .then(cargar)
         .catch(() => { /* silent */ })
    }
    window.addEventListener('nueva-notificacion', handler)
    return () => window.removeEventListener('nueva-notificacion', handler)
  }, [cargar])

  const marcarLeida = async (id) => {
    setItems(prev => prev.map(n => n.id === id ? { ...n, leida: 1 } : n))
    setNoLeidas(c => Math.max(0, c - 1))
    try { await api.marcarNotifLeida(id) } catch { cargar() }
  }
  const marcarTodas = async () => {
    setItems(prev => prev.map(n => ({ ...n, leida: 1 })))
    setNoLeidas(0)
    try { await api.marcarTodasLeidas() } catch { cargar() }
  }
  const eliminar = async (id) => {
    setItems(prev => prev.filter(n => n.id !== id))
    try { await api.eliminarNotif(id) } catch { cargar() }
  }
  const limpiar = async () => {
    setItems([]); setNoLeidas(0)
    try { await api.eliminarTodasNotif() } catch { cargar() }
  }

  const icono = (tipo) => {
    switch(tipo) {
      case 'success':    return <Ic d={I.check} size={14}/>
      case 'warning':    return <Ic d={I.warn} size={14}/>
      case 'error':      return <Ic d={I.x} size={14}/>
      case 'info':       return <Ic d={I.info} size={14}/>
      case 'pago':       return <Ic d={I.pay} size={14}/>
      case 'cliente':    return <Ic d={I.users} size={14}/>
      case 'proyecto':   return <Ic d={I.projects} size={14}/>
      case 'cotizacion': return <Ic d={I.pdf} size={14}/>
      default:           return <Ic d={I.bell} size={14}/>
    }
  }

  const formatear = (ts) => {
    const f = new Date(ts.replace(' ', 'T'))
    const diff = (Date.now() - f.getTime()) / 1000
    if (diff < 60)    return 'Hace un momento'
    if (diff < 3600)  return `Hace ${Math.floor(diff/60)} min`
    if (diff < 86400) return `Hace ${Math.floor(diff/3600)} h`
    return f.toLocaleDateString('es-CL')
  }

  return (
    <div className="notificaciones-container">
      <button
        className="notificaciones-bell"
        onClick={() => setAbierto(v => !v)}
        title="Notificaciones"
        aria-label={noLeidas > 0 ? `Notificaciones (${noLeidas} sin leer)` : 'Notificaciones'}
        aria-haspopup="true"
        aria-expanded={abierto}
        type="button"
      >
        <Ic d={I.bell} size={20} />
        {noLeidas > 0 && (
          <span className="notificaciones-badge" aria-hidden="true">{noLeidas > 99 ? '99+' : noLeidas}</span>
        )}
      </button>

      {abierto && (
        <>
          <div className="notificaciones-overlay" onClick={() => setAbierto(false)} />
          <div className="notificaciones-panel">
            <div className="notificaciones-header">
              <h3>🔔 Notificaciones</h3>
              <div className="notificaciones-acciones">
                {noLeidas > 0 && (
                  <button onClick={marcarTodas} title="Marcar todas como leídas" type="button">✓ Todo leído</button>
                )}
                {items.length > 0 && (
                  <button onClick={limpiar} title="Eliminar todas" type="button">🗑️</button>
                )}
                <button onClick={() => setAbierto(false)} aria-label="Cerrar" type="button">
                  <Ic d={I.x} size={16} />
                </button>
              </div>
            </div>

            <div className="notificaciones-lista">
              {loading && items.length === 0 ? (
                <div className="notificaciones-empty"><p>Cargando…</p></div>
              ) : items.length === 0 ? (
                <div className="notificaciones-empty">
                  <span>🔔</span>
                  <p>No hay notificaciones</p>
                  <small>Las notificaciones aparecerán aquí</small>
                </div>
              ) : (
                items.map(n => (
                  <div
                    key={n.id}
                    className={`notificacion-item ${n.leida ? 'leida' : ''}`}
                    onClick={() => !n.leida && marcarLeida(n.id)}
                  >
                    <span className="notificacion-icono">{icono(n.tipo)}</span>
                    <div className="notificacion-contenido">
                      <p className="notificacion-mensaje">{n.mensaje}</p>
                      <span className="notificacion-tiempo">{formatear(n.created_at)}</span>
                    </div>
                    <button
                      className="notificacion-eliminar"
                      onClick={(e) => { e.stopPropagation(); eliminar(n.id) }}
                      title="Eliminar"
                      type="button"
                    >
                      <Ic d={I.x} size={12} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

/** Emite una notificación que será persistida en backend por el componente */
export const notify = (mensaje, tipo = 'info', link = null) => {
  window.dispatchEvent(new CustomEvent('nueva-notificacion', { detail: { mensaje, tipo, link } }))
}
