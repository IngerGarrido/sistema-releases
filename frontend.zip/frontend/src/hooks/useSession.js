import { useEffect, useState } from 'react'
import { session } from '../assets/js/api.js'

/**
 * Sincroniza la sesión entre pestañas y emite un warning antes de expirar.
 *
 * Estrategia simple sin tocar backend:
 * - Al login, el frontend recuerda `_t_at` (timestamp). La sesión backend dura 8h sliding.
 * - Si pasaron 7h45m sin actividad, se emite event 'session:warning'.
 * - Si una pestaña hace logout/login, otras se sincronizan vía storage event.
 */
const SESSION_TTL_MS  = 8 * 60 * 60 * 1000        // 8h
const WARN_BEFORE_MS  = 15 * 60 * 1000            // avisar 15 min antes
const CHECK_EVERY_MS  = 30 * 1000

export function useSession(onLogout) {
  const [warning, setWarning] = useState(false)

  // Marcar timestamp al obtener token nuevo
  useEffect(() => {
    if (session.getToken() && !localStorage.getItem('_t_at')) {
      localStorage.setItem('_t_at', String(Date.now()))
    }
  }, [])

  // Tick para detectar expiración inminente
  useEffect(() => {
    const tick = () => {
      const at = parseInt(localStorage.getItem('_t_at') || '0', 10)
      if (!at || !session.getToken()) { setWarning(false); return }
      const elapsed = Date.now() - at
      if (elapsed >= SESSION_TTL_MS) {
        // Expirada — limpiar y avisar
        session.clear()
        try { localStorage.removeItem('_t_at') } catch {}
        onLogout?.('expired')
        setWarning(false)
        return
      }
      setWarning(elapsed >= SESSION_TTL_MS - WARN_BEFORE_MS)
    }
    tick()
    const id = setInterval(tick, CHECK_EVERY_MS)
    return () => clearInterval(id)
  }, [onLogout])

  // Sincronización entre pestañas: si otra pestaña hace logout, esta también
  useEffect(() => {
    const onStorage = (e) => {
      if (e.key === '_t' && e.newValue === null) {
        onLogout?.('multi-tab-logout')
      }
    }
    window.addEventListener('storage', onStorage)
    return () => window.removeEventListener('storage', onStorage)
  }, [onLogout])

  const extend = () => {
    // El usuario interactúa → renovamos el marcador local (el backend renueva su sliding session al primer request)
    localStorage.setItem('_t_at', String(Date.now()))
    setWarning(false)
  }

  return { warning, extend }
}
