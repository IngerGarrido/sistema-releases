import { useState, useEffect, lazy, Suspense } from 'react'
import { isFormDirty } from './hooks/useUnsavedWarning.js'
import { api, session, resolveUploadUrl } from './assets/js/api.js'
import { I }            from './assets/js/helpers.js'
import { useClientes, useProyectos, useServicios, useConfiguracion } from './hooks/useQueryApi.js'
import { useSession } from './hooks/useSession.js'

// Componentes críticos (cargados inmediatamente)
import Login         from './components/Login.jsx'
import ResetPassword from './components/ResetPassword.jsx'
import Dashboard     from './components/Dashboard.jsx'
import { Ic, Confirm } from './components/UI.jsx'
import ErrorBoundary from './components/ErrorBoundary.jsx'
import BuscadorGlobal from './components/BuscadorGlobal.jsx'
import Notificaciones from './components/Notificaciones.jsx'

// Lazy loading para componentes pesados
const Clientes      = lazy(() => import('./components/Clientes.jsx'))
const Proyectos     = lazy(() => import('./components/Proyectos.jsx'))
const Cotizaciones  = lazy(() => import('./components/Cotizaciones.jsx'))
const Pagos         = lazy(() => import('./components/Pagos.jsx'))
const Servicios     = lazy(() => import('./components/Servicios.jsx'))
const Usuarios      = lazy(() => import('./components/Usuarios.jsx'))
const Papelera      = lazy(() => import('./components/Papelera.jsx'))
const Configuracion = lazy(() => import('./components/Configuracion.jsx'))
const Auditoria     = lazy(() => import('./components/Auditoria.jsx'))
const Reportes      = lazy(() => import('./components/Reportes.jsx'))
const Sitios        = lazy(() => import('./components/Sitios.jsx'))

// Preloaders — dispara el dynamic import al hacer hover en el NAV
const preloaders = {
  clientes:     () => import('./components/Clientes.jsx'),
  proyectos:    () => import('./components/Proyectos.jsx'),
  cotizaciones: () => import('./components/Cotizaciones.jsx'),
  pagos:        () => import('./components/Pagos.jsx'),
  servicios:    () => import('./components/Servicios.jsx'),
  usuarios:     () => import('./components/Usuarios.jsx'),
  papelera:     () => import('./components/Papelera.jsx'),
  configuracion:() => import('./components/Configuracion.jsx'),
  auditoria:    () => import('./components/Auditoria.jsx'),
  reportes:     () => import('./components/Reportes.jsx'),
  sitios:       () => import('./components/Sitios.jsx'),
}

// Componente de carga para Suspense
const PageLoader = () => (
  <div style={{padding: 40, textAlign: 'center'}}>
    <div className="shimmer" style={{height: 200, borderRadius: 12, marginBottom: 20}} />
    <div className="shimmer" style={{height: 20, borderRadius: 6, width: '60%', margin: '0 auto 10px'}} />
    <div className="shimmer" style={{height: 20, borderRadius: 6, width: '40%', margin: '0 auto'}} />
  </div>
)


import './assets/css/variables.css'
import './assets/css/layout.css';
import './assets/css/ui.css';
import './assets/css/pages.css';
import './assets/css/papelera.css';
import './assets/css/buscador.css';
import './assets/css/notificaciones.css';

export default function App() {
  const [user,     setUser]  = useState(() => session.getUser())
  const [sec,      setSec]   = useState(() => localStorage.getItem('_sec') || 'dashboard')
  const [cfgOverride, setCfgOverride] = useState(null)
  const [menuOpen, setMenu]  = useState(false)
  const [dark,     setDark]  = useState(() => localStorage.getItem('_dark') === '1')
  const [userMenuOpen, setUserMenuOpen] = useState(false)

  // Migrado a React Query: solo se ejecuta logueado, con cache compartido.
  const enabled = !!user
  const { data: clientesData,  error: errClientes  } = useClientes ({ per_page: 1000 }, { enabled })
  const { data: proyectosData, error: errProyectos } = useProyectos({ per_page: 1000 }, { enabled })
  const { data: serviciosData, error: errServicios } = useServicios({ per_page: 1000 }, { enabled })
  const { data: configData,    error: errConfig    } = useConfiguracion({ enabled })

  const unwrap = (r) => Array.isArray(r) ? r : (r?.data ?? [])
  const clientes  = unwrap(clientesData)
  const proyectos = unwrap(proyectosData)
  const servicios = unwrap(serviciosData)
  const baseConfig = configData || { nombre_empresa:'Sistema', sidebar_bg:'#1e2340', color_activo:'#3b5bdb', sidebar_text:'#ffffff', fuente:'DM Sans' }
  const config = cfgOverride || baseConfig

  // Errores de carga: log a consola + evento global para toast (si existe listener).
  // React Query mantiene los datos previos; estos errores son no-bloqueantes.
  useEffect(() => {
    const errs = [
      errClientes  && ['clientes',      errClientes],
      errProyectos && ['proyectos',     errProyectos],
      errServicios && ['servicios',     errServicios],
      errConfig    && ['configuración', errConfig],
    ].filter(Boolean)
    errs.forEach(([nombre, err]) => {
      console.error(`Error cargando ${nombre}:`, err)
      window.dispatchEvent(new CustomEvent('toast', { detail: { type: 'err', msg: `Error cargando ${nombre}` } }))
    })
  }, [errClientes, errProyectos, errServicios, errConfig])

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light')
    localStorage.setItem('_dark', dark ? '1' : '0')
  }, [dark])

  // Fuente global del sistema (cambia --font para toda la app)
  // Usa fuente_global si existe (legacy), si no fuente.
  useEffect(() => {
    const fg = config?.fuente_global || config?.fuente
    if (fg) {
      document.documentElement.style.setProperty('--font', `'${fg}', sans-serif`)
    } else {
      document.documentElement.style.removeProperty('--font')
    }
  }, [config?.fuente_global, config?.fuente])
 
  const [pendingNav, setPendingNav] = useState(null)

  const ir = s => {
    if (isFormDirty()) { setPendingNav(s); return }
    setSec(s); localStorage.setItem('_sec', s); setMenu(false)
  }
  const confirmarNav = () => {
    setSec(pendingNav); localStorage.setItem('_sec', pendingNav); setMenu(false); setPendingNav(null)
  }
  const salir = async () => { try { await api.logout() } catch {} session.clear(); try{localStorage.removeItem('_t_at')}catch{}; setUser(null) }

  // Aviso de sesión por expirar + sincronización multi-pestaña
  const { warning: sessionWarning, extend: extendSession } = useSession((reason) => {
    setUser(null)
    if (reason === 'expired') {
      window.dispatchEvent(new CustomEvent('toast', { detail: { type: 'warn', msg: 'Tu sesión expiró. Inicia sesión nuevamente.' } }))
    }
  })

  // Atajos globales (g+letra, ? para ayuda)
  const [shortcutsOpen, setShortcutsOpen] = useState(false)
  useEffect(() => {
    let waitingForSecond = false
    let waitTimer
    const isTyping = () => {
      const el = document.activeElement
      if (!el) return false
      const tag = el.tagName
      return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el.isContentEditable
    }
    const onKey = (e) => {
      if (isTyping() || e.ctrlKey || e.metaKey || e.altKey) return
      if (e.key === '?') { e.preventDefault(); setShortcutsOpen(true); return }
      if (e.key === 'Escape' && shortcutsOpen) { setShortcutsOpen(false); return }
      if (waitingForSecond) {
        const map = { c:'clientes', p:'proyectos', q:'cotizaciones', d:'dashboard', s:'servicios', u:'usuarios', $:'pagos', r:'reportes', i:'sitios' }
        const target = map[e.key.toLowerCase()]
        waitingForSecond = false
        clearTimeout(waitTimer)
        if (target) { e.preventDefault(); ir(target) }
        return
      }
      if (e.key === 'g') {
        waitingForSecond = true
        waitTimer = setTimeout(() => { waitingForSecond = false }, 1200)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [shortcutsOpen])

  // Cerrar sidebar mobile con Escape
  useEffect(() => {
    if (!menuOpen) return
    const onKey = (e) => { if (e.key === 'Escape') setMenu(false) }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [menuOpen])

  // Escuchar navegación desde BuscadorGlobal
  useEffect(() => {
    const handleNavegar = (e) => {
      const { panel, id } = e.detail
      ir(panel)
      // Guardar ID seleccionado para que el componente lo use
      if (id) {
        localStorage.setItem('_selected_id', id)
      }
    }
    window.addEventListener('navegar', handleNavegar)
    return () => window.removeEventListener('navegar', handleNavegar)
  }, [])
 
  const sbg = config.sidebar_bg   || '#070946'
  const sact= config.color_activo || '#221a93'
  const stxt= config.sidebar_text || '#ffffff'
  const fnt = config.fuente       || 'DM Sans'

  // Detectar token de recuperación de contraseña en URL
  const hash = window.location.hash
  const isResetPassword = hash.includes('reset-password')
  const resetToken = isResetPassword ? new URLSearchParams(hash.split('?')[1]).get('token') : null
 
  if (!user || !session.logged()) {
    // Si hay token de reset, mostrar página de recuperación
    if (resetToken) {
      return <ResetPassword 
        token={resetToken} 
        onVolver={() => window.location.href = '/sistema-local/frontend/'} 
      />
    }
    return <Login onLogin={d => setUser(d)} panelCfg={config} />
  }
 
  const NAV_SECTIONS = [
    { titulo: 'Trabajo', items: [
      { id:'dashboard',    label:'Panel',        icon:I.dash     },
      { id:'servicios',    label:'Servicios',     icon:I.svc      },
      { id:'clientes',     label:'Clientes',      icon:I.clients  },
      { id:'proyectos',    label:'Proyectos',     icon:I.projects },
      { id:'sitios',       label:'Sitios',        icon:I.key      },
      { id:'cotizaciones', label:'Cotizaciones',  icon:I.quotes   },
      { id:'pagos',        label:'Pagos',         icon:I.pay      },
      { id:'reportes',     label:'Reportes',      icon:I.barChart },
    ]},
    ...(user.rol==='admin' ? [{ titulo: 'Administración', items: [
      { id:'usuarios',  label:'Usuarios',  icon:I.users    },
      { id:'auditoria', label:'Auditoría', icon:I.fileText },
      { id:'papelera',  label:'Papelera',  icon:I.trash    },
    ]}] : []),
    { titulo: 'Sistema', items: [
      { id:'configuracion', label:'Configuración', icon:I.gear },
    ]},
  ]
  // Flatten para títulos en topbar
  const NAV = NAV_SECTIONS.flatMap(s => s.items)

  const sidebarLite = (config.sidebar_lite === '1' || config.sidebar_lite === 1)

  const Sidebar = () => (
    <div className={`sidebar${sidebarLite ? ' sidebar--lite' : ''}`} style={{ background:sbg, fontFamily:`'${fnt}',sans-serif` }}>
      <div className="sb-top">
        {config.logo_url && <img src={resolveUploadUrl(config.logo_url)} alt={`Logo de ${config.nombre_empresa || 'Sistema'}`} className="sb-logo-img" />}
        <div className="sb-logo">{config.nombre_empresa||'Sistema'}</div>
        <div className="sb-user">{user.nombre}</div>
      </div>
      <nav className="sb-nav">
        {NAV_SECTIONS.map(section => (
          <div className="sb-section" key={section.titulo}>
            <div className="sb-section-title" style={{ color: stxt }}>{section.titulo}</div>
            {section.items.map(n => {
              const on = sec === n.id
              return (
                <button key={n.id} onClick={() => ir(n.id)}
                  className={`sb-btn${on?' act':''}`}
                  title={sidebarLite ? n.label : undefined}
                  aria-label={n.label}
                  style={{ color:on?'#fff':stxt, opacity:on?1:.55, fontFamily:`'${fnt}',sans-serif` }}
                  onMouseEnter={e=>{ preloaders[n.id]?.(); if(!on){ e.currentTarget.style.background='rgba(255,255,255,.08)'; e.currentTarget.style.opacity='0.85' }}}
                  onMouseLeave={e=>{ if(!on){ e.currentTarget.style.background='transparent'; e.currentTarget.style.opacity='0.55' }}}>
                  <Ic d={n.icon} size={15} stroke={on?'#fff':stxt} />
                  {n.label}
                </button>
              )
            })}
          </div>
        ))}
      </nav>
      <div className="sb-ft">
        <div className="sb-ver">v5.0 · PHP + MySQL</div>
      </div>
    </div>
  )
 
  return (
    <div className="app-root" style={{ fontFamily:`'${fnt}','Segoe UI',system-ui,sans-serif` }}>
      <a href="#main-content" className="skip-link">Saltar al contenido</a>
      <div className="sb-desktop"><Sidebar /></div>
 
      {menuOpen && (
        <div className="sb-overlay">
          <div className="sb-overlay-bg" onClick={() => setMenu(false)} />
          <div className="sb-overlay-panel"><Sidebar /></div>
        </div>
      )}
 
      <div className="app-main">
        <div className="topbar">
          <button className="burger" onClick={() => setMenu(true)} aria-label="Abrir menú" type="button">
            <Ic d={I.menu} size={20} />
          </button>
          <span className="topbar-title">{NAV.find(n=>n.id===sec)?.label}</span>
          <div className="topbar-right">
            <button
              className="topbar-search"
              onClick={() => window.dispatchEvent(new KeyboardEvent('keydown', {ctrlKey: true, key: 'k'}))}
              title="Buscar (Ctrl+K)"
              aria-label="Abrir buscador global (Ctrl+K)"
              type="button"
            >
              <Ic d={I.search} size={18} />
              <span>Buscar</span>
              <kbd>Ctrl+K</kbd>
            </button>
            <Notificaciones />
            <div className="user-menu">
              <button
                className="user-avatar-btn"
                onClick={() => setUserMenuOpen(v=>!v)}
                aria-haspopup="true"
                aria-expanded={userMenuOpen}
                aria-label="Menú de usuario"
                type="button"
              >
                <div className="user-avatar">{user.nombre?.[0]?.toUpperCase() || 'U'}</div>
              </button>
              {userMenuOpen && (
                <>
                  <div className="user-menu-overlay" onClick={()=>setUserMenuOpen(false)} />
                  <div className="user-menu-dropdown" role="menu">
                    <div className="user-menu-header">
                      <div className="user-menu-name">{user.nombre}</div>
                      <div className="user-menu-email">{user.email}</div>
                    </div>
                    <button role="menuitem" onClick={() => { setUserMenuOpen(false); ir('configuracion') }}>Configuración</button>
                    <button role="menuitem" onClick={() => { setDark(!dark); setUserMenuOpen(false) }}>{dark ? '☀️ Tema claro' : '🌙 Tema oscuro'}</button>
                    <div className="user-menu-divider" />
                    <button role="menuitem" className="user-menu-logout" onClick={salir}>Cerrar sesión</button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
 
        <div className="app-body" id="main-content">
          <ErrorBoundary key={sec}>
          <Suspense fallback={<PageLoader />}>
            {sec==='dashboard'    && <Dashboard />}
            {sec==='clientes'     && <Clientes />}
            {sec==='proyectos'    && <Proyectos    clientes={clientes} servicios={servicios} />}
            {sec==='cotizaciones' && <Cotizaciones clientes={clientes} proyectos={proyectos} servicios={servicios} />}
            {sec==='pagos'        && <Pagos        clientes={clientes} proyectos={proyectos} />}
            {sec==='reportes'     && <Reportes />}
            {sec==='sitios'       && <Sitios />}
            {sec==='servicios'    && <Servicios />}
            {sec==='usuarios'     && <Usuarios />}
            {sec==='auditoria'    && <Auditoria />}
            {sec==='papelera'     && <Papelera />}
            {sec==='configuracion'&& <Configuracion onPanelChange={setCfgOverride} />}
          </Suspense>
          </ErrorBoundary>
        </div>
      </div>
      
      {pendingNav && (
        <Confirm
          msg="Tienes cambios sin guardar. ¿Salir de todas formas?"
          okLabel="Salir sin guardar"
          icon="⚠️"
          color="var(--acc2)"
          onSi={confirmarNav}
          onNo={() => setPendingNav(null)}
        />
      )}

      {shortcutsOpen && (
        <div role="dialog" aria-modal="true" style={{
          position:'fixed', inset:0, background:'rgba(0,0,0,.45)', zIndex:2100,
          display:'flex', alignItems:'center', justifyContent:'center'
        }} onClick={()=>setShortcutsOpen(false)}>
          <div onClick={e=>e.stopPropagation()} style={{
            background:'var(--card)', color:'var(--txt)', borderRadius:12,
            padding:'22px 26px', maxWidth:480, width:'100%', boxShadow:'0 20px 60px rgba(0,0,0,.3)'
          }}>
            <h3 style={{margin:'0 0 14px'}}>Atajos de teclado</h3>
            <div style={{display:'grid', gridTemplateColumns:'1fr auto', rowGap:8, columnGap:18, fontSize:13}}>
              <span>Buscar global</span><kbd>Ctrl + K</kbd>
              <span>Mostrar esta ayuda</span><kbd>?</kbd>
              <span>Ir a Panel</span><kbd>g d</kbd>
              <span>Ir a Clientes</span><kbd>g c</kbd>
              <span>Ir a Proyectos</span><kbd>g p</kbd>
              <span>Ir a Cotizaciones</span><kbd>g q</kbd>
              <span>Ir a Pagos</span><kbd>g $</kbd>
              <span>Ir a Reportes</span><kbd>g r</kbd>
              <span>Ir a Servicios</span><kbd>g s</kbd>
              <span>Ir a Usuarios (admin)</span><kbd>g u</kbd>
              <span>Guardar configuración</span><kbd>Ctrl + S</kbd>
            </div>
            <div style={{textAlign:'right', marginTop:16}}>
              <button className="btn btn-ghost" onClick={()=>setShortcutsOpen(false)} type="button">Cerrar</button>
            </div>
          </div>
        </div>
      )}

      {sessionWarning && (
        <div role="alert" style={{
          position:'fixed', bottom:18, right:18, zIndex:2000,
          background:'var(--card)', color:'var(--txt)',
          border:'1px solid var(--border)', borderLeft:'4px solid #f59e0b',
          borderRadius:8, padding:'14px 16px', maxWidth:340,
          boxShadow:'0 12px 32px rgba(0,0,0,.18)', fontSize:13
        }}>
          <strong style={{display:'block', marginBottom:4}}>Tu sesión está por expirar</strong>
          <span style={{opacity:.75}}>Se cerrará en menos de 15 minutos por inactividad.</span>
          <div style={{marginTop:10, display:'flex', gap:8}}>
            <button className="btn btn-primary" onClick={extendSession} type="button">Seguir conectado</button>
            <button className="btn btn-ghost" onClick={salir} type="button">Cerrar sesión</button>
          </div>
        </div>
      )}

      {/* Buscador Global */}
      <BuscadorGlobal />
    </div>
  )
}

// App envuelta en ErrorBoundary
export function AppWithErrorBoundary() {
  return (
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  )
}