import { useState } from 'react'
import { api } from '../assets/js/api.js'

export default function ResetPassword({ token, onVolver }) {
  const [password, setPassword] = useState('')
  const [confirmar, setConfirmar] = useState('')
  const [loading, setLoading] = useState(false)
  const [msg, setMsg] = useState('')
  const [error, setError] = useState('')

  const bg1 = '#1e2340'
  const bg2 = '#3b5bdb'

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setMsg('')

    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres')
      return
    }
    if (password !== confirmar) {
      setError('Las contraseñas no coinciden')
      return
    }

    setLoading(true)
    try {
      const res = await api.resetPassword(token, password)
      setMsg(res?.message || 'Contraseña actualizada correctamente')
      setTimeout(() => onVolver(), 3000)
    } catch (e) {
      setError(e?.message || 'Error al actualizar contraseña')
    }
    setLoading(false)
  }

  return (
    <div className="login-root" style={{ background: `linear-gradient(135deg,${bg1},${bg2})` }}>
      <div className="login-card">
        <div className="login-head">
          <div className="login-icon" style={{ background: `linear-gradient(135deg,${bg1},${bg2})` }}>
            <span style={{ fontSize: 24 }}>🔐</span>
          </div>
          <h1 className="login-title">Restablecer Contraseña</h1>
          <p className="login-sub">Ingresa tu nueva contraseña</p>
        </div>

        {msg && (
          <div style={{ 
            padding: 16, 
            background: '#e8f5e9', 
            borderRadius: 8, 
            marginBottom: 16,
            color: '#2e7d32',
            fontSize: 14
          }}>
            {msg}
            <p style={{ marginTop: 8, fontSize: 12 }}>Serás redirigido al login...</p>
          </div>
        )}

        {error && (
          <div style={{ 
            padding: 16, 
            background: '#ffebee', 
            borderRadius: 8, 
            marginBottom: 16,
            color: '#c62828',
            fontSize: 14
          }}>
            {error}
          </div>
        )}

        {!msg && (
          <form onSubmit={submit}>
            <div className="field" style={{ marginBottom: 14 }}>
              <label className="field-lbl">Nueva Contraseña</label>
              <input 
                className="inp" 
                type="password" 
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                minLength={6}
                autoFocus
              />
            </div>
            <div className="field" style={{ marginBottom: 20 }}>
              <label className="field-lbl">Confirmar Contraseña</label>
              <input 
                className="inp" 
                type="password" 
                value={confirmar}
                onChange={e => setConfirmar(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>
            <button 
              type="submit" 
              disabled={loading} 
              className="login-submit"
              style={{ background: `linear-gradient(135deg,${bg1},${bg2})` }}
            >
              {loading ? 'Guardando…' : 'Guardar Contraseña'}
            </button>
          </form>
        )}

        <div style={{ textAlign: 'center', marginTop: 20 }}>
          <button 
            type="button"
            onClick={onVolver}
            style={{ 
              background: 'none', 
              border: 'none', 
              color: bg2, 
              fontSize: 12, 
              cursor: 'pointer',
              textDecoration: 'underline'
            }}
          >
            Volver al login
          </button>
        </div>
      </div>
    </div>
  )
}
