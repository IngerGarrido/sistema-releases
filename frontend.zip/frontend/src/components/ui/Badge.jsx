import React from 'react'
import { COLORES_BADGE } from '../../assets/js/helpers.js'

// Símbolo extra para accesibilidad (daltonismo): además del color se ve un glifo.
const SIMBOLO = {
  'En curso':  '●',  'Cotizado':  '◐',  'Terminado': '✓',
  'Pausado':   '⏸',  'Cancelado': '✕',  'Aceptada':  '✓',
  'Pendiente': '○',  'Rechazada': '✕',  'Pagado':    '✓',
  'Vencido':   '⚠',  'Agencia':   '◆',  'Directo':   '◇',
  'admin':     '★',  'usuario':   '☆',  'Activo':    '●',
}

export const Badge = React.memo(function Badge({ s }) {
  const [bg,tx,dot] = COLORES_BADGE[s]||['#f5f5f5','#555','#999']
  const sym = SIMBOLO[s]
  return (
    <span className="badge" style={{ background:bg, color:tx }} aria-label={`Estado: ${s}`}>
      {sym
        ? <span className="badge-sym" aria-hidden="true" style={{ color:dot, fontSize:'0.85em', marginRight:4 }}>{sym}</span>
        : <span className="badge-dot" aria-hidden="true" style={{ background:dot }} />
      }
      {s}
    </span>
  )
})
