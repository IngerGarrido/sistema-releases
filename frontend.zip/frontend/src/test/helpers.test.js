import { describe, it, expect } from 'vitest'
import { contrastRatio, normalize, clp } from '../assets/js/helpers.js'

describe('contrastRatio', () => {
  it('returns ~21 for black vs white', () => {
    const r = contrastRatio('#000000', '#ffffff')
    expect(r).not.toBeNull()
    expect(r).toBeGreaterThan(20)
    expect(r).toBeLessThanOrEqual(21.5)
  })

  it('returns 1 for identical colors', () => {
    const r = contrastRatio('#abcdef', '#abcdef')
    expect(r).toBeCloseTo(1, 5)
  })

  it('returns null for invalid hex', () => {
    expect(contrastRatio('nope', '#ffffff')).toBeNull()
  })
})

describe('normalize', () => {
  it('lowercases and strips diacritics', () => {
    expect(normalize('Árbol')).toBe('arbol')
    expect(normalize('Ñandú')).toBe('nandu')
  })
})

describe('clp', () => {
  it('formats numbers with $ prefix', () => {
    expect(clp(0)).toMatch(/\$/)
    expect(clp(null)).toMatch(/\$/)
  })
})
