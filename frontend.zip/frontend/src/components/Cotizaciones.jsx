import React, { useState, useMemo, useEffect } from 'react'
import { useLocalState, useSort } from '../hooks/useLocalState.js'
import { useUnsavedWarning } from '../hooks/useUnsavedWarning.js'
import { useDebouncedValue } from '../hooks/useDebouncedValue.js'
import { useForm, useFieldArray, Controller, useWatch } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { api } from '../assets/js/api.js'
import { clp, fecha, hoy, I } from '../assets/js/helpers.js'
import { Badge, DataPanel, Acciones, Modal, Confirm, Toast, Field, InpCLP, BotonesGuardar, SelCliente, Ic, useToast } from './UI.jsx'
import { useQueryClient } from '@tanstack/react-query'
import { useCotizaciones, useCrearCotizacion, useEditarCotizacion, useBorrarCotizacion } from '../hooks/useQueryApi.js'
import { cotizacionSchema } from '../schemas/validation.js'

// --- 1. FILA DE ÍTEMS ---
const FilaItem = React.memo(({ index, control, register, remove, servicios, setValue, idField }) => {
const item = useWatch({ control, name: `items.${index}` })

  
  const subtotal = useMemo(() => {
    const c = Number(item?.cantidad) || 0
    const p = Number(item?.precio_unitario) || 0
    const d = Number(item?.descuento) || 0
    return (c * p) * (1 - d / 100)
  }, [item?.cantidad, item?.precio_unitario, item?.descuento])

  return (
    <tr key={idField}>
      <td style={{ width: 180 }}>
        <select 
          className="sel" 
          {...register(`items.${index}.servicio_id`)} 
          onChange={(e) => {
            const s = servicios?.find(x => String(x.id) === e.target.value)
            if (s) { 
              setValue(`items.${index}.descripcion`, s.nombre)
              setValue(`items.${index}.precio_unitario`, s.precio)
            }
          }}
        >
          <option value="">— Servicio —</option>
          {servicios?.map(s => <option key={s.id} value={s.id}>{s.nombre}</option>)}
        </select>
      </td>
      <td style={{ minWidth: 200 }}>
        <input className="inp" {...register(`items.${index}.descripcion`)} placeholder="Descripción del servicio..." />
      </td>
      <td style={{ width: 80 }}>
        <input 
          className="inp" type="number" 
          style={{ textAlign: 'center' }} 
          {...register(`items.${index}.cantidad`, { valueAsNumber: true })} 
        />
      </td>
      <td style={{ width: 150 }}>
        <Controller
          name={`items.${index}.precio_unitario`}
          control={control}
          render={({ field }) => (
            <InpCLP 
              value={field.value} 
              onChange={field.onChange} 
              onBlur={field.onBlur}
              inputRef={field.ref} 
            />
          )}
        />
      </td>
      <td style={{ width: 90 }}>
        <div style={{ position: 'relative' }}>
          <input
            className="inp" type="number" 
            style={{ textAlign: 'right', paddingRight: 20 }}
            {...register(`items.${index}.descuento`, { valueAsNumber: true })}
          />
          <span style={{ position: 'absolute', right: 6, top: '50%', transform: 'translateY(-50%)', opacity: 0.4 }}>%</span>
        </div>
      </td>
      <td style={{ width: 120, textAlign: 'right', fontWeight: 700, color: 'var(--acc3)' }}>
        {clp(subtotal)}
      </td>
      <td style={{ width: 50, textAlign: 'center' }}>
        <button type="button" className="ibtn" onClick={() => remove(index)}>
          <Ic d={I.x} size={14} />
        </button>
      </td>
    </tr>
  )
})

// --- 2. FORMULARIO INTERNO ---
const FormularioInterno = ({ initialData, clientes, servicios, proyectos, onSave, onCancel, isPending }) => {
  const { register, handleSubmit, setValue, control, watch, formState: { isDirty } } = useForm({
    resolver: zodResolver(cotizacionSchema),
    defaultValues: initialData
  })

  useUnsavedWarning(isDirty)
  const { fields, append, remove } = useFieldArray({ control, name: 'items' })
  const watchedItems = useWatch({ control, name: 'items' })
  const watchedDescG = useWatch({ control, name: 'descuento_global' })

  const totals = useMemo(() => {
    const sub = (watchedItems || []).reduce((acc, it) => {
      const base = (Number(it?.cantidad) || 0) * (Number(it?.precio_unitario) || 0)
      return acc + (base * (1 - (Number(it?.descuento) || 0) / 100))
    }, 0)
    const desc = sub * (Number(watchedDescG) || 0) / 100
    return { sub, desc, tot: sub - desc }
  }, [watchedItems, watchedDescG])

  return (
    <form onSubmit={handleSubmit(onSave)}>
      {/* FILA 1: Número, Proyecto y Cliente */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 14, flexWrap: 'wrap', alignItems: 'flex-end' }}>
        <div style={{ flex: '1 1 80px' }}>
          <Field label="Número"><input className="inp" {...register('numero')} placeholder="Auto" /></Field>
        </div>
        <div style={{ flex: '1 1 250px' }}>
          <Field label="Proyecto vinculado (Opcional)">
            <select className="sel" {...register('proyecto_id')} onChange={e => {
              const pId = e.target.value;
              setValue('proyecto_id', pId);
              const pr = (proyectos || []).find(p => String(p.id) === pId);
              if (pr) setValue('cliente_id', String(pr.cliente_id));
            }}>
              <option value="">— Ninguno / Nuevo —</option>
              {(proyectos || []).map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </Field>
        </div>
        <div style={{ flex: '1 1 250px' }}>
          <Field label="Cliente" required><SelCliente clientes={clientes} value={watch('cliente_id')} onChange={v => setValue('cliente_id', v)} /></Field>
        </div>
      </div>

      {/* FILA 2: Fecha, Validez y Estado */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 14, flexWrap: 'wrap', alignItems: 'flex-end' }}>
        <div style={{ flex: '1 1 150px' }}>
          <Field label="Fecha de Cotización"><input className="inp" type="date" {...register('fecha')} /></Field>
        </div>
        <div style={{ flex: '1 1 150px' }}>
          <Field label="Válida hasta"><input className="inp" type="date" {...register('fecha_validez')} /></Field>
        </div>
        <div style={{ flex: '1 1 150px' }}>
          <Field label="Estado">
            <select className="sel" {...register('estado')}>
              <option value="Pendiente">Pendiente</option>
              <option value="Aceptada">Aceptada</option>
              <option value="Rechazada">Rechazada</option>
              <option value="Expirada">Expirada</option>
            </select>
          </Field>
        </div>
      </div>

      {/* FILA 3: Descripción (Textarea) */}
      <div style={{ marginBottom: 20 }}>
        <Field label="Descripción / Notas">
          <textarea 
            className="inp" 
            rows="2" 
            {...register('descripcion')} 
            style={{ resize: 'vertical', minHeight: '60px', paddingTop: '8px' }}
            placeholder="Detalles adicionales..."
          />
        </Field>
      </div>

      {/* SECCIÓN ÍTEMS */}
      <div style={{ margin: '24px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h3 style={{ margin: 0, fontSize: 16 }}>Ítems / Servicios</h3>
          <button type="button" className="btn btn-green" onClick={() => append({ descripcion: '', cantidad: 1, precio_unitario: 0, descuento: 0 })}>
            <Ic d={I.plus} size={14} /> Agregar Fila
          </button>
        </div>
        
        <div style={{ width: '100%', overflowX: 'auto', border: '1px solid var(--border)', borderRadius: '8px', background: 'var(--bg2)' }}>
          <table className="tbl" style={{ minWidth: '900px', borderCollapse: 'collapse', margin: 0 }}>
            <thead>
              <tr>
                <th style={{ width: 180 }}>Servicio</th>
                <th style={{ minWidth: 200 }}>Descripción</th>
                <th style={{ width: 80 }}>Cant.</th>
                <th style={{ width: 150 }}>Precio Unit.</th>
                <th style={{ width: 90 }}>Dto %</th>
                <th style={{ width: 120, textAlign: 'right' }}>Subtotal</th>
                <th style={{ width: 50 }}></th>
              </tr>
            </thead>
            <tbody>
              {fields.map((it, i) => (
                <FilaItem key={it.id} idField={it.id} index={i} control={control} register={register} remove={remove} servicios={servicios} setValue={setValue} />
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={5} style={{ textAlign: 'right', color: 'var(--txt2)', padding: '10px' }}>Neto</td>
                <td style={{ textAlign: 'right', fontWeight: 600 }}>{clp(totals.sub)}</td>
                <td></td>
              </tr>
              <tr>
                <td colSpan={4} style={{ textAlign: 'right', color: 'var(--txt2)', padding: '10px' }}>Dcto. Global (%)</td>
                <td><input className="inp" type="number" style={{ textAlign: 'right' }} {...register('descuento_global', { valueAsNumber: true })} /></td>
                <td style={{ textAlign: 'right', color: 'var(--acc2)', fontWeight: 600 }}>-{clp(totals.desc)}</td>
                <td></td>
              </tr>
              <tr style={{ fontSize: 18, borderTop: '2px solid var(--border)' }}>
                <td colSpan={5} style={{ textAlign: 'right', fontWeight: 800, padding: '15px 10px' }}>TOTAL</td>
                <td style={{ textAlign: 'right', fontWeight: 900, color: 'var(--acc3)' }}>{clp(totals.tot)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      <BotonesGuardar onCancel={onCancel} isPending={isPending} />
    </form>
  )
}

// --- 3. COMPONENTE PRINCIPAL ---
export default function Cotizaciones({ clientes, servicios, proyectos }) {
  // 1. ESTADOS (Igual que Clientes)
  const [pagina, setPagina] = useState(1)
  const [busqueda, setBusqueda] = useLocalState('cotizaciones:busqueda', '')
  const [modal, setModal] = useState(false)
  const [formData, setFormData] = useState(null)
  const [del, setDel] = useState(null)
  const [conv, setConv] = useState(null)
  const [toast, showToast] = useToast()

  // Debounce de búsqueda server-side (hook reutilizable)
  const qDebounced = useDebouncedValue(busqueda, 300)
  useEffect(() => { setPagina(1) }, [qDebounced])

  // 2. QUERY (Igual que Clientes)
  const queryClient = useQueryClient()
  const { data: respuesta, isLoading: loading } = useCotizaciones({
    page: pagina,
    q: qDebounced,
  });

  // 2. LISTA FORZADA (Igual que Clientes)
 const lista = Array.isArray(respuesta?.data) 
              ? respuesta.data 
              : (Array.isArray(respuesta) ? respuesta : []);

  // 3. MUTACIONES
  const crearCotizacion = useCrearCotizacion()
  const editarCotizacion = useEditarCotizacion()
  const borrarCotizacion = useBorrarCotizacion()

  // 4. FILTRADO: la búsqueda es server-side (param q). Solo filtramos nulos defensivamente.
  // NOTA: sort sigue client-side y por tanto ordena solo la página actual.
  const filtrados = lista.filter(Boolean)

  const { sorted: filtradosOrdenados, sortKey, sortDir, toggle: sortToggle } = useSort(filtrados)

  // 5. FUNCIONES
  const abrir = async (q) => {
    if (q?.id) {
      const res = await api.getCotizacion(q.id)
      const d = res.data || res
      setFormData({
        ...d,
        cliente_id: String(d.cliente_id),
        proyecto_id: d.proyecto_id ? String(d.proyecto_id) : '',
        items: (d.items || []).map(it => ({ ...it, servicio_id: it.servicio_id ? String(it.servicio_id) : '' }))
      })
    } else {
      setFormData({ numero: '', cliente_id: '', proyecto_id: '', fecha: hoy(), items: [{ descripcion: '', cantidad: 1, precio_unitario: 0, descuento: 0 }], descuento_global: 0, estado: 'Pendiente' })
    }
    setModal(true)
  }

  const duplicar = async (q) => {
    try {
      const res = await api.getCotizacion(q.id)
      const d = res.data || res
      setFormData({
        ...d,
        id: undefined,
        numero: '',
        estado: 'Pendiente',
        fecha: hoy(),
        cliente_id: String(d.cliente_id),
        proyecto_id: d.proyecto_id ? String(d.proyecto_id) : '',
        items: (d.items || []).map(({ id: _id, cotizacion_id: _cid, ...it }) => ({
          ...it,
          servicio_id: it.servicio_id ? String(it.servicio_id) : ''
        }))
      })
      setModal(true)
    } catch (e) { showToast(e.message, 'err') }
  }

  const onSave = async (d) => {
    try {
      d.id ? await editarCotizacion.mutateAsync({ id: d.id, data: d }) : await crearCotizacion.mutateAsync(d)
      setModal(false)
      showToast('Guardado correctamente')
    } catch (e) { showToast(e.message, 'err') }
  }

  return (
    <div>
      {toast && <Toast {...toast} />}

      <DataPanel
        title="Cotizaciones"
        count={filtrados.length} // Usamos filtrados como en Clientes
        busqueda={busqueda} 
        setBusqueda={setBusqueda}
        addLabel="Nueva Cotización"
        onAdd={() => abrir(null)}
        onExcel={() => api.exportar('cotizaciones')}
        loading={loading}
        pagination={{
              actual: pagina,
              totalPaginas: respuesta?.pagination?.total_pages || 1,
              total: respuesta?.pagination?.total || 0,
              perPage: respuesta?.pagination?.per_page || 10, 
              onChange: (n) => setPagina(n)
            }}
        sort={{ key: sortKey, dir: sortDir, toggle: sortToggle }}
        cols={[
          { l: 'Número', sortKey: 'numero' },
          { l: 'Cliente', sortKey: 'cliente_nombre' },
          { l: 'Estado', sortKey: 'estado' },
          { l: 'Total', r: true, sortKey: 'total' },
          { l: 'Fecha', sortKey: 'fecha' },
          { l: 'Acciones', r: true }
        ]}
        rows={filtradosOrdenados.map(q => [
          <span key={`n-${q.id}`} style={{ fontWeight: 700, color: 'var(--acc3)' }}>{q.numero}</span>,
          <strong key={`c-${q.id}`}>{q.cliente_nombre}</strong>,
          <Badge key={`b-${q.id}`} s={q.estado} />,
          <strong key={`t-${q.id}`}>{clp(q.total)}</strong>,
          <span key={`f-${q.id}`} className="tbl-muted">{fecha(q.fecha)}</span>,
          <div key={`a-${q.id}`} style={{ display: 'flex', justifyContent: 'flex-end', gap: 5 }}>
            {q.estado === 'Aceptada' && !q.proyecto_id && (
              <button type="button" className="ibtn" onClick={() => setConv(q)} title="Generar Proyecto" style={{ color: 'var(--acc2)' }}>
                <Ic d={I.plus} size={14} />
              </button>
            )}
            <button type="button" className="ibtn" onClick={() => duplicar(q)} title="Duplicar cotización">
              <Ic d={I.copy} size={14} />
            </button>
            <Acciones onVer={async () => { try { await api.pdfCotizacion(q.id) } catch (e) { showToast(e.message || 'No se pudo abrir el PDF', 'err') } }} onEdit={() => abrir(q)} onDel={() => setDel(q.id)} />
          </div>
        ])}
      />

      {modal && (
      <Modal title={formData?.id ? 'Editar Cotización' : 'Nueva Cotización'} onClose={() => setModal(false)} xl>
        <FormularioInterno
          initialData={formData}
          // FORZAMOS que siempre sean arrays limpios:
          clientes={clientes?.data || clientes || []}
          servicios={servicios?.data || servicios || []}
          proyectos={proyectos?.data || proyectos || []} 
          onSave={onSave}
          onCancel={() => setModal(false)}
          isPending={crearCotizacion.isPending || editarCotizacion.isPending}
        />
      </Modal>
    )}

      {del && <Confirm msg="¿Eliminar esta cotización?" onSi={async () => { await borrarCotizacion.mutateAsync(del); setDel(null); showToast('Eliminado') }} onNo={() => setDel(null)} />}
      
      {conv && (
        <Confirm 
          msg="¿Generar un proyecto desde esta cotización?" 
          onSi={async () => { 
            try { 
              await api.convertirCotizacion(conv.id)
              queryClient.invalidateQueries({ queryKey: ['cotizaciones'] })
              setConv(null); showToast('Proyecto creado!')
            } catch (e) { showToast(e.message, 'err') }
          }} 
          onNo={() => setConv(null)} 
        />
      )}
    </div>
  )
}