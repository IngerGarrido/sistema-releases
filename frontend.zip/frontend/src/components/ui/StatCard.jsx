import React from 'react'
import { Ic } from './Ic.jsx'

export function StatCard({ label, value, icon, color, sub, trend }) {
  return (
    <div className="stat-card">
      <div className="sc-lbl">{label}
        <div className="sc-ico" style={{ background:color+'18', color }}><Ic d={icon} size={14}/></div>
      </div>
      <div className="sc-val">{value}</div>
      {(sub || trend) && (
        <div className="sc-sub">
          {trend && trend.value && (
            <span className={`stat-trend stat-trend--${trend.direction === 'down' ? 'down' : 'up'}`}>
              <span aria-hidden="true">{trend.direction === 'down' ? '▼' : '▲'}</span>
              {trend.value}
            </span>
          )}
          {trend && trend.period && <span className="stat-trend-period">{trend.period}</span>}
          {sub && (!trend || !trend.value) && sub}
        </div>
      )}
    </div>
  )
}
