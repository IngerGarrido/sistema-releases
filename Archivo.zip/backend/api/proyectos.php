<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    require_once __DIR__ . '/../config.php';
    cors();
    $db = getDB();
    $user = requireAuth();
    $method = $_SERVER['REQUEST_METHOD'];
    // Soporte para method override via query string (POST con _method=PUT)
    if ($method === 'POST' && isset($_GET['_method'])) {
        $method = strtoupper($_GET['_method']);
    }
    $id = isset($_GET['id']) ? (int)$_GET['id'] : null;
    if (!$id) {
        $path = explode('/', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
        $last = end($path);
        $id = is_numeric($last) ? (int)$last : null;
    }

    // Detectar acción especial
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $esRestore = strpos($uri, 'restore') !== false || isset($_GET['restore']);
    $esHard = isset($_GET['hard']) && $_GET['hard'] == '1';
    $esPapelera = isset($_GET['papelera']) && $_GET['papelera'] == '1';

    // Helper para limpiar strings
    $clean = function($str) { return trim((string)($str ?? '')); };

    // --- GET: LISTAR ---
    // Soporta paginación: ?page=X&per_page=Y
    if ($method === 'GET') {
        $where = $esPapelera ? "WHERE p.deleted_at IS NOT NULL" : "WHERE p.deleted_at IS NULL";

        // Búsqueda server-side
        $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
        $params = [];
        if ($q !== '') {
            $where .= " AND (p.nombre LIKE ? OR p.tipo_proyecto LIKE ? OR c.nombre LIKE ? OR c.nombre_agencia LIKE ?)";
            $like = '%' . $q . '%';
            $params[] = $like; $params[] = $like; $params[] = $like; $params[] = $like;
        }

        // Parámetros de paginación
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : null;
        $per_page = isset($_GET['per_page']) ? max(1, min(100, (int)$_GET['per_page'])) : null;

        // Contar total (necesita JOIN si filtramos por cliente)
        $countSql = "SELECT COUNT(*) FROM proyectos p LEFT JOIN clientes c ON p.cliente_id = c.id {$where}";
        $countStmt = $db->prepare($countSql);
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $sql = "SELECT p.*, c.nombre as cliente_nombre_real, c.nombre_agencia,
                       s.nombre AS sitio_nombre, s.url_principal AS sitio_url
                FROM proyectos p
                LEFT JOIN clientes c ON p.cliente_id = c.id
                LEFT JOIN sitios s ON p.sitio_id = s.id
                {$where}
                ORDER BY p.id DESC";

        // Aplicar paginación
        if ($page && $per_page) {
            $offset = ($page - 1) * $per_page;
            $sql .= " LIMIT {$per_page} OFFSET {$offset}";
        }

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Formatear para el frontend
        foreach ($data as &$r) {
            $r['id'] = (int)$r['id'];
            $r['cliente_id'] = (int)$r['cliente_id'];
            $r['sitio_id'] = $r['sitio_id'] ? (int)$r['sitio_id'] : null;
            $r['servicio_id'] = $r['servicio_id'] ? (int)$r['servicio_id'] : null;
            $r['presupuesto'] = (int)$r['presupuesto'];
            $r['cliente_nombre'] = !empty($r['nombre_agencia']) ? $r['nombre_agencia'] : $r['cliente_nombre_real'];
        }
        
        // Responder con o sin paginación
        if ($page && $per_page) {
            echo json_encode([
                'ok' => true, 
                'data' => $data,
                'pagination' => [
                    'page' => $page,
                    'per_page' => $per_page,
                    'total' => $total,
                    'total_pages' => (int)ceil($total / $per_page)
                ]
            ]);
        } else {
            echo json_encode(['ok' => true, 'data' => $data]);
        }
        exit;
    }

    // --- RESTAURAR PROYECTO ---
    // DEBE IR ANTES de POST/CREAR para que no se confunda
    if ($method === 'POST' && $esRestore && $id) {
        $stmt = $db->prepare("UPDATE proyectos SET deleted_at = NULL WHERE id = ? AND deleted_at IS NOT NULL");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() > 0) {
            audit($db, $user['id'], 'RESTORE', 'proyectos', "Restauró proyecto #{$id}", $id);
            echo json_encode(['ok' => true, 'message' => 'Proyecto restaurado']);
        } else {
            echo json_encode(['ok' => false, 'error' => 'Proyecto no encontrado o no estaba eliminado']);
        }
        exit;
    }

    // --- POST: CREAR ---
    if ($method === 'POST') {
        $b = body();
        $sql = "INSERT INTO proyectos (cliente_id, sitio_id, servicio_id, nombre, descripcion, tipo_proyecto, estado, fecha_inicio, fecha_termino, presupuesto, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        $db->prepare($sql)->execute([
            (int)$b['cliente_id'],
            !empty($b['sitio_id']) ? (int)$b['sitio_id'] : null,
            !empty($b['servicio_id']) ? (int)$b['servicio_id'] : null,
            $clean($b['nombre']),
            $clean($b['descripcion']),
            $clean($b['tipo_proyecto']),
            $clean($b['estado'] ?? 'Cotizado'),
            !empty($b['fecha_inicio']) ? $b['fecha_inicio'] : null,
            !empty($b['fecha_termino']) ? $b['fecha_termino'] : null,
            (int)($b['presupuesto'] ?? 0)
        ]);
        $proyecto_id = $db->lastInsertId();
        
        audit($db, $user['id'], 'CREATE', 'proyectos', "Creó proyecto #{$proyecto_id}: {$b['nombre']}", $proyecto_id);
        
        echo json_encode(['ok' => true, 'id' => $proyecto_id]);
        exit;
    }

    // --- EDITAR PROYECTO (PUT) ---
        if ($method === 'PUT' && $id) {
            $b = body();
            // 1. Preparamos el SQL con los 10 campos (incluyendo servicio_id y el WHERE)
            $sql = "UPDATE proyectos SET
                    cliente_id = ?,
                    sitio_id = ?,
                    servicio_id = ?,
                    nombre = ?,
                    descripcion = ?,
                    tipo_proyecto = ?,
                    estado = ?,
                    fecha_inicio = ?,
                    fecha_termino = ?,
                    presupuesto = ?,
                    updated_at = NOW()
                    WHERE id = ? AND deleted_at IS NULL";

            $stmt = $db->prepare($sql);

            $stmt->execute([
                (int)$b['cliente_id'],
                !empty($b['sitio_id']) ? (int)$b['sitio_id'] : null,
                !empty($b['servicio_id']) ? (int)$b['servicio_id'] : null,
                $clean($b['nombre']),
                $clean($b['descripcion']),
                $clean($b['tipo_proyecto']),
                $clean($b['estado']),
                !empty($b['fecha_inicio']) ? $b['fecha_inicio'] : null,
                !empty($b['fecha_termino']) ? $b['fecha_termino'] : null,
                (int)($b['presupuesto'] ?? 0),
                (int)$id // El ID del proyecto para el WHERE
            ]);
            
            audit($db, $user['id'], 'UPDATE', 'proyectos', "Editó proyecto #{$id}: {$b['nombre']}", $id);
            
            echo json_encode(['ok' => true]);
            exit;
        }

    // --- DELETE ---
    if ($method === 'DELETE' && $id) {
        $info = $db->prepare("SELECT nombre FROM proyectos WHERE id = ?");
        $info->execute([$id]);
        $proy = $info->fetch();
        
        if (!$proy) {
            echo json_encode(['ok' => false, 'error' => 'Proyecto no encontrado']);
            exit;
        }
        
        if ($esHard) {
            $db->prepare("DELETE FROM proyectos WHERE id = ?")->execute([$id]);
            audit($db, $user['id'], 'HARD_DELETE', 'proyectos', "Eliminó PERMANENTEMENTE proyecto #{$id}: " . $proy['nombre'], $id);
            echo json_encode(['ok' => true, 'message' => 'Proyecto eliminado permanentemente']);
        } else {
            $db->prepare("UPDATE proyectos SET deleted_at = NOW() WHERE id = ? AND deleted_at IS NULL")->execute([$id]);
            audit($db, $user['id'], 'SOFT_DELETE', 'proyectos', "Envió a papelera proyecto #{$id}: " . $proy['nombre'], $id);
            echo json_encode(['ok' => true, 'message' => 'Proyecto enviado a papelera']);
        }
        exit;
    }

} catch (Throwable $e) {
    if (function_exists('logError')) {
        logError('Error en proyectos.php', ['message' => $e->getMessage(), 'file' => $e->getFile(), 'line' => $e->getLine()]);
    }
    errSafe($e, 500);
}