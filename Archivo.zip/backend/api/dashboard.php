<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    require_once __DIR__ . '/../config.php';
    cors();
    $db = getDB();
    $user = requireAuth();  // Proteger dashboard
    $db->exec("SET NAMES utf8mb4");

    $out = [];

    // Conteos básicos: Solo contamos lo que existe
    $out['total_cotizaciones'] = (int)$db->query("SELECT COUNT(*) FROM cotizaciones where estado = 'Pendiente' AND deleted_at IS NULL")->fetchColumn();
    $out['proyectos_activos'] = (int)$db->query("SELECT COUNT(*) FROM proyectos WHERE estado = 'En curso' AND deleted_at IS NULL")->fetchColumn();

    $periodo = $_GET['periodo'] ?? 'mes_actual';
    $where_fecha = "";

    if ($periodo === 'mes_actual') {
        $where_fecha = " AND MONTH(pc.pago_fecha) = MONTH(CURDATE()) AND YEAR(pc.pago_fecha) = YEAR(CURDATE())";
        $where_fecha_pend = " AND MONTH(pc.boleta_fecha) = MONTH(CURDATE()) AND YEAR(pc.boleta_fecha) = YEAR(CURDATE())";
    } elseif ($periodo === 'mes_pasado') {
        $where_fecha = " AND MONTH(pc.pago_fecha) = MONTH(STR_TO_DATE(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m-%d'))";
        $where_fecha_pend = " AND MONTH(pc.boleta_fecha) = MONTH(STR_TO_DATE(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m-%d'))";
    } elseif ($periodo === 'anio') {
        $where_fecha = " AND YEAR(pc.pago_fecha) = YEAR(CURDATE())";
        $where_fecha_pend = " AND YEAR(pc.boleta_fecha) = YEAR(CURDATE())";
    }

    // Luego aplicas ese $where_fecha en tus sumatorias:
    $out['total_cobrado'] = (int)($db->query("
        SELECT COALESCE(SUM(pc.pago_monto), 0) 
        FROM pago_cuotas pc
        INNER JOIN pagos pg ON pg.id = pc.pago_id 
        WHERE pc.estado = 'Pagado' AND pg.deleted_at IS NULL $where_fecha
    ")->fetchColumn());

    // TOTAL PENDIENTE: Solo sumamos cuotas de pagos que aún existen
    $out['total_pendiente'] = (int)($db->query("
        SELECT COALESCE(SUM(pc.boleta_monto), 0) 
        FROM pago_cuotas pc
        INNER JOIN pagos pg ON pg.id = pc.pago_id
        WHERE pc.estado = 'Pendiente' AND pg.deleted_at IS NULL
    ")->fetchColumn());

    // Boletas pagadas para el promedio (con INNER JOIN para asegurar que el pago existe)
    $out['boletas_pagadas'] = $db->query("
        SELECT pc.pago_monto, pc.tipo_pago, pc.boleta_fecha, pc.pago_fecha 
        FROM pago_cuotas pc
        INNER JOIN pagos pg ON pg.id = pc.pago_id
        WHERE pc.estado = 'Pagado' AND pg.deleted_at IS NULL
    ")->fetchAll(PDO::FETCH_ASSOC) ?: [];

    // Proyectos por vencer (Próximos 30 días)
    $resV = $db->query("
        SELECT p.id, p.nombre, p.estado, c.nombre as cliente, DATEDIFF(p.fecha_termino, CURDATE()) as dias
        FROM proyectos p
        INNER JOIN clientes c ON p.cliente_id = c.id
        WHERE p.estado != 'Terminado' AND p.fecha_termino IS NOT NULL AND p.deleted_at IS NULL
        AND DATEDIFF(p.fecha_termino, CURDATE()) BETWEEN 0 AND 30
        ORDER BY p.fecha_termino ASC LIMIT 5
    ")->fetchAll(PDO::FETCH_ASSOC);

    $out['proyectos_por_vencer'] = [];
    foreach ($resV as $v) {
        $out['proyectos_por_vencer'][] = [
            'id' => (string)$v['id'],
            'nombre' => $v['nombre'],
            'estado' => $v['estado'],
            'cliente_nombre' => $v['cliente'],
            'dias_restantes' => (int)$v['dias']
        ];
    }

    // Actividad reciente (Solo si hay proyectos)
    $out['proyectos_recientes'] = $db->query("SELECT id, nombre, estado FROM proyectos WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC) ?: [];

    // Boletas pendientes: Cambiamos LEFT JOIN por INNER JOIN
    // Así, si borraste el pago, la boleta "huérfana" desaparece del dashboard
    $resB = $db->query("
        SELECT pc.id, pc.boleta_fecha, pc.boleta_monto, p.nombre as proyecto_txt
        FROM pago_cuotas pc
        INNER JOIN pagos pg ON pg.id = pc.pago_id
        INNER JOIN proyectos p ON p.id = pg.proyecto_id
        WHERE pc.estado = 'Pendiente' AND pg.deleted_at IS NULL AND p.deleted_at IS NULL
        ORDER BY pc.boleta_fecha ASC LIMIT 10
    ")->fetchAll(PDO::FETCH_ASSOC);

    $out['boletas_pendientes'] = [];
    foreach ($resB as $b) {
        $out['boletas_pendientes'][] = [
            'id' => $b['id'],
            'boleta_fecha' => $b['boleta_fecha'],
            'boleta_monto' => (int)$b['boleta_monto'],
            'proyecto_nombre' => $b['proyecto_txt']
        ];
    }

    // DATOS PARA GRÁFICOS
    
    // 1. Ingresos mensuales (últimos 6 meses) - Simplificado para evitar ONLY_FULL_GROUP_BY
    try {
        $resIng = $db->query("
            SELECT 
                YEAR(pc.pago_fecha) as anio,
                MONTH(pc.pago_fecha) as mes_num,
                CONCAT(MONTHNAME(pc.pago_fecha), ' ', YEAR(pc.pago_fecha)) as mes_nombre,
                COALESCE(SUM(pc.pago_monto), 0) as total
            FROM pago_cuotas pc
            INNER JOIN pagos pg ON pg.id = pc.pago_id
            WHERE pc.estado = 'Pagado' 
              AND pg.deleted_at IS NULL
              AND pc.pago_fecha >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            GROUP BY YEAR(pc.pago_fecha), MONTH(pc.pago_fecha)
            ORDER BY anio ASC, mes_num ASC
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        // Si falla, devolver array vacío
        $resIng = [];
    }

    // Meta mensual (default 500000)
    $metaMensual = 500000;
    try {
        $metaRow = $db->query("SELECT valor FROM configuracion WHERE clave = 'meta_mensual' LIMIT 1")->fetchColumn();
        if ($metaRow) $metaMensual = (int)$metaRow;
    } catch (Exception $e) {
        // Si falla, usar default
    }
    
    $out['ingresos_mensuales'] = [];
    foreach ($resIng as $ing) {
        $out['ingresos_mensuales'][] = [
            'mes' => $ing['mes_nombre'],
            'total' => (int)$ing['total'],
            'meta' => $metaMensual
        ];
    }

    // 2. Proyectos por estado
    $resEst = $db->query("
        SELECT 
            estado,
            COUNT(*) as cantidad
        FROM proyectos
        WHERE deleted_at IS NULL
        GROUP BY estado
        ORDER BY cantidad DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    $out['proyectos_por_estado'] = [];
    foreach ($resEst as $est) {
        $out['proyectos_por_estado'][] = [
            'estado' => $est['estado'],
            'cantidad' => (int)$est['cantidad']
        ];
    }

    // 3. Próximas boletas (para notificaciones)
    $out['proximas_boletas'] = $db->query("
        SELECT pc.boleta_fecha, p.nombre as proyecto_txt
        FROM pago_cuotas pc
        INNER JOIN pagos pg ON pg.id = pc.pago_id
        INNER JOIN proyectos p ON p.id = pg.proyecto_id
        WHERE pc.estado = 'Pendiente' AND pg.deleted_at IS NULL
        ORDER BY pc.boleta_fecha ASC
        LIMIT 20
    ")->fetchAll(PDO::FETCH_ASSOC) ?: [];

    // ============================================================
    // KPIs ADICIONALES (Sprint 4)
    // ============================================================

    // 4. Tasa de conversión: % cotizaciones (últimos 90 días) que se convirtieron
    //    a proyecto. Una cotización está "convertida" si tiene proyecto_id NOT NULL
    //    o estado = 'Aceptada' (ver cotizaciones_convertir.php).
    try {
        $totCot = (int)$db->query("
            SELECT COUNT(*) FROM cotizaciones
            WHERE deleted_at IS NULL
              AND fecha >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
        ")->fetchColumn();
        $convCot = (int)$db->query("
            SELECT COUNT(*) FROM cotizaciones
            WHERE deleted_at IS NULL
              AND fecha >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
              AND (proyecto_id IS NOT NULL OR estado = 'Aceptada')
        ")->fetchColumn();
        $out['tasa_conversion'] = [
            'total'         => $totCot,
            'convertidas'   => $convCot,
            'porcentaje'    => $totCot > 0 ? round(($convCot / $totCot) * 100, 1) : 0
        ];
    } catch (Exception $e) {
        $out['tasa_conversion'] = null;
    }

    // 5. Ticket promedio: AVG(total) de cotizaciones aprobadas/convertidas
    //    últimos 90 días. Total se calcula sumando items.
    try {
        $row = $db->query("
            SELECT AVG(t.total) as prom, COUNT(*) as n
            FROM (
                SELECT c.id,
                       COALESCE((SELECT SUM(ci.cantidad * ci.precio_unitario)
                                 FROM cotizacion_items ci WHERE ci.cotizacion_id = c.id), 0) as total
                FROM cotizaciones c
                WHERE c.deleted_at IS NULL
                  AND c.fecha >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
                  AND (c.proyecto_id IS NOT NULL OR c.estado = 'Aceptada')
            ) t
        ")->fetch(PDO::FETCH_ASSOC);
        $out['ticket_promedio'] = [
            'monto' => (int)round($row['prom'] ?? 0),
            'n'     => (int)($row['n'] ?? 0)
        ];
    } catch (Exception $e) {
        $out['ticket_promedio'] = null;
    }

    // 6. Top 5 clientes por suma de pagos cobrados últimos 6 meses
    try {
        $top = $db->query("
            SELECT c.id, c.nombre, SUM(pc.pago_monto) as total
            FROM pago_cuotas pc
            INNER JOIN pagos pg ON pg.id = pc.pago_id
            INNER JOIN proyectos p ON p.id = pg.proyecto_id
            INNER JOIN clientes c ON c.id = p.cliente_id
            WHERE pc.estado = 'Pagado'
              AND pg.deleted_at IS NULL
              AND p.deleted_at IS NULL
              AND c.deleted_at IS NULL
              AND pc.pago_fecha >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            GROUP BY c.id, c.nombre
            ORDER BY total DESC
            LIMIT 5
        ")->fetchAll(PDO::FETCH_ASSOC);
        $out['top_clientes'] = array_map(function($r){
            return [
                'id'     => (int)$r['id'],
                'nombre' => $r['nombre'],
                'total'  => (int)$r['total']
            ];
        }, $top);
    } catch (Exception $e) {
        $out['top_clientes'] = [];
    }

    // 7. Aging de cobros: buckets por días desde boleta_fecha (cuota pendiente)
    //    boleta_fecha cumple el rol de "fecha_emision" en este schema.
    try {
        $agingRows = $db->query("
            SELECT
                CASE
                    WHEN DATEDIFF(CURDATE(), pc.boleta_fecha) BETWEEN 0 AND 30 THEN '0-30'
                    WHEN DATEDIFF(CURDATE(), pc.boleta_fecha) BETWEEN 31 AND 60 THEN '31-60'
                    WHEN DATEDIFF(CURDATE(), pc.boleta_fecha) BETWEEN 61 AND 90 THEN '61-90'
                    WHEN DATEDIFF(CURDATE(), pc.boleta_fecha) > 90 THEN '+90'
                    ELSE 'futuro'
                END as bucket,
                COUNT(*) as cantidad,
                SUM(pc.boleta_monto) as total
            FROM pago_cuotas pc
            INNER JOIN pagos pg ON pg.id = pc.pago_id
            WHERE pc.estado = 'Pendiente'
              AND pg.deleted_at IS NULL
              AND pc.boleta_fecha IS NOT NULL
            GROUP BY bucket
        ")->fetchAll(PDO::FETCH_ASSOC);

        $aging = [
            '0-30'  => ['cantidad' => 0, 'total' => 0],
            '31-60' => ['cantidad' => 0, 'total' => 0],
            '61-90' => ['cantidad' => 0, 'total' => 0],
            '+90'   => ['cantidad' => 0, 'total' => 0],
        ];
        foreach ($agingRows as $r) {
            if ($r['bucket'] === 'futuro') continue;
            $aging[$r['bucket']] = [
                'cantidad' => (int)$r['cantidad'],
                'total'    => (int)$r['total']
            ];
        }
        $out['aging_cobros'] = $aging;
    } catch (Exception $e) {
        $out['aging_cobros'] = null;
    }

    // 8. Cotizaciones por mes (últimos 6 meses): cantidad y suma
    try {
        $cpm = $db->query("
            SELECT
                YEAR(c.fecha) as anio,
                MONTH(c.fecha) as mes_num,
                CONCAT(MONTHNAME(c.fecha), ' ', YEAR(c.fecha)) as mes_nombre,
                COUNT(*) as cantidad,
                COALESCE(SUM((SELECT SUM(ci.cantidad * ci.precio_unitario)
                              FROM cotizacion_items ci WHERE ci.cotizacion_id = c.id)), 0) as total
            FROM cotizaciones c
            WHERE c.deleted_at IS NULL
              AND c.fecha >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            GROUP BY YEAR(c.fecha), MONTH(c.fecha)
            ORDER BY anio ASC, mes_num ASC
        ")->fetchAll(PDO::FETCH_ASSOC);
        $out['cotizaciones_por_mes'] = array_map(function($r){
            return [
                'mes'      => $r['mes_nombre'],
                'cantidad' => (int)$r['cantidad'],
                'total'    => (int)$r['total']
            ];
        }, $cpm);
    } catch (Exception $e) {
        $out['cotizaciones_por_mes'] = [];
    }

    echo json_encode(['ok' => true, 'data' => $out], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    errSafe($e, 500);
}