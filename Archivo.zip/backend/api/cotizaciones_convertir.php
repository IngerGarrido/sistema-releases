<?php
require_once '../config.php';
cors();
$db = getDB();
$user = requireAuth();

$input = body();
$cotizacion_id = $input['id'] ?? null;

if (!$cotizacion_id) {
    err('ID de cotización requerido');
}

try {
    // 1. Obtener datos de la cotización
    $stmt = $db->prepare("SELECT * FROM cotizaciones WHERE id = ?");
    $stmt->execute([$cotizacion_id]);
    $cot = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$cot) {
        err('Cotización no encontrada');
    }

    // ============================================================
    // 🛡️ FILTRO DE SEGURIDAD (NUEVO)
    // Si ya tiene un proyecto_id asignado, detenemos el proceso
    // ============================================================
    if (!empty($cot['proyecto_id'])) {
        err('Esta cotización ya fue convertida a un proyecto anteriormente.');
    }
    // ============================================================

    // VALIDACIÓN CRÍTICA: Definir un nombre para el proyecto
    $nombreProyecto = "";
    if (!empty($cot['titulo'])) {
        $nombreProyecto = $cot['titulo'];
    } elseif (!empty($cot['numero'])) {
        $nombreProyecto = "Proyecto " . $cot['numero'];
    } else {
        $nombreProyecto = "Proyecto desde Cotización #" . $cot['id'];
    }

    $db->beginTransaction();

    // 2. Crear el Proyecto
    $stmt = $db->prepare("
        INSERT INTO proyectos (nombre, cliente_id, presupuesto, estado, fecha_inicio) 
        VALUES (?, ?, ?, 'En curso', NOW())
    ");
    
    $stmt->execute([
        $nombreProyecto,
        $cot['cliente_id'],
        $cot['total'] ?? 0
    ]);
    
    $nuevo_proyecto_id = $db->lastInsertId();

    // 3. Vincular la cotización al proyecto y actualizar su estado
    // Importante: Aquí grabamos el ID para que el filtro de arriba funcione la próxima vez
    $stmt = $db->prepare("
        UPDATE cotizaciones 
        SET proyecto_id = ?, estado = 'Aceptada' 
        WHERE id = ?
    ");
    $stmt->execute([$nuevo_proyecto_id, $cotizacion_id]);

    $db->commit();
    
    ok(['proyecto_id' => $nuevo_proyecto_id]);

} catch (Exception $e) {
    if ($db && $db->inTransaction()) {
        $db->rollBack();
    }
    err("Error al convertir: " . $e->getMessage());
}