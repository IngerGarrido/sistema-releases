import { useState } from 'react'
import { api, session, resolveUploadUrl } from '../assets/js/api.js'
import { Ic, Modal, Toast } from './UI.jsx'
import { I }  from '../assets/js/helpers.js'

export default function Login({ onLogin, panelCfg={} }) {
  const [form,setForm]=useState({email:'',password:''})
  const [err,setErr]=useState('')
  const [loading,setLoading]=useState(false)
  
  // Recuperación de contraseña
  const [showRecuperar, setShowRecuperar] = useState(false)
  const [emailRecuperar, setEmailRecuperar] = useState('')
  const [loadingRecuperar, setLoadingRecuperar] = useState(false)
  const [msgRecuperar, setMsgRecuperar] = useState('')

  const bg1 = panelCfg.sidebar_bg   || '#1e2340'
  const bg2 = panelCfg.login_color_boton || panelCfg.color_activo || '#3b5bdb'

  const loginTitulo    = panelCfg.login_titulo    || panelCfg.nombre_empresa || 'Mi Sistema'
  const loginSubtitulo = panelCfg.login_subtitulo || 'Inicia sesión para continuar'
  const loginBg        = panelCfg.login_color_fondo || ''
  const loginImgFondo  = panelCfg.login_imagen_fondo || ''
  const mostrarLogo    = panelCfg.login_mostrar_logo === '0' ? false : true

  const rootStyle = loginImgFondo
    ? { backgroundImage: `url(${resolveUploadUrl(loginImgFondo)})`, backgroundSize:'cover', backgroundPosition:'center' }
    : loginBg ? { background: loginBg } : {}

  const submit = async e => {
    e.preventDefault(); setErr(''); setLoading(true)
    try {
      const d = await api.login(form)
      if (!d?.token) throw new Error('Respuesta inesperada del servidor')
      session.setToken(d.token)
      session.setUser(d.usuario || d)
      onLogin(d.usuario || d)
    } catch(e) { setErr(e.message) }
    setLoading(false)
  }

  return (
    <div className="login-root" style={rootStyle}>
      <div className="login-card">
        <div className="login-head">
          {mostrarLogo && (panelCfg.logo_url
            ? <img src={resolveUploadUrl(panelCfg.logo_url)} alt={`Logo de ${loginTitulo}`} className="login-logo-img" style={{ filter: 'none' }}/>
            : <div className="login-icon" style={{ background:bg2 }}><Ic d={I.ok} size={22} stroke="#fff"/></div>
          )}
          <h1 className="login-title">{loginTitulo}</h1>
          <p className="login-sub">{loginSubtitulo}</p>
        </div>
        {err && <div className="login-error">{err}</div>}
        <form onSubmit={submit}>
          <div className="field" style={{ marginBottom:14 }}>
            <label className="field-lbl">Email</label>
            <input className="inp" type="email" value={form.email}
              onChange={e=>setForm(p=>({...p,email:e.target.value}))} placeholder="tu@email.com" required autoFocus/>
          </div>
          <div className="field" style={{ marginBottom:12 }}>
            <label className="field-lbl">Contraseña</label>
            <input className="inp" type="password" value={form.password}
              onChange={e=>setForm(p=>({...p,password:e.target.value}))} placeholder="••••••••" required/>
          </div>
          <div style={{ textAlign: 'right', marginBottom: 20 }}>
            <button 
              type="button" 
              onClick={() => setShowRecuperar(true)}
              style={{ 
                background: 'none', 
                border: 'none', 
                color: bg2, 
                fontSize: 12, 
                cursor: 'pointer',
                fontFamily: 'var(--font)',
                textDecoration: 'underline'
              }}
            >
              ¿Olvidaste tu contraseña?
            </button>
          </div>
          <button type="submit" disabled={loading} className="login-submit btn-primary"
            style={{ background: bg2 }}>
            {loading?'Ingresando…':'Ingresar'}
          </button>
        </form>
        
        {/* Modal Recuperar Contraseña */}
        {showRecuperar && (
          <Modal title="Recuperar Contraseña" onClose={() => { setShowRecuperar(false); setMsgRecuperar('') }}>
            <div style={{ padding: '4px 0' }}>
              {msgRecuperar ? (
                <div style={{
                  padding: 16,
                  background: msgRecuperar.includes('Error') ? 'var(--err-bg)' : 'var(--success-bg)',
                  borderRadius: 8, fontSize: 14,
                  color: msgRecuperar.includes('Error') ? '#c62828' : 'var(--success)',
                  marginBottom: 16
                }}>
                  {msgRecuperar}
                </div>
              ) : (
                <>
                  <p style={{ fontSize: 13, color: 'var(--txt2)', marginBottom: 16, lineHeight: 1.5 }}>
                    Ingresa tu email y te enviaremos instrucciones para restablecer tu contraseña.
                  </p>
                  <div className="field" style={{ marginBottom: 16 }}>
                    <label className="field-lbl">Email</label>
                    <input
                      className="inp" type="email" value={emailRecuperar}
                      onChange={e => setEmailRecuperar(e.target.value)}
                      placeholder="tu@email.com" autoFocus
                    />
                  </div>
                  <button
                    className="btn btn-green" style={{ width: '100%' }}
                    disabled={loadingRecuperar || !emailRecuperar}
                    onClick={async () => {
                      setLoadingRecuperar(true)
                      try {
                        const res = await api.recuperarPassword(emailRecuperar)
                        setMsgRecuperar(res?.message || 'Revisa tu email para continuar.')
                      } catch(e) {
                        setMsgRecuperar('Error: ' + (e?.message || 'Error al procesar'))
                      }
                      setLoadingRecuperar(false)
                    }}
                  >
                    {loadingRecuperar ? 'Enviando…' : 'Enviar instrucciones'}
                  </button>
                </>
              )}
            </div>
          </Modal>
        )}
      </div>
    </div>
  )
}
