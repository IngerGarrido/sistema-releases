import React from 'react'
import { I } from '../../assets/js/helpers.js'
import { Ic } from './Ic.jsx'

/* DataPanel — wrapper completo con cabecera, buscador integrado, filtros y tabla
   Úsalo en lugar de PageHeader + pills + Tabla por separado cuando quieras
   la maquetación exacta de la imagen de referencia */
export const Pagination = React.memo(function Pagination({ pagination, onPageChange, onPrev, onNext, onPerPageChange }) {
  if (!pagination) return null;

  const page = Number(pagination.actual || 1);
  const total_pages = Number(pagination.totalPaginas || 1);
  const total = Number(pagination.total || 0);
  const per_page = Number(pagination.perPage || 10);

  // Solo ocultamos cuando no hay registros en absoluto.
  // Si el llamante pasa el prop `pagination`, mostramos la barra (consistencia entre pestañas).
  if (total === 0) return null;

  // CÁLCULO SEGURO:
  // start: Si no hay registros es 0, si no, calculamos el inicio real
  const start = total === 0 ? 0 : (page - 1) * per_page + 1;

  // end: El menor entre el final teórico (page * per_page) y el total real
  const end = Math.min(page * per_page, total);

  // Seguridad extra: Si por error la página es mayor a la posible,
  // no permitimos que start sea mayor que end
  const displayStart = start > end ? end : start;

  const getPageNumbers = () => {
    const pages = [];
    let startPage = Math.max(1, page - 2);
    let endPage = Math.min(total_pages, startPage + 4);

    if (endPage - startPage < 4) {
      startPage = Math.max(1, endPage - 4);
    }

    for (let i = Math.max(1, startPage); i <= endPage; i++) {
      pages.push(i);
    }
    return pages;
  };

  // 5. El RETURN debe estar dentro de las llaves de la función
  return (
    <div className="pagination" role="navigation" aria-label="Paginación">
      <div className="pagination-info" aria-live="polite">
        Mostrando {displayStart}-{end} de {total} registros
      </div>
      <div className="pagination-controls">
        {onPerPageChange && (
          <select
            className="pagination-perpage"
            value={per_page}
            onChange={e => { onPerPageChange(Number(e.target.value)); onPageChange && onPageChange(1) }}
            aria-label="Registros por página"
          >
            {[10, 25, 50, 100].map(n => <option key={n} value={n}>{n} por página</option>)}
          </select>
        )}
        <button
          className="pagination-btn"
          onClick={onPrev}
          disabled={page <= 1}
          type="button"
          aria-label="Página anterior"
        >
          <Ic d={I.back} size={14}/>
        </button>

        {getPageNumbers().map(p => (
          <button
            key={p}
            className={`pagination-btn ${p === page ? 'active' : ''}`}
            onClick={() => onPageChange(p)}
            type="button"
            aria-label={`Página ${p}`}
            aria-current={p === page ? 'page' : undefined}
          >
            {p}
          </button>
        ))}

        <button
          className="pagination-btn"
          onClick={onNext}
          disabled={page >= total_pages}
          type="button"
          aria-label="Página siguiente"
        >
          <Ic d={I.right} size={14}/>
        </button>
      </div>
    </div>
  );
})
