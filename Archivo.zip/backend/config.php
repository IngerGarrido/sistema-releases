<?php
// ============================================================
// Cargar variables de entorno desde .env
// ============================================================
function loadEnv($path) {
    if (!file_exists($path)) return;
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        if (!array_key_exists($name, $_SERVER) && !array_key_exists($name, $_ENV)) {
            putenv("$name=$value");
            $_ENV[$name] = $value;
            $_SERVER[$name] = $value;
        }
    }
}

loadEnv(__DIR__ . '/.env');

// ============================================================
// Definir constantes desde variables de entorno o valores por defecto
// ============================================================
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'sistema_local');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: 'root');
define('APP_ENV', getenv('APP_ENV') ?: 'production');
define('APP_DEBUG', getenv('APP_DEBUG') === 'true');
define('CORS_ORIGIN', getenv('CORS_ORIGIN') ?: '*');
// ============================================================

define('DB_CHARSET', 'utf8mb4');
define('FRONTEND_URL', CORS_ORIGIN);

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
        ]);
    }
    return $pdo;
}

function cors(): void {
    // Whitelist de orígenes desde .env (coma-separados). '*' solo se permite en debug.
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $allowed = array_filter(array_map('trim', explode(',', FRONTEND_URL)));
    if (in_array('*', $allowed, true) && APP_DEBUG) {
        header("Access-Control-Allow-Origin: *");
    } elseif ($origin && in_array($origin, $allowed, true)) {
        header("Access-Control-Allow-Origin: " . $origin);
        header("Vary: Origin");
    } elseif (!empty($allowed)) {
        // Fallback al primer origen permitido (evita CORS roto al hacer requests sin Origin)
        header("Access-Control-Allow-Origin: " . $allowed[0]);
        header("Vary: Origin");
    }
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    header("Content-Type: application/json; charset=utf-8");
    
    // ═══════════════════════════════════════════════════════════
    // SECURITY HEADERS
    // ═══════════════════════════════════════════════════════════
    // Prevenir clickjacking
    header("X-Frame-Options: DENY");
    // Prevenir MIME type sniffing
    header("X-Content-Type-Options: nosniff");
    // Habilitar XSS filter (legacy browsers)
    header("X-XSS-Protection: 1; mode=block");
    // Referrer policy
    header("Referrer-Policy: strict-origin-when-cross-origin");
    // Permissions Policy: deshabilitar APIs sensibles no usadas
    header("Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=(), magnetometer=(), gyroscope=(), accelerometer=()");
    
    // HSTS (solo en producción con HTTPS)
    if (!APP_DEBUG && isset($_SERVER['HTTPS'])) {
        header("Strict-Transport-Security: max-age=31536000; includeSubDomains; preload");
    }
    
    // CSP (Content Security Policy) - Ajustar según necesidades
    $csp = "default-src 'self'; ";
    $csp .= "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "; // Necesario para Quill/ React
    $csp .= "style-src 'self' 'unsafe-inline'; ";
    $csp .= "img-src 'self' data: blob:; ";
    $csp .= "font-src 'self'; ";
    $csp .= "connect-src 'self' http://localhost:* https:; "; // Para API calls
    $csp .= "frame-ancestors 'none'; ";
    $csp .= "base-uri 'self'; ";
    $csp .= "form-action 'self'; ";
    header("Content-Security-Policy: " . $csp);
    // ═══════════════════════════════════════════════════════════
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function body(): array {
    return json_decode(file_get_contents('php://input'), true) ?? [];
}

function ok(mixed $data = null, int $code = 200): never {
    http_response_code($code);
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function err(string $msg, int $code = 400): never {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Maneja excepciones inesperadas sin filtrar detalles internos al cliente.
 * Loggea el detalle real y devuelve mensaje genérico (o el real si APP_DEBUG=true).
 */
function errSafe(Throwable $e, int $code = 500, string $context = ''): never {
    $id = bin2hex(random_bytes(6));
    if (function_exists('logError')) {
        logError('Excepción no controlada [' . $id . ']', [
            'context'   => $context,
            'message'   => $e->getMessage(),
            'file'      => $e->getFile(),
            'line'      => $e->getLine(),
            'trace'     => APP_DEBUG ? $e->getTraceAsString() : null,
        ]);
    } else {
        error_log('[' . $id . '] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    }
    http_response_code($code);
    $payload = ['ok' => false, 'error' => 'Error interno. Ref: ' . $id];
    if (APP_DEBUG) {
        $payload['debug'] = [
            'message' => $e->getMessage(),
            'file'    => basename($e->getFile()),
            'line'    => $e->getLine(),
        ];
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

// Lee el token desde todas las fuentes posibles
function getToken(): ?string {
    $candidates = [];
    
    // 1. Intentar con apache_request_headers (Especial para MAMP/Mac)
    if (function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        if (isset($headers['Authorization'])) $candidates[] = $headers['Authorization'];
        if (isset($headers['authorization'])) $candidates[] = $headers['authorization'];
    }

    // 2. Intentar con las variables de servidor estándar
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $candidates[] = $_SERVER['HTTP_AUTHORIZATION'];
    }
    if (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $candidates[] = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    }

    // 3. Revisar cada candidato
    foreach ($candidates as $v) {
        if (empty($v)) continue;
        $v = trim((string)$v);
        if (preg_match('/^Bearer\s+(\S+)$/i', $v, $m)) {
            return $m[1];
        }
    }
    
    return null;
}

function requireAuth(): array {
    $token = getToken();
    
    if (!$token) {
        err('No autenticado. Inicia sesión.', 401);
    }
    
    $db = getDB();
    $stmt = $db->prepare("SELECT u.id, u.nombre, u.email, u.rol, u.activo 
                         FROM usuarios u 
                         JOIN sesiones s ON u.id = s.usuario_id 
                         WHERE s.token = ? AND s.expira_en > NOW() 
                         LIMIT 1");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    
    if (!$user) {
        err('Sesión inválida o expirada. Inicia sesión nuevamente.', 401);
    }
    
    if (!$user['activo']) {
        err('Usuario desactivado. Contacta al administrador.', 403);
    }
    
    return [
        'id' => (int)$user['id'],
        'nombre' => $user['nombre'],
        'email' => $user['email'],
        'rol' => $user['rol']
    ];
}

// ═══════════════════════════════════════════════════════════
// VALIDACIÓN DE INPUTS
// ═══════════════════════════════════════════════════════════

function validateEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validateString(string $value, int $min = 1, int $max = 255): bool {
    $len = mb_strlen($value);
    return $len >= $min && $len <= $max;
}

function validateInt($value, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): ?int {
    if (!is_numeric($value)) return null;
    $int = (int)$value;
    return ($int >= $min && $int <= $max) ? $int : null;
}

function validateFloat($value, float $min = PHP_FLOAT_MIN, float $max = PHP_FLOAT_MAX): ?float {
    if (!is_numeric($value)) return null;
    $float = (float)$value;
    return ($float >= $min && $float <= $max) ? $float : null;
}

function validateRut(string $rut): bool {
    // Formato chileno: 12345678-9 o 12345678-K
    if (!preg_match('/^[0-9]{1,8}-[0-9Kk]$/', $rut)) return false;
    
    list($numero, $dv) = explode('-', strtoupper($rut));
    $dv = $dv === 'K' ? 'K' : (int)$dv;
    
    // Algoritmo módulo 11
    $suma = 0;
    $multiplicador = 2;
    for ($i = strlen($numero) - 1; $i >= 0; $i--) {
        $suma += $numero[$i] * $multiplicador;
        $multiplicador = $multiplicador == 7 ? 2 : $multiplicador + 1;
    }
    
    $resto = $suma % 11;
    $dvCalculado = 11 - $resto;
    
    if ($dvCalculado == 11) $dvCalculado = '0';
    elseif ($dvCalculado == 10) $dvCalculado = 'K';
    else $dvCalculado = (string)$dvCalculado;
    
    return (string)$dv === $dvCalculado;
}

function sanitizeString(string $value): string {
    // Eliminar caracteres nulos y potencialmente peligrosos
    $value = str_replace(["\0", "\x00"], '', $value);
    // Trim
    return trim($value);
}

function sanitizeHtml(string $html): string {
    // Permitir solo tags básicos de formateo
    $allowed = '<p><br><strong><b><em><i><u><ul><ol><li><h1><h2><h3><h4><h5><h6><span><div>';
    return strip_tags($html, $allowed);
}

/**
 * Valida y limpia un array de datos
 * @param array $data Datos a validar
 * @param array $rules Reglas de validación ['campo' => 'tipo:min:max', ...]
 * @return array [ok => bool, data => cleaned|error => mensaje]
 */
function validate(array $data, array $rules): array {
    $cleaned = [];
    
    foreach ($rules as $field => $rule) {
        $value = $data[$field] ?? null;
        if ($value === null) continue;
        
        $parts = explode(':', $rule);
        $type = $parts[0];
        $min = isset($parts[1]) ? (int)$parts[1] : null;
        $max = isset($parts[2]) ? (int)$parts[2] : null;
        
        switch ($type) {
            case 'email':
                if (!validateEmail($value)) {
                    return ['ok' => false, 'error' => "El campo $field debe ser un email válido"];
                }
                $cleaned[$field] = strtolower(trim($value));
                break;
                
            case 'string':
                $value = sanitizeString($value);
                $minLen = $min ?? 1;
                $maxLen = $max ?? 255;
                if (!validateString($value, $minLen, $maxLen)) {
                    return ['ok' => false, 'error' => "El campo $field debe tener entre $minLen y $maxLen caracteres"];
                }
                $cleaned[$field] = $value;
                break;
                
            case 'int':
                $int = validateInt($value, $min ?? PHP_INT_MIN, $max ?? PHP_INT_MAX);
                if ($int === null) {
                    return ['ok' => false, 'error' => "El campo $field debe ser un número entero válido"];
                }
                $cleaned[$field] = $int;
                break;
                
            case 'float':
                $float = validateFloat($value, $min ?? PHP_FLOAT_MIN, $max ?? PHP_FLOAT_MAX);
                if ($float === null) {
                    return ['ok' => false, 'error' => "El campo $field debe ser un número válido"];
                }
                $cleaned[$field] = $float;
                break;
                
            case 'rut':
                $value = strtoupper(trim($value));
                if (!validateRut($value)) {
                    return ['ok' => false, 'error' => "El campo $field debe ser un RUT válido"];
                }
                $cleaned[$field] = $value;
                break;
                
            case 'html':
                $cleaned[$field] = sanitizeHtml($value);
                break;
                
            case 'bool':
                $cleaned[$field] = filter_var($value, FILTER_VALIDATE_BOOLEAN);
                break;
                
            default:
                $cleaned[$field] = sanitizeString($value);
        }
    }
    
    return ['ok' => true, 'data' => $cleaned];
}
// ═══════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════
// LOGGER ESTRUCTURADO JSON
// ═══════════════════════════════════════════════════════════

define('LOG_LEVEL', getenv('LOG_LEVEL') ?: 'info');
define('LOG_FILE', getenv('LOG_FILE') ?: 'logs/app.log');

// Niveles de log (menor a mayor severidad)
$GLOBALS['LOG_LEVELS'] = ['debug' => 0, 'info' => 1, 'warning' => 2, 'error' => 3, 'critical' => 4];

function logLevelValue(string $level): int {
    return $GLOBALS['LOG_LEVELS'][$level] ?? 1;
}

function shouldLog(string $level): bool {
    return logLevelValue($level) >= logLevelValue(LOG_LEVEL);
}

/**
 * Logger estructurado en JSON
 * @param string $level Nivel: debug, info, warning, error, critical
 * @param string $message Mensaje del log
 * @param array $context Datos adicionales (user_id, endpoint, ip, etc.)
 */
function logger(string $level, string $message, array $context = []): void {
    if (!shouldLog($level)) return;
    
    // Asegurar que existe el directorio de logs
    $logDir = dirname(LOG_FILE);
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    $entry = [
        'timestamp' => date('c'), // ISO 8601
        'level' => $level,
        'message' => $message,
        'context' => array_merge([
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'method' => $_SERVER['REQUEST_METHOD'] ?? 'CLI',
            'uri' => $_SERVER['REQUEST_URI'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        ], $context),
        'request_id' => uniqid(),
    ];
    
    // Si hay usuario autenticado, agregarlo al contexto
    if (function_exists('getToken')) {
        $token = getToken();
        if ($token) {
            $db = getDB();
            $stmt = $db->prepare("SELECT user_id FROM sessions WHERE token = ? AND expira_en > NOW()");
            $stmt->execute([$token]);
            $session = $stmt->fetch();
            if ($session) {
                $entry['context']['user_id'] = $session['user_id'];
            }
        }
    }
    
    $json = json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    error_log($json . "\n", 3, LOG_FILE);
}

// Helpers para cada nivel
function logDebug(string $message, array $context = []): void { logger('debug', $message, $context); }
function logInfo(string $message, array $context = []): void { logger('info', $message, $context); }
function logWarning(string $message, array $context = []): void { logger('warning', $message, $context); }
function logError(string $message, array $context = []): void { logger('error', $message, $context); }
function logCritical(string $message, array $context = []): void { logger('critical', $message, $context); }

/**
 * Middleware para loggear cada request/response
 */
function logRequest(): array {
    $startTime = microtime(true);
    
    return [
        'start' => $startTime,
        'finish' => function($statusCode = 200, $extra = []) use ($startTime) {
            $duration = round((microtime(true) - $startTime) * 1000, 2); // ms
            logger('info', 'Request completed', array_merge([
                'status_code' => $statusCode,
                'duration_ms' => $duration,
            ], $extra));
        }
    ];
}
// ═══════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════
// SISTEMA DE CACHE
// ═══════════════════════════════════════════════════════════

define('CACHE_DRIVER', getenv('CACHE_DRIVER') ?: 'file');
define('CACHE_TTL', (int)(getenv('CACHE_TTL') ?: 300));
define('CACHE_DIR', __DIR__ . '/cache');
define('REDIS_HOST', getenv('REDIS_HOST') ?: 'localhost');
define('REDIS_PORT', (int)(getenv('REDIS_PORT') ?: 6379));

// Asegurar directorio de cache existe
if (CACHE_DRIVER === 'file' && !is_dir(CACHE_DIR)) {
    mkdir(CACHE_DIR, 0755, true);
}

/**
 * Genera una clave de cache única
 */
function cacheKey(string $prefix, ...$params): string {
    return $prefix . ':' . md5(serialize($params));
}

/**
 * Obtiene valor del cache
 */
function cacheGet(string $key): ?array {
    if (CACHE_DRIVER === 'file') {
        $file = CACHE_DIR . '/' . $key . '.cache';
        if (!file_exists($file)) return null;
        
        $data = unserialize(file_get_contents($file));
        if ($data['expires'] < time()) {
            unlink($file);
            return null;
        }
        return $data['value'];
    }
    
    // Redis support (when available)
    if (CACHE_DRIVER === 'redis') {
        try {
            $redis = new Redis();
            $redis->connect(REDIS_HOST, REDIS_PORT);
            $value = $redis->get($key);
            return $value ? unserialize($value) : null;
        } catch (Exception $e) {
            logWarning('Redis cache failed, falling back to no cache', ['error' => $e->getMessage()]);
            return null;
        }
    }
    
    return null;
}

/**
 * Guarda valor en cache
 */
function cacheSet(string $key, $value, ?int $ttl = null): bool {
    $ttl = $ttl ?? CACHE_TTL;
    
    if (CACHE_DRIVER === 'file') {
        $file = CACHE_DIR . '/' . $key . '.cache';
        $data = [
            'expires' => time() + $ttl,
            'value' => $value
        ];
        return file_put_contents($file, serialize($data), LOCK_EX) !== false;
    }
    
    if (CACHE_DRIVER === 'redis') {
        try {
            $redis = new Redis();
            $redis->connect(REDIS_HOST, REDIS_PORT);
            return $redis->setex($key, $ttl, serialize($value));
        } catch (Exception $e) {
            logWarning('Redis cache set failed', ['error' => $e->getMessage()]);
            return false;
        }
    }
    
    return false;
}

/**
 * Elimina valor del cache
 */
function cacheDelete(string $key): bool {
    if (CACHE_DRIVER === 'file') {
        $file = CACHE_DIR . '/' . $key . '.cache';
        return file_exists($file) ? unlink($file) : true;
    }
    
    if (CACHE_DRIVER === 'redis') {
        try {
            $redis = new Redis();
            $redis->connect(REDIS_HOST, REDIS_PORT);
            return $redis->del($key) > 0;
        } catch (Exception $e) {
            return false;
        }
    }
    
    return false;
}

/**
 * Limpia todo el cache
 */
function cacheClear(): bool {
    if (CACHE_DRIVER === 'file') {
        $files = glob(CACHE_DIR . '/*.cache');
        foreach ($files as $file) {
            unlink($file);
        }
        return true;
    }
    
    if (CACHE_DRIVER === 'redis') {
        try {
            $redis = new Redis();
            $redis->connect(REDIS_HOST, REDIS_PORT);
            return $redis->flushAll();
        } catch (Exception $e) {
            return false;
        }
    }
    
    return false;
}

/**
 * Cache helper: get or set
 */
function cacheRemember(string $key, callable $callback, ?int $ttl = null) {
    $cached = cacheGet($key);
    if ($cached !== null) {
        return $cached;
    }
    
    $value = $callback();
    cacheSet($key, $value, $ttl);
    return $value;
}
// ═══════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════
// EMAIL QUEUE SYSTEM
// ═══════════════════════════════════════════════════════════

define('SMTP_HOST', getenv('SMTP_HOST') ?: 'localhost');
define('SMTP_PORT', (int)(getenv('SMTP_PORT') ?: 587));
define('SMTP_USER', getenv('SMTP_USER') ?: '');
define('SMTP_PASS', getenv('SMTP_PASS') ?: '');
define('SMTP_FROM', getenv('SMTP_FROM') ?: 'noreply@sistema.local');
define('SMTP_FROM_NAME', getenv('SMTP_FROM_NAME') ?: 'Sistema Local');

/**
 * Agrega un email a la cola para envío asíncrono
 */
function queueEmail(array $data): bool {
    $db = getDB();
    
    $stmt = $db->prepare("INSERT INTO email_queue 
        (to_email, to_name, subject, body_html, body_text, from_email, from_name, priority, scheduled_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    return $stmt->execute([
        $data['to_email'],
        $data['to_name'] ?? null,
        $data['subject'],
        $data['body_html'] ?? null,
        $data['body_text'] ?? null,
        $data['from_email'] ?? SMTP_FROM,
        $data['from_name'] ?? SMTP_FROM_NAME,
        $data['priority'] ?? 5,
        $data['scheduled_at'] ?? date('Y-m-d H:i:s')
    ]);
}

/**
 * Obtiene emails pendientes de la cola
 */
function getPendingEmails(int $limit = 10): array {
    $db = getDB();
    
    $stmt = $db->prepare("SELECT * FROM email_queue 
        WHERE status = 'pending' 
        AND scheduled_at <= NOW()
        AND attempts < max_attempts
        ORDER BY priority ASC, created_at ASC
        LIMIT ?");
    
    $stmt->execute([$limit]);
    return $stmt->fetchAll();
}

/**
 * Marca un email como en proceso
 */
 function markEmailProcessing(int $id): bool {
    $db = getDB();
    $stmt = $db->prepare("UPDATE email_queue 
        SET status = 'processing', attempts = attempts + 1, processed_at = NOW() 
        WHERE id = ?");
    return $stmt->execute([$id]);
}

/**
 * Marca un email como enviado
 */
function markEmailSent(int $id): bool {
    $db = getDB();
    $stmt = $db->prepare("UPDATE email_queue 
        SET status = 'sent', sent_at = NOW() 
        WHERE id = ?");
    return $stmt->execute([$id]);
}

/**
 * Marca un email como fallido
 */
function markEmailFailed(int $id, string $error): bool {
    $db = getDB();
    $stmt = $db->prepare("UPDATE email_queue 
        SET status = 'failed', error_message = ? 
        WHERE id = ?");
    return $stmt->execute([$error, $id]);
}

/**
 * Envía un email usando mail() nativo (fallback simple)
 * En producción, reemplazar por PHPMailer o SendGrid
 */
function sendEmail(array $email): bool {
    $to = $email['to_email'];
    $subject = $email['subject'];
    $headers = [
        'From: ' . $email['from_name'] . ' <' . $email['from_email'] . '>',
        'Reply-To: ' . $email['from_email'],
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8'
    ];
    
    // Para desarrollo, loggear en lugar de enviar
    if (APP_ENV === 'development') {
        logInfo('Email enviado (modo desarrollo)', [
            'to' => $to,
            'subject' => $subject,
            'queue_id' => $email['id']
        ]);
        return true;
    }
    
    // En producción, usar mail() o integrar PHPMailer
    $headersStr = implode("\r\n", $headers);
    return mail($to, $subject, $email['body_html'], $headersStr);
}

/**
 * Procesa la cola de emails (llamar desde cron job cada minuto)
 * Uso: php email_worker.php
 */
function processEmailQueue(int $batchSize = 10): array {
    $results = ['processed' => 0, 'sent' => 0, 'failed' => 0];
    
    $emails = getPendingEmails($batchSize);
    
    foreach ($emails as $email) {
        $results['processed']++;
        
        // Marcar como procesando
        markEmailProcessing($email['id']);
        
        // Intentar enviar
        try {
            if (sendEmail($email)) {
                markEmailSent($email['id']);
                $results['sent']++;
                logInfo('Email enviado desde cola', ['queue_id' => $email['id'], 'to' => $email['to_email']]);
            } else {
                throw new Exception('mail() returned false');
            }
        } catch (Exception $e) {
            markEmailFailed($email['id'], $e->getMessage());
            $results['failed']++;
            logError('Email falló', ['queue_id' => $email['id'], 'error' => $e->getMessage()]);
        }
    }
    
    return $results;
}

/**
 * Estadísticas de la cola de emails
 */
function getEmailQueueStats(): array {
    $db = getDB();
    
    $stmt = $db->query("SELECT 
        status, COUNT(*) as count 
        FROM email_queue 
        GROUP BY status");
    
    $stats = ['pending' => 0, 'processing' => 0, 'sent' => 0, 'failed' => 0];
    foreach ($stmt->fetchAll() as $row) {
        $stats[$row['status']] = (int)$row['count'];
    }
    
    return $stats;
}
// ═══════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════
// AUDITORÍA
// ═══════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════
// RATE LIMITING (basado en file lock + ventana fija)
// ═══════════════════════════════════════════════════════════
/**
 * Rate limit por IP + clave. Si se supera, responde 429 y corta la ejecución.
 *
 * @param string $key   Identificador del bucket (ej: 'export', 'backup.create').
 * @param int    $limit Cantidad máxima de requests permitidos.
 * @param int    $window Ventana en segundos.
 */
function rateLimit(string $key, int $limit, int $window): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'cli';
    $bucket = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $key . ':' . $ip);
    $dir = __DIR__ . '/cache/rl';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $file = $dir . '/' . $bucket;
    $now  = time();
    $data = ['reset' => $now + $window, 'count' => 0];
    if (is_file($file)) {
        $raw = @file_get_contents($file);
        $parsed = $raw ? @json_decode($raw, true) : null;
        if (is_array($parsed) && ($parsed['reset'] ?? 0) > $now) $data = $parsed;
    }
    $data['count']++;
    @file_put_contents($file, json_encode($data), LOCK_EX);
    if ($data['count'] > $limit) {
        header('Retry-After: ' . max(1, $data['reset'] - $now));
        err('Demasiadas solicitudes. Intenta en ' . ($data['reset'] - $now) . 's.', 429);
    }
}
// ═══════════════════════════════════════════════════════════

function audit(PDO $db, int $usuarioId, string $accion, string $tabla, string $detalle, ?int $regId = null): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $db->prepare("INSERT INTO auditoria (usuario_id, accion, tabla_afectada, registro_id, detalle, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())")
       ->execute([$usuarioId, $accion, $tabla, $regId, $detalle, $ip]);
}