import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../assets/js/api.js'

/**
 * Helper centralizado: invalida todas las queries afectadas por un cambio.
 * Mantiene la coherencia del dashboard y vistas relacionadas sin que cada
 * mutación tenga que recordar a quién avisa.
 */
function invalidate(qc, keys) {
  for (const k of keys) qc.invalidateQueries({ queryKey: [k] })
}

// ═══════════════════════════════════════════════════════════
// QUERIES - Lectura de datos
// ═══════════════════════════════════════════════════════════

export function useClientes(params = {}, options = {}) {
  return useQuery({
    queryKey: ['clientes', params],
    queryFn: () => api.getClientes(params),
    // Esto mantiene los datos en pantalla mientras carga la página siguiente
    placeholderData: (previousData) => previousData,
    staleTime: 30_000,
    gcTime: 5 * 60_000,
    ...options,
  })
}

export function useProyectos(params = {}, options = {}) {
  return useQuery({
    queryKey: ['proyectos', params],
    queryFn: () => api.getProyectos(params),
    placeholderData: (previousData) => previousData,
    staleTime: 30_000,
    gcTime: 5 * 60_000,
    ...options,
  })
}

export function useServicios(params = {}, options = {}) {
  return useQuery({
    queryKey: ['servicios', params],
    queryFn: () => api.getServicios(params),
    placeholderData: (previousData) => previousData,
    staleTime: 30_000,
    gcTime: 5 * 60_000,
    ...options,
  })
}

export function usePagos(params = {}) {
  return useQuery({
    queryKey: ['pagos', params],
    queryFn: () => api.getPagos(params),
    placeholderData: (previousData) => previousData,
    staleTime: 10_000,
  })
}

export function useCotizaciones(params = {}) {
  return useQuery({
    queryKey: ['cotizaciones', params],
    queryFn: () => api.getCotizaciones(params),
    placeholderData: (previousData) => previousData,
    staleTime: 10_000,
  })
}

export function useUsuarios() {
  return useQuery({
    queryKey: ['usuarios'],
    queryFn: api.getUsuarios,
    staleTime: 60_000,
  })
}

export function useDashboard(periodo = 'mes_actual') {
  return useQuery({
    queryKey: ['dashboard', periodo],
    queryFn: () => api.dashboard(`?periodo=${periodo}`),
    staleTime: 60_000,
  })
}

export function useSitios(params = {}, options = {}) {
  return useQuery({
    queryKey: ['sitios', params],
    queryFn: () => api.getSitios(params),
    placeholderData: (previousData) => previousData,
    staleTime: 30_000,
    ...options,
  })
}

export function useAccesos(sitioId, options = {}) {
  return useQuery({
    queryKey: ['accesos', sitioId],
    queryFn: () => api.getAccesos(sitioId),
    enabled: !!sitioId,
    staleTime: 30_000,
    ...options,
  })
}

// Sitios aparecen en proyectos (sitio_nombre/sitio_url) → cualquier mutación
// debe refrescar también la lista de proyectos.
const SITIO_RELATED = ['sitios', 'proyectos']

export function useCrearSitio() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: api.crearSitio,
    onSuccess: () => invalidate(qc, SITIO_RELATED),
  })
}
export function useEditarSitio() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.editarSitio(id, data),
    onSuccess: () => invalidate(qc, SITIO_RELATED),
  })
}
export function useBorrarSitio() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: api.borrarSitio,
    onSuccess: () => invalidate(qc, SITIO_RELATED),
  })
}

export function useCrearAcceso() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: api.crearAcceso,
    onSuccess: (_data, vars) => { invalidate(qc, ['accesos','sitios']); qc.invalidateQueries({ queryKey: ['accesos', vars.sitio_id] }) },
  })
}
export function useEditarAcceso() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.editarAcceso(id, data),
    onSuccess: () => invalidate(qc, ['accesos','sitios']),
  })
}
export function useBorrarAcceso() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: api.borrarAcceso,
    onSuccess: () => invalidate(qc, ['accesos','sitios']),
  })
}

export function useReportes(params = {}) {
  return useQuery({
    queryKey: ['reportes', params],
    queryFn: () => api.reportes(params),
    staleTime: 60_000,
  })
}

export function useConfiguracion(options = {}) {
  return useQuery({
    queryKey: ['configuracion'],
    queryFn: api.getConfig,
    staleTime: 5 * 60_000,
    ...options,
  })
}

export function useAuditoria(filtros = {}) {
  const qs = new URLSearchParams(filtros).toString()
  return useQuery({
    queryKey: ['auditoria', qs],
    queryFn: () => api.getAuditoria(filtros),
    staleTime: 0,         // siempre trae datos frescos al montar
    refetchOnMount: true
  })
}

// ═══════════════════════════════════════════════════════════
// MUTATIONS - Escritura de datos
// ═══════════════════════════════════════════════════════════

// El cliente es referenciado por sitios, proyectos, cotizaciones y pagos
// (todos hacen JOIN y muestran nombre/agencia). Al mutarlo, invalidamos
// también esas vistas para que el nombre cambiado aparezca sin recargar.
const CLIENTE_RELATED = ['clientes', 'sitios', 'proyectos', 'cotizaciones', 'pagos', 'dashboard']

export function useCrearCliente() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.crearCliente,
    onSuccess: () => invalidate(queryClient, CLIENTE_RELATED),
  })
}

export function useEditarCliente() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.editarCliente(id, data),
    onSuccess: () => invalidate(queryClient, CLIENTE_RELATED),
  })
}

export function useBorrarCliente() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.borrarCliente,
    onSuccess: () => invalidate(queryClient, CLIENTE_RELATED),
  })
}

export function useCrearProyecto() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.crearProyecto,
    onSuccess: () => {
      invalidate(queryClient, ['proyectos', 'dashboard', 'clientes'])
    }
  })
}

export function useEditarProyecto() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.editarProyecto(id, data),
    onSuccess: () => {
      invalidate(queryClient, ['proyectos', 'dashboard'])
    }
  })
}

export function useBorrarProyecto() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.borrarProyecto,
    onSuccess: () => {
      invalidate(queryClient, ['proyectos', 'dashboard'])
    }
  })
}

export function useCrearPago() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.crearPago,
    onSuccess: () => {
      invalidate(queryClient, ['pagos', 'dashboard', 'cotizaciones', 'proyectos'])
    }
  })
}

export function useEditarPago() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.editarPago(id, data),
    onSuccess: () => {
      invalidate(queryClient, ['pagos', 'dashboard', 'cotizaciones', 'proyectos'])
    }
  })
}

export function useBorrarPago() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.borrarPago,
    onSuccess: () => {
      invalidate(queryClient, ['pagos', 'dashboard', 'cotizaciones', 'proyectos'])
    }
  })
}

export function useCrearServicio() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.crearServicio,
    onSuccess: () => {
      invalidate(queryClient, ['servicios'])
    }
  })
}

export function useEditarServicio() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.editarServicio(id, data),
    onSuccess: () => {
      invalidate(queryClient, ['servicios', 'cotizaciones'])
    }
  })
}

export function useBorrarServicio() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.borrarServicio,
    onSuccess: () => {
      invalidate(queryClient, ['servicios', 'cotizaciones'])
    }
  })
}

export function useCrearUsuario() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.crearUsuario,
    onSuccess: () => {
      invalidate(queryClient, ['usuarios'])
    }
  })
}

export function useEditarUsuario() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.editarUsuario(id, data),
    onSuccess: () => {
      invalidate(queryClient, ['usuarios'])
    }
  })
}

export function useBorrarUsuario() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.borrarUsuario,
    onSuccess: () => {
      invalidate(queryClient, ['usuarios'])
    }
  })
}

export function useCrearCotizacion() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.crearCotizacion,
    onSuccess: () => {
      invalidate(queryClient, ['cotizaciones', 'dashboard'])
    }
  })
}

export function useEditarCotizacion() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.editarCotizacion(id, data),
    onSuccess: () => {
      invalidate(queryClient, ['cotizaciones', 'dashboard'])
    }
  })
}

export function useBorrarCotizacion() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.borrarCotizacion,
    onSuccess: () => {
      invalidate(queryClient, ['cotizaciones', 'dashboard'])
    }
  })
}

export function useBorrarAuditoria() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.borrarAuditoria,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['auditoria'] })
    }
  })
}

export function useBorrarAuditoriaBulk() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.borrarAuditoriaBulk,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['auditoria'] })
    }
  })
}

export function useVaciarAuditoria() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.vaciarAuditoria,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['auditoria'] })
    }
  })
}

export function useLogin() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.login,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['auth'] })
    }
  })
}

export function useLogout() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.logout,
    onSuccess: () => {
      queryClient.clear()
    }
  })
}
