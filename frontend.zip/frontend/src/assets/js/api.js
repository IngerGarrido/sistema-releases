// ============================================================
// CONFIGURACIÓN DE API - VARIABLES DE ENTORNO
// ============================================================
const PER_PAGE_DEFAULT = 10;
const API = import.meta.env.VITE_API_URL || 'https://sistema.ingergarrido.cl/backend/api'
const isLocal = import.meta.env.VITE_APP_ENV === 'development' || 
                window.location.hostname === 'localhost' || 
                window.location.hostname === '127.0.0.1' || 
                window.location.hostname.startsWith('192.168.') || 
                window.location.hostname.startsWith('10.')
// ============================================================

// Función helper para resolver URLs de uploads (logo, etc.)
// En local usa la URL del backend, en producción usa ruta relativa
export const resolveUploadUrl = (path) => {
  if (!path) return null
  if (path.startsWith('http')) return path // Ya es URL absoluta
  if (isLocal) {
    // En local: usar URL completa del backend
    const baseUrl = API.replace('/backend/api', '')
    return `${baseUrl}${path}`
  }
  // En producción: ruta relativa funciona
  return path
}

export const session = {
  getUser:  () => { try { return JSON.parse(localStorage.getItem('_u') || 'null') } catch { return null } },
  setUser:  (u) => localStorage.setItem('_u', JSON.stringify(u)),
  getToken: () => localStorage.getItem('_t') || null,
  setToken: (t) => localStorage.setItem('_t', t),
  clear:    () => { localStorage.removeItem('_u'); localStorage.removeItem('_t') },
  logged:   () => !!localStorage.getItem('_t'),
}

const DEFAULT_TIMEOUT_MS = 30000
const MAX_RETRIES = 2 // solo para GET en errores de red / 5xx
const sleep = (ms) => new Promise(r => setTimeout(r, ms))

async function call(method, path, data, isForm = false, opts2 = {}) {
  const token = session.getToken()
  const headers = {}
  if (token) headers['Authorization'] = 'Bearer ' + token
  if (!isForm) headers['Content-Type'] = 'application/json'

  const timeoutMs = opts2.timeoutMs ?? DEFAULT_TIMEOUT_MS
  const maxRetries = method === 'GET' ? (opts2.maxRetries ?? MAX_RETRIES) : 0

  const opts = { method, headers }
  if (data !== undefined) opts.body = isForm ? data : JSON.stringify(data)

  let lastErr
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const ctrl = new AbortController()
    const tid = setTimeout(() => ctrl.abort(), timeoutMs)
    opts.signal = ctrl.signal
    let res
    try {
      res = await fetch(`${API}/${path}`, opts)
    } catch (e) {
      clearTimeout(tid)
      lastErr = (e?.name === 'AbortError')
        ? new Error(`La solicitud superó ${Math.round(timeoutMs/1000)}s sin respuesta`)
        : new Error('No se pudo conectar al servidor')
      if (attempt < maxRetries) { await sleep(300 * Math.pow(2, attempt)); continue }
      throw lastErr
    }
    clearTimeout(tid)
    if (res.status >= 500 && attempt < maxRetries) {
      await sleep(300 * Math.pow(2, attempt)); continue
    }
    return handleResponse(res)
  }
  throw lastErr || new Error('Error de red')
}

async function handleResponse(res) {

  const text = await res.text()
  const trim = text.trim()

  // Detectar HTML = error PHP
  if (trim.startsWith('<') || trim.startsWith('<!')) {
    const m = trim.match(/(?:Fatal error|Warning|Notice|Parse error|Deprecated)[^\n<]*/i)
    throw new Error(m ? 'Error PHP: ' + m[0].trim() : `Servidor devolvió HTML (${res.status}). Revisa config.php`)
  }

  let json
  try { 
    json = JSON.parse(text) 
  } catch (e) { 
    console.error('Error parseando JSON:', e, 'Texto recibido:', text)
    throw new Error('Respuesta inválida: ' + trim.substring(0, 100)) 
  }

  if (!json.ok) {
    if (res.status === 401 && session.getToken()) {
      session.clear(); window.location.reload(); return null
    }
    throw new Error(json.error || 'Error del servidor')
  }
  // Si hay paginación, retornar objeto completo; si no, solo los datos (compatibilidad)
  if (json.pagination) {
    return { data: json.data, pagination: json.pagination }
  }
  return json.data
}

/**
 * Descarga autenticada: usa fetch con Authorization en header
 * (en lugar de exponer el token en la URL) y guarda como blob.
 */
/**
 * Abre un endpoint autenticado (que devuelve HTML) en una pestaña nueva.
 * Útil para la "vista previa imprimible" de cotizaciones: el backend devuelve
 * HTML con botón de imprimir, no un PDF binario.
 *
 * Estrategia:
 *  1) Abre window inmediatamente (con el gesto del click) para evitar popup-blocker.
 *  2) Fetch autenticado del HTML.
 *  3) Reescribe el documento de la pestaña ya abierta con el HTML recibido.
 */
export async function openAuthenticatedHTML(path) {
  const win = window.open('about:blank', '_blank')
  if (!win) throw new Error('El navegador bloqueó la ventana emergente. Permítela e intenta de nuevo.')
  try {
    win.document.write('<title>Cargando…</title><body style="font-family:system-ui;padding:24px;color:#666">Cargando vista previa…</body>')
    const token = session.getToken()
    const headers = {}
    if (token) headers['Authorization'] = 'Bearer ' + token
    const res = await fetch(`${API}/${path}`, { headers })
    if (!res.ok) {
      const t = await res.text().catch(()=> '')
      win.close()
      throw new Error(t || `No se pudo abrir (${res.status})`)
    }
    let html = await res.text()
    // Inyectar <base> para que recursos relativos (CSS, imágenes) sigan resolviendo
    // contra el backend cuando el documento se reescribe en la pestaña.
    const baseHref = `${API}/`
    if (/<head[^>]*>/i.test(html)) {
      html = html.replace(/<head([^>]*)>/i, `<head$1><base href="${baseHref}">`)
    } else {
      html = `<head><base href="${baseHref}"></head>` + html
    }
    win.document.open()
    win.document.write(html)
    win.document.close()
  } catch (e) {
    try { win.close() } catch { /* ignore */ }
    throw e
  }
}

export async function downloadAuthenticated(path, suggestedName) {
  const token = session.getToken()
  const headers = {}
  if (token) headers['Authorization'] = 'Bearer ' + token
  const res = await fetch(`${API}/${path}`, { headers })
  if (!res.ok) {
    const t = await res.text().catch(()=> '')
    throw new Error(t || `Descarga falló (${res.status})`)
  }
  // Nombre desde Content-Disposition si está presente
  let filename = suggestedName || 'descarga'
  const cd = res.headers.get('Content-Disposition') || ''
  const m = cd.match(/filename="?([^";]+)"?/)
  if (m) filename = m[1]
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

export const api = {
  // Auth
  login:   (b) => call('POST', 'auth.php', b),
  logout:  ()  => call('POST', 'auth.php/logout'),
  activos: ()  => call('GET',  'auth.php/activos'),

  // Usuarios
  getUsuarios:   ()      => call('GET',  'usuarios.php'),
  crearUsuario:  (b)     => call('POST', 'usuarios.php', b),
  editarUsuario: (id, b) => call('POST', `usuarios.php?id=${id}&_method=PUT`, b),
  borrarUsuario: (id) => call('DELETE', `usuarios.php?id=${id}`),

  // Clientes (con soft delete y paginación)
  /**
   * Lista clientes paginados con búsqueda server-side.
   * @param {Object} opts
   * @param {boolean} [opts.papelera=false] - Si true, solo eliminados (deleted_at IS NOT NULL)
   * @param {number} [opts.page=1]
   * @param {number} [opts.per_page=10]
   * @param {string} [opts.q] - Filtro LIKE sobre nombre, nombre_agencia, rut, email
   * @returns {Promise<{data:Array, pagination:Object}>}
   */
  getClientes:       (opts = {}) => {
    const { papelera = false, page = 1, per_page = PER_PAGE_DEFAULT, q = '' } = opts;
    let qs = new URLSearchParams();
    if (papelera) qs.append('papelera', '1');
    if (page) qs.append('page', page);
    if (per_page) qs.append('per_page', per_page);
    if (q) qs.append('q', q);
    const qsStr = qs.toString();
    return call('GET', `clientes.php${qsStr ? '?' + qsStr : ''}`);
  },
  getClientesPapelera: () => call('GET', 'clientes.php?papelera=1'),
  crearCliente:    (b) => call('POST', 'clientes.php', b),
  editarCliente:   (id, b) => call('PUT', `clientes.php/${id}`, b),
  borrarCliente: (id) => call('DELETE', `clientes.php?id=${id}`),        // Soft delete
  restaurarCliente:(id) => call('POST', `clientes.php/restore/${id}`),   // Restaurar
  eliminarClienteDefinitivo: (id) => call('DELETE', `clientes.php/${id}?hard=1`), // Hard delete

  // Proyectos (con soft delete y paginación)
  /**
   * Lista proyectos paginados con búsqueda server-side.
   * @param {Object} opts
   * @param {boolean} [opts.papelera=false]
   * @param {number} [opts.page=1]
   * @param {number} [opts.per_page=10]
   * @param {string} [opts.q] - Filtro LIKE sobre nombre proyecto, tipo, cliente
   */
  getProyectos:         (opts = {}) => {
    const { papelera = false, page = 1, per_page = PER_PAGE_DEFAULT, q = '' } = opts;
    let qs = new URLSearchParams();
    if (papelera) qs.append('papelera', '1');
    if (page) qs.append('page', page);
    if (per_page) qs.append('per_page', per_page);
    if (q) qs.append('q', q);
    const qsStr = qs.toString();
    return call('GET', `proyectos.php${qsStr ? '?' + qsStr : ''}`);
  },
  getProyectosPapelera: () => call('GET', 'proyectos.php?papelera=1'),
  crearProyecto:        (b) => call('POST', 'proyectos.php', b),
  editarProyecto:       (id, data) => call('PUT', `proyectos.php?id=${id}`, data),
  borrarProyecto:       (id) => call('DELETE', `proyectos.php?id=${id}`),          // Soft delete
  restaurarProyecto:    (id) => call('POST', `proyectos.php/restore/${id}`),       // Restaurar
  eliminarProyectoDefinitivo: (id) => call('DELETE', `proyectos.php?id=${id}&hard=1`), // Hard delete

  // Cotizaciones (con soft delete y paginación)
  /**
   * Lista cotizaciones paginadas con búsqueda server-side.
   * @param {Object} opts
   * @param {string} [opts.q] - Filtro LIKE sobre numero, cliente, proyecto
   */
  getCotizaciones:         (opts = {}) => {
    const { papelera = false, page = 1, per_page = PER_PAGE_DEFAULT, q = '' } = opts;
    let qs = new URLSearchParams();
    if (papelera) qs.append('papelera', '1');
    if (page) qs.append('page', page);
    if (per_page) qs.append('per_page', per_page);
    if (q) qs.append('q', q);
    const qsStr = qs.toString();
    return call('GET', `cotizaciones.php${qsStr ? '?' + qsStr : ''}`);
  },
  getCotizacionesPapelera: () => call('GET', 'cotizaciones.php?papelera=1'),
  getCotizacion:         (id) => call('GET', `cotizaciones.php?id=${id}`),
  crearCotizacion:       (b) => call('POST', 'cotizaciones.php', b),
  editarCotizacion:      (id, data) => call('PUT', `cotizaciones.php?id=${id}`, data),
  borrarCotizacion:      (id) => call('DELETE', `cotizaciones.php?id=${id}`),          // Soft delete
  restaurarCotizacion:   (id) => call('POST', `cotizaciones.php/restore/${id}`),       // Restaurar
  eliminarCotizacionDefinitivo: (id) => call('DELETE', `cotizaciones.php?id=${id}&hard=1`), // Hard delete
  convertirCotizacion: (id) => call('POST', 'cotizaciones_convertir.php', { id }),

  // Pagos (con soft delete y paginación)
  /**
   * Lista pagos paginados con búsqueda server-side.
   * @param {Object} opts
   * @param {string} [opts.q] - Filtro LIKE sobre descripcion, cliente, proyecto
   */
  getPagos:         (opts = {}) => {
    const { papelera = false, page = 1, per_page = PER_PAGE_DEFAULT, q = '' } = opts;
    let qs = new URLSearchParams();
    if (papelera) qs.append('papelera', '1');
    if (page) qs.append('page', page);
    if (per_page) qs.append('per_page', per_page);
    if (q) qs.append('q', q);
    const qsStr = qs.toString();
    return call('GET', `pagos.php${qsStr ? '?' + qsStr : ''}`);
  },
  getPagosPapelera: () => call('GET', 'pagos.php?papelera=1'),
  crearPago:        (b) => call('POST', 'pagos.php', b),
  editarPago:       (id, b) => call('PUT', `pagos.php/${id}`, b),
  borrarPago:       (id) => call('DELETE', `pagos.php/${id}`),          // Soft delete
  restaurarPago:    (id) => call('POST', `pagos.php/restore/${id}`),     // Restaurar
  eliminarPagoDefinitivo: (id) => call('DELETE', `pagos.php/${id}?hard=1`), // Hard delete

  // Config
  getConfig:   ()  => call('GET', 'configuracion.php'),
  saveConfig:  (b) => call('PUT', 'configuracion.php', b),
  resetNumero: (n) => call('PUT', 'configuracion.php/reset-numero', { siguiente: n }),
  // Servicios (con soft delete y paginación)
  getServicios:         (opts = {}) => {
    const { papelera = false, page = 1, per_page = PER_PAGE_DEFAULT, q = '' } = opts;
    let qs = new URLSearchParams();
    if (papelera) qs.append('papelera', '1');
    if (page) qs.append('page', page);
    if (per_page) qs.append('per_page', per_page);
    if (q) qs.append('q', q);
    const qsStr = qs.toString();
    return call('GET', `servicios.php${qsStr ? '?' + qsStr : ''}`);
  },
  getServiciosPapelera: () => call('GET', 'servicios.php?papelera=1'),
  crearServicio:        (data) => call('POST', 'servicios.php', data),
  editarServicio:       (id, data) => call('PUT', `servicios.php?id=${id}`, data),
  borrarServicio:       (id) => call('DELETE', `servicios.php?id=${id}`),          // Soft delete
  restaurarServicio:    (id) => call('POST', `servicios.php/restore/${id}`),       // Restaurar
  eliminarServicioDefinitivo: (id) => call('DELETE', `servicios.php?id=${id}&hard=1`), // Hard delete

  subirLogo: (file) => {
    const formData = new FormData();
    formData.append('logo', file);
    return call('POST', 'configuracion.php?accion=subir_logo', formData, true);
  },

  borrarLogo: () => call('DELETE', 'configuracion.php?accion=borrar_logo'),

  subirLogoCotizaciones: (file) => {
    const formData = new FormData();
    formData.append('logo', file);
    return call('POST', 'configuracion.php?accion=subir_logo_cotizaciones', formData, true);
  },

  borrarLogoCotizaciones: () => call('DELETE', 'configuracion.php?accion=borrar_logo_cotizaciones'),

  subirLoginBg: (file) => {
    const formData = new FormData();
    formData.append('logo', file);
    return call('POST', 'configuracion.php?accion=subir_login_bg', formData, true);
  },

  borrarLoginBg: () => call('DELETE', 'configuracion.php?accion=borrar_login_bg'),

  dashboard: (qs = '') => call('GET', `dashboard.php${qs}`),  // ...
  reportes: (params = {}) => {
    const qs = new URLSearchParams(params).toString()
    return call('GET', `reportes.php${qs ? '?' + qs : ''}`)
  },
  mantenimiento: () => call('POST', 'mantenimiento.php'),
  // Backups mejorados
  listarBackups: () => call('GET', 'backup.php'),
  generarBackup: () => call('POST', 'backup.php'),
  descargarBackup: (filename) => downloadAuthenticated(`backup.php?file=${encodeURIComponent(filename)}`, filename),
  restaurarBackup: (filename) => call('POST', 'backup.php?action=restore', { file: filename }),
  eliminarBackup: (filename) => call('DELETE', `backup.php?file=${encodeURIComponent(filename)}`),
  // Auditoría
  getAuditoria: (filtros = {}) => {
    const qs = new URLSearchParams(filtros).toString()
    return call('GET', `auditoria.php${qs ? '?' + qs : ''}`)
  },
  borrarAuditoria: (id) => call('DELETE', `auditoria.php?id=${id}`),
  borrarAuditoriaBulk: (ids) => call('DELETE', `auditoria.php?ids=${ids.join(',')}`),
  vaciarAuditoria: () => call('DELETE', `auditoria.php?all=1`),

  // Exports — autenticación por header
  excel: (type) => downloadAuthenticated(`exports?type=${encodeURIComponent(type)}`, `${type}.xlsx`),
  pdfCotizacion: (id) => openAuthenticatedHTML(`exports?type=pdf_cotizacion&id=${encodeURIComponent(id)}`),

  // Buscador global
  buscarGlobal: (query) => call('GET', `buscar.php?q=${encodeURIComponent(query)}`),

  // Exportar a Excel — autenticación por header
  exportar: (tipo) => downloadAuthenticated(`exportar.php?tipo=${encodeURIComponent(tipo)}`, `${tipo}.xlsx`),

  // Plantillas de Términos
  getPlantillasTerminos: (todas = false) => call('GET', `plantillas_terminos.php${todas ? '?todas=1' : ''}`),
  getPlantillaTerminos: (id) => call('GET', `plantillas_terminos.php?id=${id}`),
  crearPlantillaTerminos: (data) => call('POST', 'plantillas_terminos.php', data),
  actualizarPlantillaTerminos: (id, data) => call('PUT', `plantillas_terminos.php?id=${id}`, data),
  desactivarPlantillaTerminos: (id) => call('DELETE', `plantillas_terminos.php?id=${id}`),

  // Recuperación de contraseña
  recuperarPassword: (email) => call('POST', 'recuperar.php', { email }),
  resetPassword: (token, password) => call('POST', 'reset_password.php', { token, password }),

  // Sitios (cuentas/marcas que pueden tener N proyectos y compartir accesos)
  getSitios:    (opts = {}) => {
    // Si se pide per_page, garantizamos page=1 para que el backend devuelva
    // siempre el envoltorio { data, pagination } (consistente con proyectos.php)
    const { cliente_id, q, papelera = false, page, per_page } = opts
    const qs = new URLSearchParams()
    if (cliente_id) qs.append('cliente_id', cliente_id)
    if (q) qs.append('q', q)
    if (papelera) qs.append('papelera', '1')
    if (per_page) {
      qs.append('page', page || 1)
      qs.append('per_page', per_page)
    } else if (page) {
      qs.append('page', page)
    }
    const s = qs.toString()
    return call('GET', `sitios.php${s ? '?' + s : ''}`)
  },
  getSitio:     (id) => call('GET', `sitios.php?id=${id}`),
  crearSitio:   (data) => call('POST', 'sitios.php', data),
  editarSitio:  (id, data) => call('PUT', `sitios.php?id=${id}`, data),
  borrarSitio:  (id) => call('DELETE', `sitios.php?id=${id}`),
  restaurarSitio: (id) => call('POST', `sitios.php/restore/${id}`),
  eliminarSitioDefinitivo: (id) => call('DELETE', `sitios.php?id=${id}&hard=1`),

  // Accesos cifrados por sitio
  getAccesos:      (sitioId) => call('GET', `accesos.php?sitio_id=${sitioId}`),
  revelarAcceso:   (sitioId, id) => call('GET', `accesos.php?sitio_id=${sitioId}&id=${id}&reveal=1`),
  crearAcceso:     (data) => call('POST', 'accesos.php', data),
  editarAcceso:    (id, data) => call('PUT', `accesos.php?id=${id}`, data),
  borrarAcceso:    (id) => call('DELETE', `accesos.php?id=${id}`),

  // Migraciones (admin)
  getMigraciones:    () => call('GET',  'admin/migraciones.php'),
  aplicarMigraciones:() => call('POST', 'admin/migraciones.php'),

  // Actualizaciones de código (git pull + migrar)
  getActualizaciones:    () => call('GET',  'admin/actualizar.php'),
  ejecutarActualizacion: () => call('POST', 'admin/actualizar.php', {}, false, { timeoutMs: 120_000 }),
  guardarTokenGitHub:    (token) => call('POST', 'admin/actualizar.php?action=save_token', { token }),

  // Notificaciones (persistidas en backend)
  getNotificaciones:  ()       => call('GET',    'notificaciones.php'),
  crearNotificacion:  (data)   => call('POST',   'notificaciones.php', data),
  marcarNotifLeida:   (id)     => call('PUT',    `notificaciones.php?id=${id}`),
  marcarTodasLeidas:  ()       => call('PUT',    'notificaciones.php?all=1'),
  eliminarNotif:      (id)     => call('DELETE', `notificaciones.php?id=${id}`),
  eliminarTodasNotif: ()       => call('DELETE', 'notificaciones.php?all=1'),
}
