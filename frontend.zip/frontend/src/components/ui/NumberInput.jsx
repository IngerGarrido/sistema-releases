import React, { useState, useEffect } from 'react'

export const NumberInput = ({ value, onChange, ...props }) => {
  const [localValue, setLocalValue] = useState(value)
  useEffect(() => setLocalValue(value), [value])

  const handleChange = (e) => {
    setLocalValue(e.target.value)
    onChange(e)
  }

  return <input {...props} type="number" value={localValue} onChange={handleChange} />
}
