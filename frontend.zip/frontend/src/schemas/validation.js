import { z } from 'zod'

// ═══════════════════════════════════════════════════════════
// CLIENTES
// ═══════════════════════════════════════════════════════════
export const clienteSchema = z.object({
  id: z.number().optional(),
  tipo: z.enum(['Agencia', 'Directo']),
  nombre_agencia: z.string().optional(),
  nombre: z.string().optional(),
  url: z.string().url('URL inválida').optional().or(z.literal('')),
  rut: z.string().optional(),
  email: z.string().email('Email inválido').optional().or(z.literal('')),
  telefono: z.string().regex(/^[0-9+\-\s()]{6,20}$/, 'Teléfono inválido').optional().or(z.literal('')),
  direccion: z.string().optional(),
  notas: z.string().optional()
}).refine(
  (data) => {
    if (data.tipo === 'Agencia') return !!data.nombre_agencia?.trim()
    return !!data.nombre?.trim()
  },
  {
    message: 'El nombre es requerido',
    path: ['nombre_agencia']
  }
).refine(
  (data) => {
    if (data.tipo !== 'Agencia') return !!data.nombre?.trim()
    return true
  },
  {
    message: 'El nombre es requerido',
    path: ['nombre']
  }
)

// ═══════════════════════════════════════════════════════════
// PROYECTOS
// ═══════════════════════════════════════════════════════════
export const proyectoSchema = z.object({
  id: z.number().optional(),
  cliente_id: z.union([z.number(), z.string()]).transform(val => typeof val === 'string' ? parseInt(val) : val).refine(val => val && val > 0, 'Cliente requerido'),
  nombre: z.string().min(1, 'Nombre requerido'),
  descripcion: z.string().optional(),
  tipo_proyecto: z.string().optional(),
  servicio_id: z.union([z.number(), z.string()]).transform(val => typeof val === 'string' ? (val === '' ? undefined : parseInt(val)) : val).optional(),
  sitio_id: z.union([z.number(), z.string()]).transform(val => typeof val === 'string' ? (val === '' ? undefined : parseInt(val)) : val).optional(),
  estado: z.enum(['Cotizado', 'En curso', 'Terminado', 'Pausado', 'Cancelado']),
  fecha_inicio: z.union([z.string(), z.null(), z.undefined()]).transform(val => val === null || val === undefined ? '' : val).optional(),
  fecha_termino: z.union([z.string(), z.null(), z.undefined()]).transform(val => val === null || val === undefined ? '' : val).optional(),
  presupuesto: z.preprocess((val) => {
    if (val === undefined || val === null || val === '' || Number.isNaN(val)) return 0
    if (typeof val === 'string') {
      const parsed = parseFloat(val)
      return isNaN(parsed) ? 0 : parsed
    }
    return val
  }, z.number().optional())
}).refine(
  (data) => {
    if (data.fecha_inicio && data.fecha_termino) {
      return data.fecha_termino >= data.fecha_inicio
    }
    return true
  },
  {
    message: 'La fecha de término no puede ser anterior al inicio',
    path: ['fecha_termino']
  }
)

// ═══════════════════════════════════════════════════════════
// SERVICIOS
// ═══════════════════════════════════════════════════════════
export const servicioSchema = z.object({
  id: z.union([z.number(), z.string()]).transform(val => typeof val === 'string' ? parseInt(val)||undefined : val).optional(),
  nombre: z.string().min(1, 'Nombre requerido'),
  descripcion: z.string().optional(),
  precio: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform(val => {
    if (val === null || val === undefined || val === '') return 0
    const cleaned = String(val).replace(/[.,$\s]/g, '')
    const num = parseInt(cleaned)
    return isNaN(num) ? 0 : num
  }),
  unidad: z.string().optional(),
  activo: z.union([z.number(), z.string(), z.boolean()]).transform(val => {
    if (typeof val === 'boolean') return val ? 1 : 0
    if (typeof val === 'string') return val === '1' || val === 'true' ? 1 : 0
    return val || 0
  }).optional()
})

// ═══════════════════════════════════════════════════════════
// USUARIOS
// ═══════════════════════════════════════════════════════════
export const usuarioSchema = z.object({
  id: z.number().optional(),
  nombre: z.string().min(1, 'Nombre requerido'),
  email: z.string().email('Email inválido'),
  password: z.string().optional(),
  rol: z.enum(['admin', 'usuario']),
  activo: z.union([z.boolean(), z.number(), z.string()]).transform(val => {
    if (typeof val === 'boolean') return val
    if (typeof val === 'number') return val === 1
    if (typeof val === 'string') return val === '1' || val === 'true'
    return true
  }).optional()
}).refine(
  (data) => {
    if (!data.id && !data.password) return false
    return true
  },
  {
    message: 'La contraseña es requerida para nuevos usuarios',
    path: ['password']
  }
).refine(
  (data) => {
    if (data.password && data.password.length < 6) return false
    return true
  },
  {
    message: 'La contraseña debe tener al menos 6 caracteres',
    path: ['password']
  }
)

// ═══════════════════════════════════════════════════════════
// PAGOS
// ═══════════════════════════════════════════════════════════
export const cuotaSchema = z.object({
  id: z.union([z.number(), z.string()]).optional(),
  numero_cuota: z.union([z.number(), z.string()]).transform(val => parseInt(String(val)) || 1),
  tipo_pago: z.enum(['boleta', 'directo']).default('boleta'),
  boleta_num: z.union([z.string(), z.null(), z.undefined()]).transform(v => v ?? '').default(''),
  boleta_fecha: z.union([z.string(), z.null(), z.undefined()]).transform(v => v ?? '').default(''),
  boleta_monto: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform(val => {
    if (val === null || val === undefined || val === '') return 0
    const cleaned = String(val).replace(/[.,$\s]/g, '')
    const num = parseInt(cleaned)
    return isNaN(num) ? 0 : num
  }).default(0),
  pago_fecha: z.union([z.string(), z.null(), z.undefined()]).transform(v => v ?? '').default(''),
  pago_monto: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform(val => {
    if (val === null || val === undefined || val === '') return 0
    const cleaned = String(val).replace(/[.,$\s]/g, '')
    const num = parseInt(cleaned)
    return isNaN(num) ? 0 : num
  }).default(0),
  estado: z.enum(['Pendiente', 'Pagado', 'Vencido']).default('Pendiente')
})

export const pagoSchema = z.object({
  id: z.union([z.number(), z.string()]).transform(val => typeof val === 'string' ? parseInt(val)||undefined : val).optional(),
  cliente_id: z.union([z.number(), z.string()]).transform(val => parseInt(String(val)) || 0).refine(val => val > 0, 'Cliente requerido'),
  proyecto_id: z.union([z.number(), z.string()]).transform(val => parseInt(String(val)) || 0).refine(val => val > 0, 'Proyecto requerido'),
  descripcion: z.string().optional().default(''),
  monto_total: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform(val => {
    if (val === null || val === undefined || val === '') return 0
    const cleaned = String(val).replace(/[\.,$\s]/g, '')
    const num = parseInt(cleaned)
    return isNaN(num) ? 0 : num
  }).default(0),
  tipo_pago: z.enum(['boleta', 'directo']).default('boleta'),
  cuotas: z.array(cuotaSchema).min(1, 'Debe agregar al menos una cuota')
})

// ═══════════════════════════════════════════════════════════
// COTIZACIONES
// ═══════════════════════════════════════════════════════════
export const cotizacionItemSchema = z.object({
  descripcion: z.string().min(1, 'Descripción requerida'),
  cantidad: z.number().min(1, 'Cantidad debe ser mayor a 0'),
  unidad: z.string().optional(),
  precio_unitario: z.number().min(0, 'Precio debe ser mayor o igual a 0'),
  descuento: z.number().min(0, 'Descuento debe ser mayor o igual a 0')
})

export const cotizacionSchema = z.object({
  id: z.any().optional(),
  numero: z.string().optional(),
  proyecto_id: z.union([z.number(), z.string(), z.null()]).transform(val => {
    if (val === null || val === '' || val === undefined) return null
    if (typeof val === 'string') {
      const num = parseInt(val)
      return isNaN(num) ? null : num
    }
    return val
  }).optional(),
  cliente_id: z.union([z.number(), z.string()]).transform(val => typeof val === 'string' ? parseInt(val) : val).refine(val => val && val > 0, 'Cliente requerido'),
  fecha: z.string().optional(),
  fecha_validez: z.string().optional(),
  estado: z.enum(['Pendiente', 'Aceptada', 'Rechazada', 'Expirada']),
  items: z.array(cotizacionItemSchema).min(1, 'Debe agregar al menos un ítem'),
  notas: z.string().optional(),
  descuento_global: z.union([z.number(), z.string()]).transform(val => typeof val === 'string' ? (val === '' ? 0 : parseFloat(val)) : val).refine(val => val !== undefined && val !== null && val >= 0, 'Descuento debe ser mayor o igual a 0'),
  plantilla_id: z.union([z.number(), z.string(), z.null()]).transform(val => {
    if (val === null || val === '' || val === undefined) return null
    if (typeof val === 'string') {
      const num = parseInt(val)
      return isNaN(num) ? null : num
    }
    return val
  }).optional()
})