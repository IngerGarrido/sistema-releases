// Compat shim — el contenido real ahora vive en ./ui/
// Mantenemos este archivo para no tocar los ~15 componentes
// que hacen `import { ... } from './UI.jsx'`.
export * from './ui/index.js'
