import { useState, useEffect } from 'react'
import { useLocalState, useSort } from '../hooks/useLocalState.js'
import { useUnsavedWarning } from '../hooks/useUnsavedWarning.js'
import { useBulkSelect } from '../hooks/useBulkSelect.js'
import { useDebouncedValue } from '../hooks/useDebouncedValue.js'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { api } from '../assets/js/api.js'
import { clp } from '../assets/js/helpers.js'
import { Badge,DataPanel,Acciones,Modal,Confirm,Toast,Field,InpCLP,BotonesGuardar,useToast,Skeleton } from './UI.jsx'
import { useServicios, useCrearServicio, useEditarServicio, useBorrarServicio } from '../hooks/useQueryApi.js'
import { servicioSchema } from '../schemas/validation.js'

export default function Servicios() {
  const [pagina, setPagina] = useState(1)
  const [perPage, setPerPage] = useLocalState('servicios:perPage', 10)
  const [busqueda,setBusqueda]=useLocalState('servicios:busqueda', '')
  // Debounce de la búsqueda para enviar al backend (hook reutilizable)
  const qDebounced = useDebouncedValue(busqueda, 300)
  useEffect(() => { setPagina(1) }, [qDebounced])
  const { data: respuesta, isLoading: loading } = useServicios({ page: pagina, per_page: perPage, q: qDebounced })
  const lista = Array.isArray(respuesta?.data) ? respuesta.data : (Array.isArray(respuesta) ? respuesta : [])
  const totalPaginas = respuesta?.pagination?.total_pages || 1
  const totalRegistros = respuesta?.pagination?.total ?? lista.length
  const [modal,setModal]=useState(false)
  const [modalKey,setModalKey]=useState(0)
  const [editando,setEditando]=useState(null)
  const [del,setDel]=useState(null)
  const [delMultiple, setDelMultiple] = useState(false)
  const [toast,showToast]=useToast()

  const { register, handleSubmit, reset, getValues, control, formState: { errors, isDirty } } = useForm({
    resolver: zodResolver(servicioSchema),
    defaultValues: {
      nombre: '',
      descripcion: '',
      precio: 0,
      unidad: ''
    }
  })

  useUnsavedWarning(modal && isDirty)
  const crearServicio = useCrearServicio()
  const editarServicio = useEditarServicio()
  const borrarServicio = useBorrarServicio()

  const abrir = (s) => {
    if (s) {
      reset({ ...s, precio: Number(s.precio) || 0 })
      setEditando(s)
    } else {
      reset({
        nombre: '',
        descripcion: '',
        precio: 0,
        unidad: ''
      })
      setEditando(null)
    }
    setModalKey(k=>k+1)
    setModal(true)
  }

  const guardar = async (data) => {
    try {
      const id = data.id || editando?.id
      if (id) {
        await editarServicio.mutateAsync({ id, data: { ...data, id } })
      } else {
        await crearServicio.mutateAsync(data)
      }
      setModal(false)
      showToast('Servicio guardado')
    } catch(err) {
      showToast(err.message || 'Error al guardar', 'err')
    }
  }

  const onError = (errs) => {
    const msgs = Object.values(errs).map(e => e?.message).filter(m => typeof m === 'string')
    if (msgs.length) showToast(msgs[0], 'err')
  }

  // Búsqueda ahora es server-side (params.q). No filtrar de nuevo aquí.
  const filtrados = lista

  const { sorted: filtradosOrdenados, sortKey, sortDir, toggle: sortToggle } = useSort(filtrados)

  const borrar=async()=>{
    try{await borrarServicio.mutateAsync(del);showToast('Eliminado')}catch(err){showToast(err.message,'err')}
    setDel(null)
  }

  const {
    seleccionados,
    toggle: toggleSeleccion,
    toggleAll: seleccionarTodos,
    clear: clearSeleccion,
  } = useBulkSelect(filtrados, busqueda)

  const eliminarSeleccionados = async () => {
    if (seleccionados.size === 0) return
    setDelMultiple(true)
  }

  const confirmarEliminarMultiple = async () => {
    setDelMultiple(false)
    if (seleccionados.size === 0) return

    try {
      const ids = Array.from(seleccionados)
      const total = ids.length
      for (const id of ids) {
        await borrarServicio.mutateAsync(id)
      }
      showToast(`${total} servicios eliminados`)
      clearSeleccion()
    } catch(err) {
      showToast(err.message, 'err')
    }
  }
  return (
    <div>
      {toast&&<Toast {...toast}/>}
      <p className="svc-hint">Los servicios aparecen al crear proyectos y cotizaciones, rellenando precio automáticamente.</p>
      
      {/* Skeleton loading */}
      {loading && (
        <div className="card" style={{padding:'16px'}}>
          <div style={{marginBottom:'16px'}}>
            <Skeleton className="skeleton-title" />
          </div>
          {[...Array(5)].map((_,i)=>(
            <Skeleton key={i} className="skeleton-row" />
          ))}
        </div>
      )}
      
      {/* Barra de acciones masivas */}
      {!loading && filtrados.length > 0 && (
        <div className="bulk-actions-bar">
          <label>
            <input
              type="checkbox"
              checked={seleccionados.size === filtrados.length && filtrados.length > 0}
              onChange={seleccionarTodos}
              aria-label="Seleccionar todos"
            />
            <span>Todos</span>
          </label>
          {seleccionados.size > 0 && (
            <>
              <span className="selection-count">| {seleccionados.size} seleccionados</span>
              <button
                onClick={eliminarSeleccionados}
                className="btn-bulk-delete"
              >
                🗑️ Eliminar ({seleccionados.size})
              </button>
            </>
          )}
        </div>
      )}
      
      <DataPanel
        title="Servicios" count={filtrados.length} total={totalRegistros}
        busqueda={busqueda} setBusqueda={setBusqueda}
        placeholder="Buscar por nombre o descripción..."
        onAdd={()=>abrir(null)} addLabel="Nuevo servicio"
        onExcel={()=>api.exportar('servicios')}
        loading={loading}
        sort={{ key: sortKey, dir: sortDir, toggle: sortToggle }}
        pagination={{
          actual: pagina,
          totalPaginas: totalPaginas,
          total: totalRegistros,
          perPage: respuesta?.pagination?.per_page || perPage,
          onChange: (n) => setPagina(n)
        }}
        onPerPageChange={n => { setPerPage(n); setPagina(1) }}
        cols={[
          {l:<input type="checkbox" checked={seleccionados.size === filtrados.length && filtrados.length > 0} onChange={seleccionarTodos} aria-label="Seleccionar todos los servicios"/>, w:40},
          {l:'Servicio', sortKey:'nombre'},
          {l:'Descripción', sortKey:'descripcion'},
          {l:'Precio', r:true, sortKey:'precio'},
          {l:'Estado', sortKey:'activo'},
          {l:'Acciones',r:true}
        ]}
        rows={filtradosOrdenados.map(s=>[
          <input
            type="checkbox"
            checked={seleccionados.has(s.id)}
            onChange={() => toggleSeleccion(s.id)}
            aria-label={`Seleccionar servicio ${s.nombre}`}
          />,
          <span style={{fontWeight:700,color:'var(--txt)'}}>{s.nombre}</span>,
          <span className="tbl-muted">{s.descripcion||'—'}</span>,
          <strong style={{color:'var(--txt)'}}>{clp(s.precio)}</strong>,
          <Badge s={s.activo?'Activo':'Inactivo'}/>,
          <Acciones onEdit={()=>abrir(s)} onDel={()=>setDel(s.id)}/>,
        ])}
        vacio="No se encontraron servicios"
      />
      {modal&&(
        <Modal title={editando ? 'Editar servicio' : 'Nuevo servicio'} onClose={()=>setModal(false)} key={modalKey}>
          <form onSubmit={handleSubmit(guardar, onError)}>
            <div className="form-row">
              <Field label="Nombre del servicio" required>
                <input className="inp" {...register('nombre')} />
                {errors.nombre && <span className="field-err">{errors.nombre.message}</span>}
              </Field>
              <Field label="Descripción">
                <textarea className="tex" {...register('descripcion')} />
              </Field>
              <Field label="Precio (CLP)" half>
                <Controller
                  name="precio"
                  control={control} // Asegúrate de sacar 'control' de useForm: const { control, ... } = useForm(...)
                  render={({ field }) => (
                    <InpCLP 
                      value={field.value} 
                      onChange={field.onChange} 
                      onBlur={field.onBlur} 
                      name={field.name}
                      ref={field.ref}
                    />
                  )}
                />
              {errors.precio && <span className="field-err">{errors.precio.message}</span>}
              </Field>
              <Field label="Estado" half>
                <select className="sel" {...register('activo', { valueAsNumber: true })}>
                  <option value={1}>Activo</option>
                  <option value={0}>Inactivo</option>
                </select>
              </Field>
            </div>
            <BotonesGuardar onCancel={()=>setModal(false)} isPending={crearServicio.isPending || editarServicio.isPending} />
          </form>
        </Modal>
      )}
      {del&&<Confirm msg="¿Eliminar este servicio?" onSi={borrar} onNo={()=>setDel(null)}/>}
      {delMultiple&&(
        <Confirm
          msg={`¿Eliminar ${seleccionados.size} servicios?`}
          onSi={confirmarEliminarMultiple}
          onNo={()=>setDelMultiple(false)}
        />
      )}
    </div>
  )
}