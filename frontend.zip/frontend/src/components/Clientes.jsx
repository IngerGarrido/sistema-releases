import { useState, useEffect, useMemo } from 'react'
import { useLocalState, useSort } from '../hooks/useLocalState.js'
import { useUnsavedWarning } from '../hooks/useUnsavedWarning.js'
import { useBulkSelect } from '../hooks/useBulkSelect.js'
import { useDebouncedValue } from '../hooks/useDebouncedValue.js'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { api } from '../assets/js/api.js'
import { Badge, DataPanel, Acciones, Modal, Confirm, Toast, Field, BotonesGuardar, useToast, Skeleton } from './UI.jsx'
import { useClientes, useCrearCliente, useEditarCliente, useBorrarCliente } from '../hooks/useQueryApi.js'
import { clienteSchema } from '../schemas/validation.js'

export default function Clientes() {
  // 1. ESTADOS
  const [pagina, setPagina] = useState(1)
  const [perPage, setPerPage] = useLocalState('clientes:perPage', 10)
  const [busqueda, setBusqueda] = useLocalState('clientes:busqueda', '')
  const [filtro, setFiltro] = useLocalState('clientes:filtro', 'Todos')
  const [modal, setModal] = useState(false)
  const [del, setDel] = useState(null)
  const [delMultiple, setDelMultiple] = useState(false)
  const [toast, showToast] = useToast()

  // Búsqueda server-side con debounce (hook reutilizable)
  const qDebounced = useDebouncedValue(busqueda, 300)
  useEffect(() => { setPagina(1) }, [qDebounced])

  const { data: respuesta, isLoading: loading } = useClientes({ page: pagina, per_page: perPage, q: qDebounced })
  const lista = Array.isArray(respuesta?.data) ? respuesta.data : []


  // 3. FORMULARIO
  const { register, handleSubmit, reset, formState: { errors, isDirty }, watch, setValue } = useForm({
    resolver: zodResolver(clienteSchema),
    defaultValues: { tipo: 'Agencia', nombre_agencia: '', nombre: '', url: '', rut: '', email: '', telefono: '', direccion: '', notas: '' }
  })
  const tipo = watch('tipo')
  useUnsavedWarning(modal && isDirty)
  const clienteId = watch('id')

  // 4. MUTACIONES
  const crearCliente = useCrearCliente()
  const editarCliente = useEditarCliente()
  const borrarCliente = useBorrarCliente()

  // 5. FUNCIONES
  const abrir = (c) => {
    if (c) reset(c)
    else reset({ tipo: 'Agencia', nombre_agencia: '', nombre: '', url: '', rut: '', email: '', telefono: '', direccion: '', notas: '' })
    setModal(true)
  }

  const guardar = async (data) => {
    try {
      if (data.id) await editarCliente.mutateAsync({ id: data.id, data })
      else await crearCliente.mutateAsync(data)
      setModal(false)
      showToast('Cliente guardado')
    } catch(err) {
      showToast(err.message, 'err')
    }
  }

  const borrar = async () => {
    try {
      await borrarCliente.mutateAsync(del)
      showToast('Eliminado')
    } catch(err) {
      showToast(err.message, 'err')
    }
    setDel(null)
  }

  // 6. FILTRADO LOCAL: la búsqueda de texto ya viene filtrada server-side (q).
  // Solo aplicamos el filtro de tipo (Todos / Agencia / Directo) sobre la página actual.
  // NOTA: como el sort es client-side, solo ordena la página visible — si se necesita
  // ordenar por todo el dataset hay que mover sort al backend (TODO futuro).
  const filtrados = useMemo(
    () => lista.filter(c => filtro === 'Todos' || c.tipo === filtro),
    [lista, filtro]
  )

  const { sorted: filtradosOrdenados, sortKey, sortDir, toggle: sortToggle } = useSort(filtrados)

  // 7. SELECCIÓN MASIVA (hook reutilizable; resetDep combina busqueda+filtro)
  const {
    seleccionados,
    toggle: toggleSeleccion,
    toggleAll: seleccionarTodos,
    clear: clearSeleccion,
  } = useBulkSelect(filtrados, `${busqueda}|${filtro}`)

  const confirmarEliminarMultiple = async () => {
    setDelMultiple(false)
    try {
      const total = seleccionados.size
      for (const id of Array.from(seleccionados)) {
        await borrarCliente.mutateAsync(id)
      }
      showToast(`${total} eliminados`)
      clearSeleccion()
    } catch(err) {
      showToast(err.message, 'err')
    }
  }

  return (
    <div>
      {toast && <Toast {...toast} />}
      
      {loading && (
        <div className="card" style={{ padding: '16px' }}>
          <Skeleton className="skeleton-title" style={{ marginBottom: '16px' }} />
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="skeleton-row" />)}
        </div>
      )}
      
      {!loading && (
        <>
          {filtrados.length > 0 && (
            <div className="bulk-actions-bar">
              <label>
                <input type="checkbox" checked={seleccionados.size === filtrados.length && filtrados.length > 0} onChange={seleccionarTodos} aria-label="Seleccionar todos" />
                <span>Todos</span>
              </label>
              {seleccionados.size > 0 && (
                <>
                  <span className="selection-count">| {seleccionados.size} seleccionados</span>
                  <button onClick={() => setDelMultiple(true)} className="btn-bulk-delete">
                    🗑️ Eliminar ({seleccionados.size})
                  </button>
                </>
              )}
            </div>
          )}

          <DataPanel
            title="Clientes"
            count={filtrados.length}
            loading={loading}
            busqueda={busqueda}
            setBusqueda={setBusqueda}
            onAdd={() => abrir(null)}
            onExcel={() => api.exportar('clientes')}
            filters={['Todos', 'Agencia', 'Directo']} 
            activeFilter={filtro} 
            onFilter={setFiltro}
            pagination={{
              actual: pagina,
              totalPaginas: respuesta?.pagination?.total_pages || 1,
              total: respuesta?.pagination?.total || 0,
              perPage: respuesta?.pagination?.per_page || perPage,
              onChange: (n) => setPagina(n)
            }}
           
            onPerPageChange={n => { setPerPage(n); setPagina(1) }}
            sort={{ key: sortKey, dir: sortDir, toggle: sortToggle }}
            cols={[
              { l: <input type="checkbox" checked={seleccionados.size === filtrados.length && filtrados.length > 0} onChange={seleccionarTodos} aria-label="Seleccionar todos los clientes" />, w: 40 },
              { l: 'Tipo', sortKey: 'tipo' },
              { l: 'Agencia / Cliente', sortKey: 'nombre_agencia' },
              { l: 'Web / RUT', sortKey: 'url' },
              { l: 'Email', sortKey: 'email' },
              { l: 'Acciones', r: true }
            ]}
            rows={filtradosOrdenados.map(c => [
              <input type="checkbox" checked={seleccionados.has(c.id)} onChange={() => toggleSeleccion(c.id)} aria-label={`Seleccionar cliente ${c.tipo === 'Agencia' ? (c.nombre_agencia || c.nombre) : c.nombre}`} />,
              <Badge s={c.tipo} />,
              <span style={{ fontWeight: 700 }}>{c.tipo === 'Agencia' ? (c.nombre_agencia || c.nombre) : c.nombre}</span>,
              c.tipo === 'Agencia' ? <span className="tbl-link">{c.url || '—'}</span> : <span>{c.rut || '—'}</span>,
              <span>{c.email || '—'}</span>,
              <Acciones onEdit={() => abrir(c)} onDel={() => setDel(c.id)} />,
            ])}
            vacio="No se encontraron registros"
          />
        </>
      )}

      {modal && (
        <Modal title={clienteId ? "Editar cliente" : "Nuevo cliente"} onClose={() => setModal(false)}>
          <form onSubmit={handleSubmit(guardar)}>
            <div className="type-row">
              {['Agencia', 'Directo'].map(t => (
                <button key={t} type="button" className={`type-btn${tipo === t ? ' type-btn--on' : ''}`}
                  onClick={() => setValue('tipo', t)}>
                  {t === 'Agencia' ? '🏢 Agencia' : '👤 Directo'}
                </button>
              ))}
            </div>
            <div className="form-row">
              {tipo === 'Agencia' ? (
                <>
                  <Field label="Nombre de la agencia" required><input className="inp" {...register('nombre_agencia')} /></Field>
                  <Field label="Sitio Web"><input className="inp" {...register('url')} /></Field>
                  <Field label="RUT" half><input className="inp" {...register('rut')} /></Field>
                  <Field label="Email" half><input className="inp" {...register('email')} /></Field>
                  <Field label="Teléfono" half><input className="inp" {...register('telefono')} /></Field>
                </>
              ) : (
                <>
                  <Field label="Nombre completo" required><input className="inp" {...register('nombre')} /></Field>
                  <Field label="RUT" half><input className="inp" {...register('rut')} /></Field>
                  <Field label="Email" half><input className="inp" {...register('email')} /></Field>
                  <Field label="Teléfono" half><input className="inp" {...register('telefono')} /></Field>
                </>
              )}
              <Field label="Notas"><textarea className="tex" {...register('notas')} /></Field>
            </div>
            <BotonesGuardar onCancel={() => setModal(false)} isPending={crearCliente.isPending || editarCliente.isPending} />
          </form>
        </Modal>
      )}

      {del && <Confirm msg="¿Eliminar este cliente?" onSi={borrar} onNo={() => setDel(null)} />}
      {delMultiple && <Confirm msg={`¿Eliminar ${seleccionados.size} clientes?`} onSi={confirmarEliminarMultiple} onNo={() => setDelMultiple(false)} />}
    </div>
  )
}