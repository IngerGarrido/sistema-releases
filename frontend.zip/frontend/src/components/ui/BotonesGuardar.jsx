import React from 'react'

export function BotonesGuardar({ onCancel, isPending }) {
  return (
    <div className="form-btns">
      <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={isPending}>Cancelar</button>
      <button type="submit" className="btn btn-green" disabled={isPending} aria-busy={isPending ? 'true' : undefined}>
        {isPending ? 'Guardando…' : 'Guardar'}
      </button>
    </div>
  )
}
