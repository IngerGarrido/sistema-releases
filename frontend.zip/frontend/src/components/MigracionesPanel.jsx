import { useState, useEffect } from 'react'
import { api } from '../assets/js/api.js'
import { I } from '../assets/js/helpers.js'
import { Ic, Toast, useToast } from './UI.jsx'

export default function MigracionesPanel() {
  const [status, setStatus] = useState(null)
  const [loading, setLoading] = useState(false)
  const [running, setRunning] = useState(false)
  const [logs, setLogs] = useState([])
  const [showDetails, setShowDetails] = useState(false)
  const [toast, showToast] = useToast()

  const cargar = async () => {
    setLoading(true)
    try { setStatus(await api.getMigraciones()) }
    catch (e) { showToast(e.message, 'err') }
    finally   { setLoading(false) }
  }

  useEffect(() => { cargar() }, [])

  const aplicar = async () => {
    if (!status?.por_aplicar) return
    if (!confirm(`Se aplicarán ${status.por_aplicar} cambio(s) pendientes a la base de datos. Es seguro hacerlo. ¿Continuar?`)) return
    setRunning(true); setLogs([])
    try {
      const r = await api.aplicarMigraciones()
      setLogs(r.logs || [])
      setStatus(r.status)
      showToast(`${r.aplicadas} cambio(s) aplicados`)
    } catch (e) {
      if (e.message) showToast(e.message, 'err')
      cargar()
    } finally { setRunning(false) }
  }

  if (loading || !status) {
    return <div style={{ padding: 12, color: 'var(--txt2)', fontFamily: 'var(--font)', fontSize: 13 }}>Consultando estado de la base de datos…</div>
  }

  const pendientes = status.por_aplicar
  return (
    <div className="upd-panel" style={{ fontFamily: 'var(--font)' }}>
      {toast && <Toast {...toast} />}

      {pendientes > 0 ? (
        <MigState
          status="info"
          title={`${pendientes} cambio(s) pendientes en la base de datos`}
          desc="Estos son ajustes técnicos al esquema de la base que llegaron con la última versión. Es seguro aplicarlos en cualquier momento."
        />
      ) : (
        <MigState
          status="ok"
          title="Base de datos al día"
          desc={`${status.aplicadas} de ${status.total} cambios aplicados`}
        />
      )}

      <div className="upd-actions">
        {pendientes > 0 && (
          <button className="btn-pri" onClick={aplicar} disabled={running}>
            {running
              ? <><Ic d={I.loader} size={14}/> Aplicando…</>
              : <><Ic d={I.refresh} size={14}/> Aplicar cambios pendientes</>}
          </button>
        )}
        <button className="btn-sec" onClick={cargar} disabled={running}>
          <Ic d={I.refresh} size={13}/> Revisar de nuevo
        </button>
        <button className="upd-link" onClick={() => setShowDetails(s => !s)}>
          {showDetails ? 'Ocultar historial' : 'Ver historial'}
        </button>
      </div>

      {showDetails && (
        <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 6 }}>
          {status.items.map(it => (
            <div key={it.archivo} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '8px 12px', border: '1px solid var(--card-b)', borderRadius: 8,
              background: it.aplicada ? 'var(--card)' : '#fff7e6',
              fontFamily: 'var(--font)'
            }}>
              <span style={{
                width: 22, height: 22, borderRadius: '50%',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                background: it.aplicada ? '#40c057' : '#fab005', color: '#fff', flexShrink: 0
              }}>
                <Ic d={it.aplicada ? I.check : I.warn} size={12}/>
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontFamily: 'var(--mono, monospace)' }}>{it.archivo}</div>
                {it.aplicada && it.ejecutada_at && (
                  <div style={{ fontSize: 11, color: 'var(--txt2)' }}>
                    Aplicado el {it.ejecutada_at}{it.duracion_ms != null ? ` · ${it.duracion_ms}ms` : ''}
                  </div>
                )}
                {!it.aplicada && <div style={{ fontSize: 11, color: '#7a5a00' }}>Pendiente</div>}
              </div>
            </div>
          ))}
        </div>
      )}

      {logs.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <div style={{ fontSize: 12, color: 'var(--txt2)', marginBottom: 4 }}>Log de la aplicación:</div>
          <pre style={{
            margin: 0, padding: 10, background: '#0f172a', color: '#cbd5e1',
            borderRadius: 6, fontSize: 12, maxHeight: 220, overflow: 'auto',
            fontFamily: 'var(--mono, ui-monospace, SFMono-Regular, monospace)'
          }}>{logs.join('\n')}</pre>
        </div>
      )}
    </div>
  )
}

function MigState({ status, title, desc }) {
  const styles = {
    ok:   { bg: '#e6fcf5', bd: '#69db7c', ico: I.check,   color: '#16a34a' },
    info: { bg: '#e7f5ff', bd: '#74c0fc', ico: I.refresh, color: '#1971c2' },
  }[status] || {}
  return (
    <div style={{
      display: 'flex', gap: 14, alignItems: 'flex-start',
      padding: '14px 16px', borderRadius: 10,
      background: styles.bg, border: '1px solid ' + styles.bd,
      marginBottom: 14, fontFamily: 'var(--font)'
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: '50%', flexShrink: 0,
        background: '#fff', color: styles.color,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center'
      }}>
        <Ic d={styles.ico} size={16}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--txt)' }}>{title}</div>
        {desc && <div style={{ fontSize: 13, color: 'var(--txt2)', marginTop: 4, lineHeight: 1.5 }}>{desc}</div>}
      </div>
    </div>
  )
}
