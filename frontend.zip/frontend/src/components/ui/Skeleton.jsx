import React from 'react'

export const Skeleton = ({ className, style }) => (
  <div className={`skeleton ${className||''}`} style={style} />
)
