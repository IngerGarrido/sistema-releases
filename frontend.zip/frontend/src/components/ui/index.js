// Barrel: re-exports de todos los componentes de UI.
// Mantiene compatibilidad con `import { ... } from '../UI.jsx'`.

export { COLORES_BADGE, I, clp } from '../../assets/js/helpers.js'

export { Ic } from './Ic.jsx'
export { Badge } from './Badge.jsx'
export { Field } from './Field.jsx'
export { Skeleton } from './Skeleton.jsx'
export { EmptyState } from './EmptyState.jsx'
export { NumberInput } from './NumberInput.jsx'
export { InpCLP } from './InpCLP.jsx'
export { Modal, Confirm } from './Modal.jsx'
export { Toast, useToast } from './Toast.jsx'
export { StatCard } from './StatCard.jsx'
export { Pagination } from './Pagination.jsx'
export { DataPanel } from './DataPanel.jsx'
export { Acciones, IBtn } from './Acciones.jsx'
export { BotonesGuardar } from './BotonesGuardar.jsx'
export { SelCliente } from './SelCliente.jsx'
