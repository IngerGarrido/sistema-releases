import React, { useState, useRef, useEffect, useCallback } from 'react'
import { I } from '../../assets/js/helpers.js'
import { Ic } from './Ic.jsx'

export function Toast({ msg, type='ok' }) {
  if (!msg) return null
  return (
    <div
      className={`toast toast-${type}`}
      role={type==='err' ? 'alert' : 'status'}
      aria-live={type==='err' ? 'assertive' : 'polite'}
      aria-atomic="true"
    >
      <Ic d={type==='err'?I.x:I.ok} size={14} stroke="#fff"/>{msg}
    </div>
  )
}

/**
 * useToast — cola FIFO: si llegan varios toasts seguidos, se muestran uno
 * tras otro (cada uno 3s) en vez de superponerse en la misma posición.
 * API legacy intacta: const [t, showToast] = useToast()
 */
export function useToast() {
  const [current, setCurrent] = useState(null)
  const queueRef = useRef([])
  const timerRef = useRef(null)
  const showingRef = useRef(false)

  const showNext = useCallback(() => {
    const next = queueRef.current.shift()
    if (!next) { showingRef.current = false; setCurrent(null); return }
    showingRef.current = true
    setCurrent(next)
    timerRef.current = setTimeout(() => { showingRef.current = false; showNext() }, 3000)
  }, [])

  const show = useCallback((msg, type='ok') => {
    queueRef.current.push({ msg, type })
    if (!showingRef.current) showNext()
  }, [showNext])

  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current) }, [])

  return [current, show]
}
