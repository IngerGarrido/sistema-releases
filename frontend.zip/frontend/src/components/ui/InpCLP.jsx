import React, { useState, useEffect } from 'react'

export const InpCLP = React.forwardRef(function InpCLP(
  { value, onChange, onBlur, name, placeholder = '0', style }, ref
) {
  // Función para formatear CLP
  const format = (v) => {
    const n = parseInt(String(v).replace(/\D/g, ''));
    return isNaN(n) ? '' : n.toLocaleString('es-CL');
  };

  // Estado local para lo que se ve
  const [display, setDisplay] = useState(() => format(value));

  // Sincronizar cuando el valor cambie externamente (ej: al elegir un servicio)
  useEffect(() => {
    const formatted = format(value);
    if (formatted !== display) {
      setDisplay(formatted);
    }
  }, [value]);

  const handleChange = (e) => {
    const raw = e.target.value.replace(/\D/g, '');
    const num = raw ? parseInt(raw) : 0;

    // Actualizamos el texto visual inmediatamente (sin esperar a React)
    setDisplay(raw ? num.toLocaleString('es-CL') : '');

    // Informamos a RHF
    if (onChange) onChange(num);
  };

  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center', width: '100%' }}>
      <span style={{
        position: 'absolute', left: 8, color: 'var(--txt2)',
        fontSize: 12, pointerEvents: 'none', zIndex: 1, opacity: 0.7
      }}>$</span>
      <input
        ref={ref}
        name={name}
        className="inp"
        value={display}
        onChange={handleChange}
        onBlur={onBlur}
        placeholder={placeholder}
        inputMode="numeric"
        style={{
          paddingLeft: 18,
          textAlign: 'right',
          width: '100%',
          ...style
        }}
      />
    </div>
  );
});
