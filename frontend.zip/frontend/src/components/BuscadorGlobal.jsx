import { useState, useEffect, useCallback, useRef } from 'react'
import { api } from '../assets/js/api.js'
import { I } from '../assets/js/helpers.js'
import { Ic } from './UI.jsx'

export default function BuscadorGlobal() {
  const [abierto, setAbierto] = useState(false)
  const [query, setQuery] = useState('')
  const [resultados, setResultados] = useState([])
  const [cargando, setCargando] = useState(false)
  const [seleccionado, setSeleccionado] = useState(0)
  const inputRef = useRef(null)
  const modalRef = useRef(null)
  const itemsRef = useRef([])

  // Abrir con Ctrl+K o Cmd+K
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault()
        setAbierto(true)
      }
      if (e.key === 'Escape') {
        setAbierto(false)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  // Focus en input al abrir
  useEffect(() => {
    if (abierto && inputRef.current) {
      inputRef.current.focus()
    }
  }, [abierto])

  // Buscar con debounce
  useEffect(() => {
    if (!query.trim()) {
      setResultados([])
      return
    }

    const timer = setTimeout(async () => {
      setCargando(true)
      try {
        const data = await api.buscarGlobal(query)
        setResultados(data || [])
        setSeleccionado(0)
      } catch (e) {
        setResultados([])
      } finally {
        setCargando(false)
      }
    }, 200)

    return () => clearTimeout(timer)
  }, [query])

  // Scroll automático al navegar con teclado
  useEffect(() => {
    itemsRef.current[seleccionado]?.scrollIntoView({ block: 'nearest' })
  }, [seleccionado])

  // Navegación con flechas
  const handleKeyDown = useCallback((e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setSeleccionado(prev => Math.min(prev + 1, resultados.length - 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setSeleccionado(prev => Math.max(prev - 1, 0))
    } else if (e.key === 'Enter') {
      e.preventDefault()
      const item = resultados[seleccionado]
      if (item) navegar(item)
    }
  }, [resultados, seleccionado])

  const navegar = (item) => {
    setAbierto(false)
    setQuery('')
    
    // Emitir evento para navegación
    window.dispatchEvent(new CustomEvent('navegar', { 
      detail: { panel: item.tipo, id: item.id }
    }))
  }

  const getIcono = (tipo) => {
    switch(tipo) {
      case 'clientes': return <Ic d={I.users} size={14}/>
      case 'proyectos': return <Ic d={I.projects} size={14}/>
      case 'cotizaciones': return <Ic d={I.pdf} size={14}/>
      case 'pagos': return <Ic d={I.pay} size={14}/>
      case 'servicios': return <Ic d={I.svc} size={14}/>
      default: return <Ic d={I.fileText} size={14}/>
    }
  }

  if (!abierto) return null

  return (
    <div
      className="buscador-overlay"
      onClick={() => setAbierto(false)}
      ref={modalRef}
    >
      <div
        className="buscador-modal"
        onClick={e => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label="Buscador global"
      >
        <div className="buscador-header">
          <Ic d={I.search} size={18} />
          <input
            ref={inputRef}
            type="text"
            placeholder="Buscar clientes, proyectos, cotizaciones, pagos..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            className="buscador-input"
            role="combobox"
            aria-expanded={resultados.length > 0}
            aria-controls="buscador-resultados-list"
            aria-autocomplete="list"
            aria-activedescendant={resultados.length > 0 ? `buscador-item-${seleccionado}` : undefined}
            aria-label="Buscar"
          />
          <kbd className="buscador-kbd" aria-hidden="true">ESC</kbd>
        </div>

        <div className="buscador-resultados" id="buscador-resultados-list" role="listbox">
          {cargando && (
            <div className="buscador-loading">
              <div className="shimmer" style={{height: 40, borderRadius: 8, margin: '8px 0'}} />
              <div className="shimmer" style={{height: 40, borderRadius: 8, margin: '8px 0'}} />
            </div>
          )}

          {!cargando && resultados.length === 0 && query && (
            <div className="buscador-empty">
              No se encontraron resultados para "{query}"
            </div>
          )}

          {!cargando && resultados.map((item, idx) => (
            <div
              key={`${item.tipo}-${item.id}`}
              id={`buscador-item-${idx}`}
              ref={el => itemsRef.current[idx] = el}
              className={`buscador-item ${idx === seleccionado ? 'seleccionado' : ''}`}
              onClick={() => navegar(item)}
              onMouseEnter={() => setSeleccionado(idx)}
              role="option"
              aria-selected={idx === seleccionado}
            >
              <span className="buscador-icono">{getIcono(item.tipo)}</span>
              <div className="buscador-info">
                <div className="buscador-titulo">{item.titulo}</div>
                <div className="buscador-meta">
                  {item.tipo} • {item.subtitulo}
                </div>
              </div>
              <Ic d={I.right} size={16} className="buscador-flecha" />
            </div>
          ))}

          {!query && !cargando && (
            <div className="buscador-hints">
              <p>💡 <strong>Pro tip:</strong> Usa las flechas ↑↓ para navegar y Enter para seleccionar</p>
              <div className="buscador-atajos">
                <span><kbd>Ctrl</kbd> + <kbd>K</kbd> para buscar</span>
                <span><kbd>Esc</kbd> para cerrar</span>
              </div>
            </div>
          )}
        </div>

        {resultados.length > 0 && (
          <div className="buscador-footer">
            {resultados.length} resultado{resultados.length !== 1 ? 's' : ''}
          </div>
        )}
      </div>
    </div>
  )
}
