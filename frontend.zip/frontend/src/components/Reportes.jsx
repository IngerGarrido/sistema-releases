import { useState, useMemo, lazy, Suspense } from 'react'
import { clp, I } from '../assets/js/helpers.js'
import { Ic, StatCard, Skeleton, Badge, EmptyState } from './UI.jsx'
import { useReportes } from '../hooks/useQueryApi.js'
import { exportCSV, hoy } from '../assets/js/csvExport.js'

// Lazy-load de gráficos (reutiliza recharts si Dashboard lo cargó)
const GraficoIngresos = lazy(() =>
  import('./GraficosDashboard.jsx').then(m => ({ default: m.GraficoIngresos }))
)
const ChartFallback = () => (
  <div className="card" style={{ padding: 16, minHeight: 240 }}>
    <Skeleton className="skeleton-row" />
  </div>
)

const BUCKETS_COBROS = [
  { id: 'vigente', label: 'Vigente',     color: 'var(--txt2)' },
  { id: '1-30',    label: '1-30 días',   color: 'var(--accent)' },
  { id: '31-60',   label: '31-60 días',  color: 'var(--acc2)' },
  { id: '61-90',   label: '61-90 días',  color: '#fab005' },
  { id: '+90',     label: '+90 días',    color: 'var(--err)' },
]

const BUCKETS_PRONOSTICO = [
  { id: '30',  label: 'Próximos 30 días',   color: 'var(--acc3)' },
  { id: '60',  label: '31-60 días',         color: 'var(--accent)' },
  { id: '90',  label: '61-90 días',         color: 'var(--acc2)' },
  { id: '+90', label: 'Más de 90 días',     color: 'var(--txt2)' },
]

// Botón pequeño "Exportar CSV" para reusar
function BtnExportar({ onClick, title = 'Exportar a CSV' }) {
  return (
    <button
      type="button"
      className="btn btn-ghost"
      onClick={onClick}
      title={title}
      style={{ fontSize: 12, padding: '5px 10px' }}
    >
      <Ic d={I.download} size={13}/> Exportar
    </button>
  )
}

export default function Reportes() {
  const [diasCot, setDiasCot] = useState(30)
  const { data, isLoading, error, refetch } = useReportes({ dias: diasCot })

  const r = data?.data || data || {}
  const ingresos     = r.ingresos_mes        || []
  const cobros       = r.cobros_pendientes   || { total: 0, items: [], buckets: {} }
  const cotizaciones = r.cotizaciones_estado || { items: [], total_cantidad: 0, total_monto: 0 }
  const servicios    = r.servicios_top       || { items: [], total_monto: 0, total_cantidad: 0 }
  const productividad = r.productividad_mensual || { serie: [], total_terminados: 0, dias_promedio_glob: null, activos_hoy: 0 }
  const conversion   = r.conversion_mensual  || { serie: [], tot_emitidas: 0, tot_aceptadas: 0, tasa_global: 0 }
  const pronostico   = r.pronostico_ingresos || { buckets: {}, items: [], total: 0 }

  // Métricas derivadas de ingresos
  const totalIngresos12m = useMemo(
    () => ingresos.reduce((a, x) => a + (x.total || 0), 0),
    [ingresos]
  )
  const mesActual    = ingresos[ingresos.length - 1]?.total || 0
  const mesAnterior  = ingresos[ingresos.length - 2]?.total || 0
  const variacion    = mesAnterior > 0
    ? Math.round(((mesActual - mesAnterior) / mesAnterior) * 100)
    : null

  // ── Exportadores ────────────────────────────────────────
  const exportarIngresos = () => exportCSV(
    `ingresos_${hoy()}.csv`,
    ['Mes', 'Total'],
    ingresos.map(x => [x.mes, x.total])
  )
  const exportarCobros = () => exportCSV(
    `cobros_pendientes_${hoy()}.csv`,
    ['Cliente', 'Proyecto', 'Fecha boleta', 'Monto', 'Días vencido', 'Tramo'],
    cobros.items.map(it => [
      it.cliente_nombre, it.proyecto_nombre, it.boleta_fecha || '',
      it.monto, it.dias_vencido ?? '', it.bucket
    ])
  )
  const exportarCotizaciones = () => exportCSV(
    `cotizaciones_estado_${hoy()}.csv`,
    ['Estado', 'Cantidad', 'Monto'],
    cotizaciones.items.map(it => [it.estado, it.cantidad, it.total])
  )
  const exportarServicios = () => exportCSV(
    `servicios_top_${hoy()}.csv`,
    ['Servicio', 'Cantidad', 'Monto'],
    servicios.items.map(it => [it.servicio, it.cantidad, it.total])
  )
  const exportarProductividad = () => exportCSV(
    `productividad_${hoy()}.csv`,
    ['Mes', 'Terminados', 'Días promedio'],
    productividad.serie.map(x => [x.mes, x.terminados, x.dias_prom ?? ''])
  )
  const exportarConversion = () => exportCSV(
    `conversion_cotizaciones_${hoy()}.csv`,
    ['Mes', 'Emitidas', 'Aceptadas', 'Tasa %'],
    conversion.serie.map(x => [x.mes, x.emitidas, x.aceptadas, x.tasa])
  )
  const exportarPronostico = () => exportCSV(
    `pronostico_ingresos_${hoy()}.csv`,
    ['Cliente', 'Proyecto', 'Fecha boleta', 'Monto', 'Días hasta'],
    pronostico.items.map(it => [
      it.cliente_nombre, it.proyecto_nombre, it.boleta_fecha || '',
      it.monto, it.dias
    ])
  )

  if (isLoading) {
    return (
      <div className="card" style={{ padding: 16 }}>
        <Skeleton className="skeleton-title" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 11, margin: '14px 0' }}>
          {[...Array(3)].map((_, i) => <Skeleton key={i} style={{ height: 100 }} />)}
        </div>
        <Skeleton style={{ height: 240 }} />
      </div>
    )
  }

  if (error) {
    return (
      <div className="tbl-loading" style={{ textAlign: 'center', padding: 40 }}>
        <p style={{ color: 'var(--err)', marginBottom: 12 }}>❌ Error al cargar reportes</p>
        <p style={{ fontSize: 12, color: 'var(--txt3)', marginBottom: 20 }}>{error.message}</p>
        <button onClick={refetch} className="btn btn-primary" type="button">🔄 Reintentar</button>
      </div>
    )
  }

  // Header pequeño reutilizable por sección
  const SectionHdr = ({ titulo, subtitulo, accion, exportar }) => (
    <div
      className="panel-hdr"
      style={{
        marginBottom: 12,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 10
      }}
    >
      <div>
        <div className="panel-title">{titulo}</div>
        {subtitulo && <div style={{ fontSize: 12, color: 'var(--txt2)', marginTop: 2 }}>{subtitulo}</div>}
      </div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        {accion}
        {exportar && <BtnExportar onClick={exportar} />}
      </div>
    </div>
  )

  return (
    <div>
      <div className="dash-hdr">
        <div>
          <div className="dash-title">Reportes</div>
          <div className="dash-date">Resumen consolidado para tomar decisiones</div>
        </div>
      </div>

      {/* 1) INGRESOS POR MES ──────────────────────────────── */}
      <section style={{ marginBottom: 18 }}>
        <div className="g-3" style={{ marginBottom: 12 }}>
          <StatCard
            label={ingresos.length >= 12 ? 'Total últimos 12 meses' : `Total (${ingresos.length} ${ingresos.length === 1 ? 'mes' : 'meses'})`}
            value={clp(totalIngresos12m)}
            icon={I.download}
            color="var(--acc3)"
            sub="Pagos cobrados"
          />
          <StatCard
            label="Mes en curso"
            value={clp(mesActual)}
            icon={I.trendingUp}
            color="var(--accent)"
            sub={
              variacion === null
                ? 'Sin mes anterior'
                : variacion >= 0
                  ? `▲ ${variacion}% vs mes anterior`
                  : `▼ ${Math.abs(variacion)}% vs mes anterior`
            }
          />
          <StatCard
            label="Promedio mensual"
            value={clp(ingresos.length ? Math.round(totalIngresos12m / ingresos.length) : 0)}
            icon={I.barChart}
            color="var(--acc2)"
            sub={ingresos.length >= 12 ? 'Últimos 12 meses' : `Sobre ${ingresos.length} ${ingresos.length === 1 ? 'mes' : 'meses'}`}
          />
        </div>

        <div className="card" style={{ padding: 16 }}>
          <SectionHdr
            titulo="Ingresos por mes"
            subtitulo="Cobros efectivos últimos 12 meses"
            exportar={exportarIngresos}
          />
          <Suspense fallback={<ChartFallback />}>
            <GraficoIngresos datos={ingresos} />
          </Suspense>
        </div>
      </section>

      {/* 2) PRONÓSTICO DE INGRESOS ────────────────────────── */}
      <section style={{ marginBottom: 18 }}>
        <div className="card" style={{ padding: 16 }}>
          <SectionHdr
            titulo="Pronóstico de ingresos"
            subtitulo={`Total por venir: ${clp(pronostico.total)} · ${pronostico.items.length} boleta(s)`}
            exportar={pronostico.items.length ? exportarPronostico : null}
          />
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(160px,1fr))',
            gap: 10,
            marginBottom: pronostico.items.length ? 16 : 0
          }}>
            {BUCKETS_PRONOSTICO.map(b => {
              const info = pronostico.buckets?.[b.id] || { monto: 0, cantidad: 0 }
              return (
                <div key={b.id} className="card" style={{
                  padding: 12,
                  borderLeft: `3px solid ${b.color}`,
                  background: 'var(--bg)'
                }}>
                  <div style={{ fontSize: 11, color: 'var(--txt2)', marginBottom: 4 }}>{b.label}</div>
                  <div style={{ fontWeight: 700, color: info.monto > 0 ? b.color : 'var(--txt2)' }}>
                    {clp(info.monto)}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--txt3)', marginTop: 2 }}>
                    {info.cantidad} {info.cantidad === 1 ? 'boleta' : 'boletas'}
                  </div>
                </div>
              )
            })}
          </div>
          {!pronostico.items.length && (
            <EmptyState
              titulo="Sin pagos por venir"
              descripcion="No hay cuotas pendientes con fecha futura."
            />
          )}
        </div>
      </section>

      {/* 3) COBROS PENDIENTES ────────────────────────────── */}
      <section style={{ marginBottom: 18 }}>
        <div className="card" style={{ padding: 16 }}>
          <SectionHdr
            titulo="Cobros pendientes"
            subtitulo={`Total adeudado: ${clp(cobros.total)} · ${cobros.items.length} ${cobros.items.length === 1 ? 'boleta' : 'boletas'}`}
            exportar={cobros.items.length ? exportarCobros : null}
          />

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
            gap: 10,
            marginBottom: 16
          }}>
            {BUCKETS_COBROS.map(b => {
              const monto = cobros.buckets?.[b.id] || 0
              return (
                <div key={b.id} className="card" style={{
                  padding: 12,
                  borderLeft: `3px solid ${b.color}`,
                  background: 'var(--bg)',
                }}>
                  <div style={{ fontSize: 11, color: 'var(--txt2)', marginBottom: 4 }}>{b.label}</div>
                  <div style={{ fontWeight: 700, color: monto > 0 ? b.color : 'var(--txt2)' }}>
                    {clp(monto)}
                  </div>
                </div>
              )
            })}
          </div>

          {!cobros.items.length ? (
            <EmptyState titulo="¡Sin cobros pendientes!" descripcion="No tienes boletas pendientes de cobro." />
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table className="tbl" style={{ width: '100%' }}>
                <thead>
                  <tr>
                    <th>Cliente</th>
                    <th>Proyecto</th>
                    <th>Fecha boleta</th>
                    <th style={{ textAlign: 'right' }}>Monto</th>
                    <th style={{ textAlign: 'center' }}>Días</th>
                  </tr>
                </thead>
                <tbody>
                  {cobros.items.map(it => {
                    const bucket = BUCKETS_COBROS.find(b => b.id === it.bucket)
                    return (
                      <tr key={it.id}>
                        <td>{it.cliente_nombre}</td>
                        <td>{it.proyecto_nombre}</td>
                        <td>
                          {it.boleta_fecha
                            ? it.boleta_fecha.split('-').reverse().join('-')
                            : <span style={{ color: 'var(--txt3)' }}>—</span>}
                        </td>
                        <td style={{ textAlign: 'right', fontWeight: 600 }}>{clp(it.monto)}</td>
                        <td style={{ textAlign: 'center' }}>
                          <span style={{
                            display: 'inline-block',
                            padding: '2px 10px',
                            borderRadius: 12,
                            fontSize: 12,
                            fontWeight: 600,
                            background: bucket?.color || 'var(--txt2)',
                            color: '#fff'
                          }}>
                            {it.dias_vencido === null ? '—' :
                              it.dias_vencido <= 0 ? 'Vigente' : `${it.dias_vencido}d`}
                          </span>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* 4) COTIZACIONES POR ESTADO ──────────────────────── */}
      <section style={{ marginBottom: 18 }}>
        <div className="card" style={{ padding: 16 }}>
          <SectionHdr
            titulo="Cotizaciones por estado"
            subtitulo={`${cotizaciones.total_cantidad} cotización(es) · ${clp(cotizaciones.total_monto)} en total`}
            accion={
              <select
                className="dash-periodo"
                value={diasCot}
                onChange={e => setDiasCot(Number(e.target.value))}
                aria-label="Rango de días"
              >
                <option value={7}>Últimos 7 días</option>
                <option value={30}>Últimos 30 días</option>
                <option value={90}>Últimos 90 días</option>
                <option value={180}>Últimos 6 meses</option>
                <option value={365}>Último año</option>
              </select>
            }
            exportar={cotizaciones.items.length ? exportarCotizaciones : null}
          />
          {!cotizaciones.items.length ? (
            <EmptyState titulo="Sin cotizaciones en el rango" descripcion="Prueba ampliando el rango de días." />
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 10 }}>
              {cotizaciones.items.map(it => {
                const pct = cotizaciones.total_cantidad > 0
                  ? Math.round((it.cantidad / cotizaciones.total_cantidad) * 100)
                  : 0
                return (
                  <div key={it.estado} className="card" style={{ padding: 14, background: 'var(--bg)' }}>
                    <div style={{ marginBottom: 8 }}><Badge s={it.estado} /></div>
                    <div style={{ fontSize: 26, fontWeight: 700, lineHeight: 1 }}>{it.cantidad}</div>
                    <div style={{ fontSize: 12, color: 'var(--txt2)', margin: '4px 0 10px' }}>
                      {pct}% del total
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--txt2)' }}>Monto</div>
                    <div style={{ fontWeight: 600 }}>{clp(it.total)}</div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </section>

      {/* 5) TASA DE CONVERSIÓN POR MES ───────────────────── */}
      <section style={{ marginBottom: 18 }}>
        <div className="card" style={{ padding: 16 }}>
          <SectionHdr
            titulo="Conversión de cotizaciones"
            subtitulo={
              `${conversion.tot_aceptadas} de ${conversion.tot_emitidas} aceptadas · ` +
              `Tasa global ${conversion.tasa_global}%`
            }
            exportar={conversion.serie.length ? exportarConversion : null}
          />
          {!conversion.tot_emitidas ? (
            <EmptyState titulo="Sin cotizaciones" descripcion="Aparecerá información cuando emitas cotizaciones." />
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table className="tbl" style={{ width: '100%' }}>
                <thead>
                  <tr>
                    <th>Mes</th>
                    <th style={{ textAlign: 'right' }}>Emitidas</th>
                    <th style={{ textAlign: 'right' }}>Aceptadas</th>
                    <th>Tasa</th>
                  </tr>
                </thead>
                <tbody>
                  {conversion.serie.map(x => (
                    <tr key={x.key}>
                      <td>{x.mes}</td>
                      <td style={{ textAlign: 'right' }}>{x.emitidas}</td>
                      <td style={{ textAlign: 'right' }}>{x.aceptadas}</td>
                      <td style={{ minWidth: 180 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <div style={{
                            flex: 1,
                            height: 8,
                            background: 'var(--bg)',
                            borderRadius: 4,
                            overflow: 'hidden'
                          }}>
                            <div style={{
                              width: `${Math.min(100, x.tasa)}%`,
                              height: '100%',
                              background: x.tasa >= 50 ? 'var(--acc3)' : x.tasa >= 25 ? 'var(--acc2)' : 'var(--err)',
                              transition: 'width .3s'
                            }}/>
                          </div>
                          <span style={{ fontSize: 12, fontWeight: 600, minWidth: 42, textAlign: 'right' }}>
                            {x.tasa}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* 6) SERVICIOS MÁS VENDIDOS ───────────────────────── */}
      <section style={{ marginBottom: 18 }}>
        <div className="card" style={{ padding: 16 }}>
          <SectionHdr
            titulo="Servicios más vendidos"
            subtitulo={`Últimos 12 meses · ${servicios.items.length} servicio(s) · ${clp(servicios.total_monto)}`}
            exportar={servicios.items.length ? exportarServicios : null}
          />
          {!servicios.items.length ? (
            <EmptyState titulo="Aún sin datos" descripcion="Aparecerán cuando tengas cotizaciones aceptadas." />
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table className="tbl" style={{ width: '100%' }}>
                <thead>
                  <tr>
                    <th>Servicio</th>
                    <th style={{ textAlign: 'right' }}>Veces</th>
                    <th style={{ textAlign: 'right' }}>Monto</th>
                    <th>Participación</th>
                  </tr>
                </thead>
                <tbody>
                  {servicios.items.map((it, i) => {
                    const pct = servicios.total_monto > 0
                      ? Math.round((it.total / servicios.total_monto) * 100)
                      : 0
                    return (
                      <tr key={i}>
                        <td>{it.servicio}</td>
                        <td style={{ textAlign: 'right' }}>{it.cantidad}</td>
                        <td style={{ textAlign: 'right', fontWeight: 600 }}>{clp(it.total)}</td>
                        <td style={{ minWidth: 180 }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <div style={{
                              flex: 1, height: 8, background: 'var(--bg)',
                              borderRadius: 4, overflow: 'hidden'
                            }}>
                              <div style={{
                                width: `${pct}%`, height: '100%',
                                background: 'var(--accent)', transition: 'width .3s'
                              }}/>
                            </div>
                            <span style={{ fontSize: 12, fontWeight: 600, minWidth: 38, textAlign: 'right' }}>
                              {pct}%
                            </span>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* 7) PRODUCTIVIDAD MENSUAL ────────────────────────── */}
      <section style={{ marginBottom: 18 }}>
        <div className="card" style={{ padding: 16 }}>
          <SectionHdr
            titulo="Productividad mensual"
            subtitulo={
              `${productividad.total_terminados} terminados últimos 12 meses` +
              (productividad.dias_promedio_glob !== null
                ? ` · Promedio ${productividad.dias_promedio_glob} días/proyecto`
                : '') +
              ` · ${productividad.activos_hoy} activo(s) hoy`
            }
            exportar={productividad.serie.length ? exportarProductividad : null}
          />
          {!productividad.total_terminados ? (
            <EmptyState
              titulo="Sin proyectos terminados aún"
              descripcion="Aparecerán cuando marques proyectos como 'Terminado'."
            />
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table className="tbl" style={{ width: '100%' }}>
                <thead>
                  <tr>
                    <th>Mes</th>
                    <th style={{ textAlign: 'right' }}>Terminados</th>
                    <th style={{ textAlign: 'right' }}>Días promedio</th>
                    <th>Volumen</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    const max = Math.max(...productividad.serie.map(x => x.terminados), 1)
                    return productividad.serie.map(x => (
                      <tr key={x.key}>
                        <td>{x.mes}</td>
                        <td style={{ textAlign: 'right' }}>{x.terminados}</td>
                        <td style={{ textAlign: 'right' }}>{x.dias_prom ?? '—'}</td>
                        <td style={{ minWidth: 160 }}>
                          <div style={{
                            width: `${(x.terminados / max) * 100}%`,
                            height: 8,
                            background: 'var(--acc3)',
                            borderRadius: 4,
                            minWidth: x.terminados ? 4 : 0,
                            transition: 'width .3s'
                          }}/>
                        </td>
                      </tr>
                    ))
                  })()}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
