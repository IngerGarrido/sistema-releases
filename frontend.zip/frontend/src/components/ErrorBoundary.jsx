import { Component } from 'react'

/**
 * Error Boundary - Captura errores de React y muestra UI amigable
 * Evita que toda la aplicación se rompa por un error en un componente
 */
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null, errorInfo: null }
  }

  static getDerivedStateFromError(error) {
    return { hasError: true }
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ error, errorInfo })
    // eslint-disable-next-line no-console
    console.error('Error capturado por ErrorBoundary:', error, errorInfo)

    // Reportar al backend (best-effort, no debe romper el render del fallback)
    try {
      const API = (import.meta?.env?.VITE_API_URL) || 'https://sistema.ingergarrido.cl/backend/api'
      const token = (() => { try { return localStorage.getItem('_t') } catch { return null } })()
      const body = JSON.stringify({
        message: String(error?.message || error || 'unknown'),
        stack: String(error?.stack || ''),
        componentStack: String(errorInfo?.componentStack || ''),
        url: window.location.href,
        section: (() => { try { return localStorage.getItem('_sec') } catch { return '' } })(),
      })
      const headers = { 'Content-Type': 'application/json' }
      if (token) headers['Authorization'] = 'Bearer ' + token
      // sendBeacon no soporta headers personalizados → uso fetch keepalive
      fetch(`${API}/client_errors.php`, { method: 'POST', headers, body, keepalive: true }).catch(() => {})
    } catch { /* swallow */ }
  }

  handleReload = () => {
    window.location.reload()
  }

  handleGoHome = () => {
    try { localStorage.setItem('_sec', 'dashboard') } catch {}
    window.location.href = '/'
  }

  render() {
    if (this.state.hasError) {
      const isDev = (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.DEV)
        || (typeof process !== 'undefined' && process.env && process.env.NODE_ENV === 'development')

      return (
        <div className="error-boundary">
          <div className="error-boundary__icon">⚠️</div>
          <h1>Algo salió mal</h1>
          <p>Ha ocurrido un error inesperado en esta sección. Puedes recargar la página o volver al inicio.</p>

          {isDev && this.state.error && (
            <details className="error-boundary__details" open>
              <summary>Detalles técnicos (solo en desarrollo)</summary>
              <pre style={{ whiteSpace: 'pre-wrap' }}>{this.state.error.toString()}</pre>
              {this.state.errorInfo?.componentStack && (
                <pre style={{ whiteSpace: 'pre-wrap', fontSize: 11, opacity: 0.8 }}>
                  {this.state.errorInfo.componentStack}
                </pre>
              )}
            </details>
          )}

          <div className="error-boundary__actions">
            <button onClick={this.handleReload} className="btn btn-primary">
              🔄 Recargar
            </button>
            <button onClick={this.handleGoHome} className="btn btn-ghost">
              🏠 Volver al inicio
            </button>
          </div>
        </div>
      )
    }

    return this.props.children
  }
}
