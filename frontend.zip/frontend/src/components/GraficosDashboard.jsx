import { useState, useEffect } from 'react'
import { 
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts'
import { clp, I } from '../assets/js/helpers.js'
import { Ic } from './UI.jsx'

// Gráfico de Ingresos Mensuales (últimos 6 meses)
export function GraficoIngresos({ datos }) {
  if (!datos || datos.length === 0) {
    return (
      <div className="grafico-card grafico-card--empty">
        <h4><Ic d={I.trendingUp}/> Ingresos por Mes</h4>
        <div className="grafico-empty-bonito">
          <Ic d={I.barChart}/>
          <p>Sin datos de ingresos</p>
          <small>Los ingresos aparecerán aquí cuando registres pagos</small>
        </div>
      </div>
    )
  }

  const data = datos.map(d => ({
    mes: d.mes,
    ingresos: d.total || 0,
    meta: d.meta || 0
  }))

  return (
    <div className="grafico-card">
      <h4><Ic d={I.trendingUp}/> Ingresos por Mes</h4>
      <ResponsiveContainer width="100%" height={200}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--card-b)" />
          <XAxis dataKey="mes" stroke="var(--txt2)" fontSize={12} />
          <YAxis stroke="var(--txt2)" fontSize={12} tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
          <Tooltip
            contentStyle={{ background: 'var(--card)', border: '1px solid var(--card-b)', borderRadius: 8, fontSize: 12 }}
            formatter={(value) => clp(value)}
          />
          <Legend wrapperStyle={{ fontSize: 11 }} iconSize={10} />
          <Line type="monotone" dataKey="ingresos" stroke="#3b5bdb" strokeWidth={2} name="Ingresos" dot={{r: 4}} />
          <Line type="monotone" dataKey="meta" stroke="#40c057" strokeWidth={2} strokeDasharray="5 5" name="Meta" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

// Gráfico de Proyectos por Estado
export function GraficoProyectosEstado({ datos }) {
  const COLORES = ['#3b5bdb', '#40c057', '#fab005', '#fa5252', '#868e96']
  
  if (!datos || datos.length === 0) {
    return (
      <div className="grafico-card grafico-card--empty">
        <h4><Ic d={I.pieChart}/> Proyectos por Estado</h4>
        <div className="grafico-empty-bonito">
          <Ic d={I.projects}/>
          <p>Sin proyectos</p>
          <small>Crea proyectos para ver la distribución aquí</small>
        </div>
      </div>
    )
  }

  return (
    <div className="grafico-card">
      <h4><Ic d={I.pieChart}/> Proyectos por Estado</h4>
      <ResponsiveContainer width="100%" height={200}>
        <PieChart>
          <Pie
            data={datos}
            cx="50%"
            cy="50%"
            innerRadius={50}
            outerRadius={80}
            paddingAngle={4}
            dataKey="cantidad"
            nameKey="estado"
          >
            {datos.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORES[index % COLORES.length]} />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{ background: 'var(--card)', border: '1px solid var(--card-b)', borderRadius: 8, fontSize: 12 }}
          />
          <Legend 
            verticalAlign="bottom" 
            height={36} 
            wrapperStyle={{ 
              fontSize: '11px', 
              paddingTop: '15px'
            }} 
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}

// Gráfico de Tipos de Pago (Boleta vs Directo)
export function GraficoTiposPago({ boletas, directos }) {
  const total = (boletas || 0) + (directos || 0)
  
  if (total === 0) {
    return (
      <div className="grafico-card grafico-card--empty">
        <h4><Ic d={I.creditCard}/> Tipos de Pago</h4>
        <div className="grafico-empty-bonito">
          <Ic d={I.pay}/>
          <p>Sin pagos registrados</p>
          <small>Los pagos aparecerán aquí al registrar boletas</small>
        </div>
      </div>
    )
  }
  
  const data = [
    { nombre: 'Con Boleta', valor: boletas || 0, fill: '#3b5bdb' },
    { nombre: 'Directo', valor: directos || 0, fill: '#40c057' }
  ]

  return (
    <div className="grafico-card">
      <h4>💳 Tipos de Pago</h4>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data} layout="vertical">
          <CartesianGrid strokeDasharray="3 3" stroke="var(--card-b)" horizontal={false} />
          <XAxis type="number" stroke="var(--txt2)" fontSize={12} tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
          <YAxis type="category" dataKey="nombre" stroke="var(--txt2)" fontSize={12} width={80} />
          <Tooltip
            contentStyle={{ background: 'var(--card)', border: '1px solid var(--card-b)', borderRadius: 8, fontSize: 12 }}
            formatter={(value) => clp(value)}
          />
          <Bar dataKey="valor" radius={[0, 4, 4, 0]} barSize={40} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

// Gráfico de Cotizaciones por Mes (Sprint 4)
export function GraficoCotizacionesMes({ datos }) {
  if (!datos || datos.length === 0) {
    return (
      <div className="grafico-card grafico-card--empty">
        <h4><Ic d={I.barChart}/> Cotizaciones por Mes</h4>
        <div className="grafico-empty-bonito">
          <Ic d={I.barChart}/>
          <p>Sin cotizaciones recientes</p>
          <small>Aquí verás cantidad y monto de los últimos 6 meses</small>
        </div>
      </div>
    )
  }
  return (
    <div className="grafico-card">
      <h4><Ic d={I.barChart}/> Cotizaciones por Mes</h4>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={datos}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--card-b)" />
          <XAxis dataKey="mes" stroke="var(--txt2)" fontSize={11} />
          <YAxis yAxisId="left" stroke="var(--txt2)" fontSize={11} />
          <YAxis yAxisId="right" orientation="right" stroke="var(--txt2)" fontSize={11} tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
          <Tooltip
            contentStyle={{ background: 'var(--card)', border: '1px solid var(--card-b)', borderRadius: 8, fontSize: 12 }}
            formatter={(value, name) => name === 'Monto' ? clp(value) : value}
          />
          <Legend wrapperStyle={{ fontSize: 11 }}/>
          <Bar yAxisId="left" dataKey="cantidad" name="Cantidad" fill="#3b5bdb" radius={[4,4,0,0]} />
          <Bar yAxisId="right" dataKey="total"    name="Monto"    fill="#40c057" radius={[4,4,0,0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

// Gráfico Aging de Cobros (Sprint 4)
export function GraficoAgingCobros({ datos }) {
  const buckets = ['0-30','31-60','61-90','+90']
  const colores = ['#40c057','#fab005','#fd7e14','#fa5252']
  const data = buckets.map((b, i) => ({
    bucket: b,
    cantidad: datos?.[b]?.cantidad || 0,
    total:    datos?.[b]?.total    || 0,
    fill:     colores[i]
  }))
  const totalGeneral = data.reduce((a,d)=>a+d.total,0)
  if (!datos || totalGeneral === 0) {
    return (
      <div className="grafico-card grafico-card--empty">
        <h4><Ic d={I.pay}/> Aging de Cobros</h4>
        <div className="grafico-empty-bonito">
          <Ic d={I.pay}/>
          <p>Sin cobros pendientes</p>
          <small>¡Todo al día!</small>
        </div>
      </div>
    )
  }
  return (
    <div className="grafico-card">
      <h4><Ic d={I.pay}/> Aging de Cobros</h4>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--card-b)" />
          <XAxis dataKey="bucket" stroke="var(--txt2)" fontSize={12} />
          <YAxis stroke="var(--txt2)" fontSize={11} tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
          <Tooltip
            contentStyle={{ background: 'var(--card)', border: '1px solid var(--card-b)', borderRadius: 8, fontSize: 12 }}
            formatter={(value) => clp(value)}
          />
          <Bar dataKey="total" name="Monto pendiente" radius={[4,4,0,0]}>
            {data.map((entry, idx) => <Cell key={idx} fill={entry.fill} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

// Mini estadísticas
export function MiniStats({ titulo, valor, trend, trendUp }) {
  return (
    <div className="mini-stat">
      <span className="mini-stat-label">{titulo}</span>
      <span className="mini-stat-value">{valor}</span>
      {trend && (
        <span className={`mini-stat-trend ${trendUp ? 'up' : 'down'}`}>
          {trendUp ? '↑' : '↓'} {trend}
        </span>
      )}
    </div>
  )
}
