import { useState, useEffect } from 'react'
import { useLocalState } from '../hooks/useLocalState.js'
import { useUnsavedWarning } from '../hooks/useUnsavedWarning.js'
import { useBulkSelect } from '../hooks/useBulkSelect.js'
import { useDebouncedValue } from '../hooks/useDebouncedValue.js'
import { useForm, useFieldArray, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { clp, fecha, I } from '../assets/js/helpers.js'
import { api } from '../assets/js/api.js'
import { Ic, Modal, Confirm, Toast, Field, InpCLP, BotonesGuardar, SelCliente, Badge, IBtn, useToast, Skeleton, Pagination } from './UI.jsx'
import { usePagos, useCrearPago, useEditarPago, useBorrarPago } from '../hooks/useQueryApi.js'
import { pagoSchema } from '../schemas/validation.js'

export default function Pagos({ clientes, proyectos }) {
  const crearPago = useCrearPago()
  const editarPago = useEditarPago()
  const borrarPago = useBorrarPago()

  const [modal, setModal] = useState(false)
  const [modalKey, setModalKey] = useState(0)
  const [editando, setEditando] = useState(null)
  const [del, setDel] = useState(null)
  const [delMultiple, setDelMultiple] = useState(false)
  const [toast, showToast] = useToast()
  const [pagina, setPagina] = useState(1)
  const [perPage, setPerPage] = useLocalState('pagos:perPage', 10)
  const [busqueda, setBusqueda] = useLocalState('pagos:busqueda', '')

  // Búsqueda server-side con debounce (hook reutilizable)
  const qDebounced = useDebouncedValue(busqueda, 300)
  useEffect(() => { setPagina(1) }, [qDebounced])

  const { data: respuesta, isLoading: loading } = usePagos({ page: pagina, per_page: perPage, q: qDebounced })
  const lista = Array.isArray(respuesta?.data) ? respuesta.data : []

  const listaProyectos = Array.isArray(proyectos) ? proyectos : (Array.isArray(proyectos?.data) ? proyectos.data : [])
  const listaClientes  = Array.isArray(clientes)  ? clientes  : (Array.isArray(clientes?.data)  ? clientes.data  : [])

  const totalPaginas = respuesta?.pagination?.total_pages || 1

  const { register, handleSubmit, reset, watch, setValue, control, formState: { isDirty } } = useForm({
    resolver: zodResolver(pagoSchema),
    defaultValues: {
      cliente_id: '', proyecto_id: '', descripcion: '', monto_total: 0, tipo_pago: 'boleta',
      cuotas: [{ numero_cuota: 1, tipo_pago: 'boleta', boleta_num: '', boleta_fecha: '', boleta_monto: 0, pago_fecha: '', pago_monto: 0, estado: 'Pendiente' }]
    }
  })

  const { fields, append, remove } = useFieldArray({ control, name: 'cuotas' })
  useUnsavedWarning(modal && isDirty)

  const abrir = (p) => {
    if (p) {
      reset({
        ...p,
        cliente_id: String(p.cliente_id),
        proyecto_id: String(p.proyecto_id),
        monto_total: parseInt(p.monto_total) || 0,
        cuotas: (p.cuotas || []).map(c => ({
          ...c,
          boleta_monto: parseInt(c.boleta_monto) || 0,
          pago_monto: parseInt(c.pago_monto) || 0
        }))
      })
      setEditando(p)
    } else {
      reset({
        cliente_id: '', proyecto_id: '', descripcion: '', monto_total: 0, tipo_pago: 'boleta',
        cuotas: [{ numero_cuota: 1, tipo_pago: 'boleta', boleta_num: '', boleta_fecha: '', boleta_monto: 0, pago_fecha: '', pago_monto: 0, estado: 'Pendiente' }]
      })
      setEditando(null)
    }
    setModalKey(k => k + 1)
    setModal(true)
  }

  const guardar = async (data) => {
    try {
      const id = data.id || editando?.id
      id ? await editarPago.mutateAsync({ id, data }) : await crearPago.mutateAsync(data)
      setModal(false)
      showToast('Pago guardado')
    } catch (err) { showToast(err.message || 'Error', 'err') }
  }

  // Búsqueda ahora es server-side (param q). Mostrar tal cual.
  const filtrados = lista

  const {
    seleccionados,
    toggle: toggleSeleccion,
    toggleAll: seleccionarTodos,
    clear: clearSeleccion,
  } = useBulkSelect(filtrados, busqueda)

  return (
    <div>
      {toast && <Toast {...toast} />}

      {loading && (
        <div className="card" style={{ padding: '16px' }}>
          <Skeleton className="skeleton-title" style={{ marginBottom: '16px' }} />
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="skeleton-row" />)}
        </div>
      )}

      {!loading && (
        <>
          {/* Barra acciones masivas */}
          {filtrados.length > 0 && (
            <div className="bulk-actions-bar">
              <label>
                <input
                  type="checkbox"
                  checked={seleccionados.size === filtrados.length && filtrados.length > 0}
                  onChange={seleccionarTodos}
                  aria-label="Seleccionar todos los pagos"
                />
                <span>Todos</span>
              </label>
              {seleccionados.size > 0 && (
                <>
                  <span className="selection-count">| {seleccionados.size} seleccionados</span>
                  <button onClick={() => setDelMultiple(true)} className="btn-bulk-delete">
                    🗑️ Eliminar ({seleccionados.size})
                  </button>
                </>
              )}
            </div>
          )}

          {/* Header: título, búsqueda, botones — SIN tabla ni paginación */}
          <div className="data-panel">
            <div className="data-panel__head">
              <div>
                <div className="data-panel__title">Pagos y Boletas</div>
                <div className="data-panel__count"><b>{filtrados.length}</b> registros</div>
              </div>
              <div className="data-panel__controls">
                <div className="data-panel__search">
                  <Ic d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z" size={14} />
                  <input
                    type="text"
                    placeholder="Buscar..."
                    value={busqueda}
                    onChange={e => setBusqueda(e.target.value)}
                  />
                </div>
                <button className="btn btn-outline" onClick={() => api.exportar('pagos')}>
                  <Ic d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" size={13} /> Excel
                </button>
                <button className="btn btn-green" onClick={() => abrir(null)}>
                  <Ic d={I.plus} size={13} /> Nuevo pago
                </button>
              </div>
            </div>

            {/* Tarjetas */}
            <div className="pago-list">
              {filtrados.length === 0 ? (
                <div className="data-panel__empty">No se encontraron registros</div>
              ) : filtrados.map(p => {
                const pagado = Number(p.total_pagado || 0)
                const pct = p.monto_total ? Math.min(100, Math.round(pagado / p.monto_total * 100)) : 0
                return (
                  <div key={p.id} className="pago-card">
                    <div className="pago-hdr">
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <input
                          type="checkbox"
                          checked={seleccionados.has(p.id)}
                          onChange={() => toggleSeleccion(p.id)}
                          aria-label={`Seleccionar pago ${p.descripcion || p.proyecto_nombre || p.id}`}
                        />
                        <div>
                          <div className="pago-name">{p.descripcion || p.proyecto_nombre}</div>
                          <div className="pago-meta">{p.cliente_nombre}{p.proyecto_nombre && ` · ${p.proyecto_nombre}`}</div>
                        </div>
                      </div>
                      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                        <div style={{ textAlign: 'right' }}>
                          <div className="pago-cob">{clp(pagado)}</div>
                          <div className="pago-total">de {clp(p.monto_total)}</div>
                        </div>
                        <IBtn icon={I.edit} onClick={() => abrir(p)} variant="edit" />
                        <IBtn icon={I.trash} onClick={() => setDel(p.id)} variant="del" />
                      </div>
                    </div>
                    <div className="pago-bar">
                      <div className="pago-bar-fill" style={{ width: pct + '%' }} />
                    </div>
                    <div style={{ overflowX: 'auto' }}>
                      <table className="tbl" style={{ minWidth: 560 }}>
                        <thead>
                          <tr>
                            {['Cuota', 'N° Boleta / Tipo', 'Fecha Boleta', 'Monto Boleta', 'Fecha Pago', 'Monto Pagado', 'Estado'].map((h, i) => (
                              <th key={i} style={{ textAlign: [3, 5].includes(i) ? 'right' : 'left' }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {(p.cuotas || []).map((c, i) => (
                            <tr key={i}>
                              <td style={{ fontWeight: 700 }}>#{c.numero_cuota}</td>
                              <td>{c.tipo_pago === 'directo' ? <span className="tipo-direct">PAGO DIRECTO</span> : <span style={{ fontWeight: 600 }}>{c.boleta_num || '—'}</span>}</td>
                              <td style={{ color: 'var(--txt2)', fontSize: 12 }}>{c.tipo_pago === 'directo' ? 'N/A' : (fecha(c.boleta_fecha) || '—')}</td>
                              <td style={{ textAlign: 'right', fontWeight: 700 }}>{c.tipo_pago === 'directo' ? 'N/A' : clp(c.boleta_monto)}</td>
                              <td style={{ fontSize: 12 }}>{c.estado === 'Pagado' ? <span style={{ color: 'var(--acc3)', fontWeight: 600 }}>{fecha(c.pago_fecha)}</span> : 'Pendiente'}</td>
                              <td style={{ textAlign: 'right' }}>{c.estado === 'Pagado' ? <span style={{ fontWeight: 800 }}>{clp(c.pago_monto)}</span> : '—'}</td>
                              <td><Badge s={c.estado} /></td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Paginación al fondo del panel */}
            <Pagination
              pagination={{
                actual: pagina,
                totalPaginas: totalPaginas,
                total: respuesta?.pagination?.total || 0,
                perPage: respuesta?.pagination?.per_page || perPage,
              }}
              onPageChange={setPagina}
              onPrev={() => setPagina(p => Math.max(1, p - 1))}
              onNext={() => setPagina(p => Math.min(totalPaginas, p + 1))}
              onPerPageChange={n => { setPerPage(n); setPagina(1) }}
            />
          </div>
        </>
      )}

      {modal && (
        <Modal title={editando ? 'Editar pago' : 'Nuevo pago'} onClose={() => setModal(false)} l key={modalKey}>
          <form onSubmit={handleSubmit(guardar)}>
            <div style={{ display: 'flex', gap: '12px', marginBottom: '14px', flexWrap: 'wrap', alignItems: 'flex-end' }}>
              <div style={{ flex: '1 1 200px' }}>
                <Field label="Proyecto" required>
                  <select className="sel" {...register('proyecto_id')} onChange={e => {
                    const pId = e.target.value
                    setValue('proyecto_id', pId)
                    const pr = listaProyectos.find(p => String(p.id) === pId)
                    if (pr) {
                      setValue('cliente_id', String(pr.cliente_id))
                      setValue('monto_total', pr.presupuesto || 0)
                    }
                  }}>
                    <option value="">— Seleccionar —</option>
                    {listaProyectos.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
                  </select>
                </Field>
              </div>
              <div style={{ flex: '1 1 200px' }}>
                <Field label="Cliente" required>
                  <SelCliente clientes={listaClientes} value={watch('cliente_id')} onChange={v => setValue('cliente_id', v)} />
                </Field>
              </div>
              <div style={{ flex: '1 1 150px' }}>
                <Field label="Monto servicio">
                  <Controller name="monto_total" control={control} render={({ field }) => <InpCLP value={field.value} onChange={field.onChange} />} />
                </Field>
              </div>
            </div>
            <div className="form-row" style={{ marginBottom: 14 }}>
              <Field label="Descripción"><textarea className="inp" row="3" {...register('descripcion')} /></Field>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 9 }}>
              <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--txt2)', textTransform: 'uppercase' }}>Cuotas / Boletas</span>
              <button type="button" className="btn btn-green" onClick={() => append({
                numero_cuota: fields.length + 1, tipo_pago: 'boleta', boleta_num: '',
                boleta_fecha: '', boleta_monto: 0, pago_fecha: '', pago_monto: 0, estado: 'Pendiente'
              })}>+ Agregar cuota</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              {fields.map((c, i) => (
                <div key={c.id} className="pago-cuota">
                  <div className="pago-cuota-top">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span className="pago-cuota-num">Cuota #{i + 1}</span>
                      <select className="sel" style={{ width: 'auto', padding: '4px 8px', fontSize: 11, fontWeight: 700 }} {...register(`cuotas.${i}.tipo_pago`)}>
                        <option value="boleta">🧾 Boleta</option>
                        <option value="directo">⚡ Directo</option>
                      </select>
                    </div>
                    <div style={{ display: 'flex', gap: 7, alignItems: 'center' }}>
                      <select className="sel" style={{ width: 'auto', padding: '5px 9px', fontSize: 12 }} {...register(`cuotas.${i}.estado`)}>
                        <option value="Pendiente">Pendiente</option>
                        <option value="Pagado">Pagado</option>
                        <option value="Vencido">Vencido</option>
                      </select>
                      <button type="button" className="ibtn ibtn-del" onClick={() => remove(i)} aria-label="Quitar cuota" title="Quitar"><Ic d={I.x} size={12} /></button>
                    </div>
                  </div>
                  {watch(`cuotas.${i}.tipo_pago`) !== 'directo' && (
                    <div className="pago-section">
                      <div className="pago-section-title">📄 Boleta de Honorarios</div>
                      <div style={{ display: 'flex', gap: 9, flexWrap: 'wrap' }}>
                        <div style={{ flex: '1 1 120px' }}><label className="field-lbl">N° Boleta</label><input className="inp" {...register(`cuotas.${i}.boleta_num`)} /></div>
                        <div style={{ flex: '1 1 120px' }}><label className="field-lbl">Fecha emisión</label><input className="inp" type="date" {...register(`cuotas.${i}.boleta_fecha`)} /></div>
                        <div style={{ flex: '1 1 120px' }}><label className="field-lbl">Monto boleta</label>
                          <Controller name={`cuotas.${i}.boleta_monto`} control={control} render={({ field }) => <InpCLP value={field.value} onChange={field.onChange} />} />
                        </div>
                      </div>
                    </div>
                  )}
                  <div className={`pago-section ${watch(`cuotas.${i}.estado`) === 'Pagado' ? 'pago-section-pagado' : ''}`}>
                    <div className={`pago-section-title ${watch(`cuotas.${i}.estado`) === 'Pagado' ? 'pago-section-title-ok' : ''}`}>
                      <Ic d={I.check} /> Pago recibido
                    </div>
                    <div style={{ display: 'flex', gap: 9, flexWrap: 'wrap' }}>
                      <div style={{ flex: '1 1 120px' }}><label className="field-lbl">Fecha de pago</label><input className="inp" type="date" {...register(`cuotas.${i}.pago_fecha`)} /></div>
                      <div style={{ flex: '1 1 120px' }}><label className="field-lbl">Monto recibido</label>
                        <Controller name={`cuotas.${i}.pago_monto`} control={control} render={({ field }) => <InpCLP value={field.value} onChange={field.onChange} />} />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <BotonesGuardar onCancel={() => setModal(false)} isPending={crearPago.isPending || editarPago.isPending} />
          </form>
        </Modal>
      )}

      {del && (
        <Confirm
          msg="¿Eliminar este registro?"
          onSi={async () => { await borrarPago.mutateAsync(del); setDel(null); showToast('Eliminado') }}
          onNo={() => setDel(null)}
        />
      )}
      {delMultiple && (
        <Confirm
          msg={`¿Eliminar ${seleccionados.size} seleccionados?`}
          onSi={async () => {
            for (let id of seleccionados) await borrarPago.mutateAsync(id)
            clearSeleccion()
            setDelMultiple(false)
            showToast('Eliminados')
          }}
          onNo={() => setDelMultiple(false)}
        />
      )}
    </div>
  )
}