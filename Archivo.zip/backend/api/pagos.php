<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    require_once __DIR__ . '/../config.php';
    cors();
    $db = getDB();
    $user = requireAuth();
    $method = $_SERVER['REQUEST_METHOD'];
    // Soporte para method override via query string (POST con _method=PUT)
    if ($method === 'POST' && isset($_GET['_method'])) {
        $method = strtoupper($_GET['_method']);
    }

    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
    $db->exec("SET NAMES utf8mb4");

    if ($user['rol'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Acceso denegado']);
        exit;
    }

    $id_url = $_GET['id'] ?? null;
    if (!$id_url) {
        $path = explode('/', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
        $last = end($path);
        $id_url = is_numeric($last) ? (int)$last : null;
    }

    // Detectar acción especial
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $esRestore = strpos($uri, 'restore') !== false || isset($_GET['restore']);
    $esHard = isset($_GET['hard']) && $_GET['hard'] == '1';
    $esPapelera = isset($_GET['papelera']) && $_GET['papelera'] == '1';

    $limpiar = function($str) { return trim(str_replace("\0", "", (string)($str ?? ''))); };
    
    $cleanInt = function($valor) {
        if (is_null($valor) || $valor === '') return 0;
        $v = str_replace(['.', ',', '$', ' '], '', (string)$valor);
        return (int)round((float)$v);
    };

    // --- LISTAR (GET) ---
    // Soporta paginación: ?page=X&per_page=Y
    if ($method === 'GET') {
        $where = $esPapelera ? "WHERE p.deleted_at IS NOT NULL" : "WHERE p.deleted_at IS NULL";

        // Búsqueda server-side
        $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
        $params = [];
        if ($q !== '') {
            $where .= " AND (p.descripcion LIKE ? OR c.nombre LIKE ? OR pr.nombre LIKE ?)";
            $like = '%' . $q . '%';
            $params[] = $like; $params[] = $like; $params[] = $like;
        }

        // Parámetros de paginación (con cap 100)
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : null;
        $per_page = isset($_GET['per_page']) ? max(1, min(100, (int)$_GET['per_page'])) : null;

        // Contar total (con mismos JOINs por filtro server-side)
        $countSql = "SELECT COUNT(*) FROM pagos p INNER JOIN clientes c ON p.cliente_id = c.id LEFT JOIN proyectos pr ON p.proyecto_id = pr.id {$where}";
        $countStmt = $db->prepare($countSql);
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $sql = "SELECT p.*, c.nombre as cliente_nombre, pr.nombre as proyecto_nombre
                FROM pagos p
                INNER JOIN clientes c ON p.cliente_id = c.id
                LEFT JOIN proyectos pr ON p.proyecto_id = pr.id
                {$where}
                ORDER BY p.id DESC";

        // Aplicar paginación
        if ($page && $per_page) {
            $offset = ($page - 1) * $per_page;
            $sql .= " LIMIT {$per_page} OFFSET {$offset}";
        }

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $pagos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // OPTIMIZACIÓN N+1: cargar TODAS las cuotas en una sola query
        $cuotasPorPago = [];
        if (count($pagos) > 0) {
            $pagoIds = array_map(fn($p) => (int)$p['id'], $pagos);
            $placeholders = implode(',', array_fill(0, count($pagoIds), '?'));
            $sqlC = "SELECT * FROM pago_cuotas WHERE pago_id IN ($placeholders) ORDER BY pago_id ASC, numero_cuota ASC";
            $stmtC = $db->prepare($sqlC);
            $stmtC->execute($pagoIds);
            while ($c = $stmtC->fetch(PDO::FETCH_ASSOC)) {
                $cuotasPorPago[(int)$c['pago_id']][] = $c;
            }
        }

        $res = [];
        foreach ($pagos as $p) {
            $cuotas = $cuotasPorPago[(int)$p['id']] ?? [];
            $suma_pagada = 0;
            foreach ($cuotas as $c) {
                if ($c['estado'] === 'Pagado') {
                    $suma_pagada += (int)($c['pago_monto'] ?? 0);
                }
            }
            $p['total_pagado'] = $suma_pagada;
            $p['cuotas'] = $cuotas;
            $res[] = $p;
        }
        
        // Responder con o sin paginación
        if ($page && $per_page) {
            echo json_encode([
                'ok' => true, 
                'data' => $res,
                'pagination' => [
                    'page' => $page,
                    'per_page' => $per_page,
                    'total' => $total,
                    'total_pages' => (int)ceil($total / $per_page)
                ]
            ]);
        } else {
            echo json_encode(['ok' => true, 'data' => $res]);
        }
        exit;
    }

    // --- RESTAURAR PAGO ---
    // DEBE IR ANTES de POST/CREAR para que no se confunda
    if ($method === 'POST' && $esRestore && $id_url) {
        $id = (int)$id_url;
        $stmt = $db->prepare("UPDATE pagos SET deleted_at = NULL WHERE id = ? AND deleted_at IS NOT NULL");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() > 0) {
            audit($db, $user['id'], 'RESTORE', 'pagos', "Restauró pago #{$id}", $id);
            echo json_encode(['ok' => true, 'message' => 'Pago restaurado']);
        } else {
            echo json_encode(['ok' => false, 'error' => 'Pago no encontrado o no estaba eliminado']);
        }
        exit;
    }

    // --- CREAR (POST) ---
    if ($method === 'POST') {
        $b = json_decode(file_get_contents("php://input"), true);
        if (!$b) throw new Exception("No se recibieron datos");

        // Validación mínima: cliente_id requerido y numérico
        if (empty($b['cliente_id']) || !is_numeric($b['cliente_id'])) {
            err('El campo cliente_id es requerido y debe ser numérico.');
        }

        $db->beginTransaction();

        // 1. Insertar en tabla maestra 'pagos'
        $sql = "INSERT INTO pagos (cliente_id, proyecto_id, descripcion, monto_total, tipo_pago) VALUES (?, ?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        $stmt->execute([
            (int)$b['cliente_id'],
            $b['proyecto_id'] ?: null,
            $limpiar($b['descripcion'] ?? ''),
            $cleanInt($b['monto_total'] ?? 0),
            $b['tipo_pago'] ?? 'boleta'
        ]);
        $pago_id = $db->lastInsertId();

        // 2. Insertar cuotas en 'pago_cuotas'
        if (isset($b['cuotas']) && is_array($b['cuotas'])) {
            $sqlCuota = "INSERT INTO pago_cuotas (
                            pago_id, numero_cuota, boleta_num, boleta_monto, 
                            boleta_fecha, pago_monto, pago_fecha, estado, tipo_pago
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmtC = $db->prepare($sqlCuota);
            foreach ($b['cuotas'] as $index => $cuota) {
                $stmtC->execute([
                    $pago_id, 
                    $index + 1, 
                    $limpiar($cuota['boleta_num'] ?? ''),
                    $cleanInt($cuota['boleta_monto'] ?? 0),
                    !empty($cuota['boleta_fecha']) ? $cuota['boleta_fecha'] : null,
                    $cleanInt($cuota['pago_monto'] ?? 0),
                    !empty($cuota['pago_fecha']) ? $cuota['pago_fecha'] : null,
                    $cuota['estado'] ?? 'Pendiente',
                    $cuota['tipo_pago'] ?? 'boleta'
                ]);
            }
        }
        $db->commit();
        
        // Auditoría
        $montoFmt = number_format($cleanInt($b['monto_total'] ?? 0), 0, ',', '.');
        audit($db, $user['id'], 'CREATE', 'pagos', "Creó pago #{$pago_id} - Cliente: {$b['cliente_id']} - Total: $ {$montoFmt}", $pago_id);
        
        echo json_encode(['ok' => true, 'id' => $pago_id]);
        exit;
    }

    // --- EDITAR (PUT) ---
    if ($method === 'PUT') {
        $b = json_decode(file_get_contents("php://input"), true);
        $target_id = $id_url ?? $b['id'] ?? null;

        if (!$target_id) throw new Exception("ID no proporcionado");
        if (empty($b['cliente_id']) || !is_numeric($b['cliente_id'])) {
            err('El campo cliente_id es requerido y debe ser numérico.');
        }

        $db->beginTransaction();

        // 1. Actualizar Pago Maestro
        $sql = "UPDATE pagos SET cliente_id = ?, proyecto_id = ?, descripcion = ?, monto_total = ?, tipo_pago = ? WHERE id = ? AND deleted_at IS NULL";
        $stmt = $db->prepare($sql);
        $stmt->execute([
            (int)$b['cliente_id'],
            $b['proyecto_id'] ?: null,
            $limpiar($b['descripcion'] ?? ''),
            $cleanInt($b['monto_total'] ?? 0),
            $b['tipo_pago'] ?? 'boleta',
            (int)$target_id
        ]);

        // 2. Manejar Cuotas
        if (isset($b['cuotas']) && is_array($b['cuotas'])) {
            $ids_enviados = [];

            foreach ($b['cuotas'] as $index => $c) {
                if (isset($c['id']) && is_numeric($c['id'])) {
                    // ACTUALIZAR EXISTENTE
                    $ids_enviados[] = (int)$c['id'];
                    $sqlU = "UPDATE pago_cuotas SET 
                                boleta_num = ?, boleta_fecha = ?, boleta_monto = ?, 
                                pago_fecha = ?, pago_monto = ?, estado = ?, numero_cuota = ?, tipo_pago = ? 
                             WHERE id = ?";
                    $stmtU = $db->prepare($sqlU);
                    $stmtU->execute([
                        $limpiar($c['boleta_num'] ?? ''),
                        !empty($c['boleta_fecha']) ? $c['boleta_fecha'] : null,
                        $cleanInt($c['boleta_monto'] ?? 0),
                        !empty($c['pago_fecha']) ? $c['pago_fecha'] : null,
                        $cleanInt($c['pago_monto'] ?? 0),
                        $c['estado'] ?? 'Pendiente',
                        $index + 1,
                        $c['tipo_pago'] ?? 'boleta',
                        (int)$c['id']
                    ]);
                } else {
                    // INSERTAR NUEVA
                    $sqlI = "INSERT INTO pago_cuotas (
                                pago_id, numero_cuota, boleta_num, boleta_monto, 
                                boleta_fecha, pago_fecha, pago_monto, estado, tipo_pago
                             ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmtI = $db->prepare($sqlI);
                    $stmtI->execute([
                        (int)$target_id,
                        $index + 1,
                        $limpiar($c['boleta_num'] ?? ''),
                        $cleanInt($c['boleta_monto'] ?? 0),
                        !empty($c['boleta_fecha']) ? $c['boleta_fecha'] : null,
                        !empty($c['pago_fecha']) ? $c['pago_fecha'] : null,
                        $cleanInt($c['pago_monto'] ?? 0),
                        $c['estado'] ?? 'Pendiente',
                        $c['tipo_pago'] ?? 'boleta'
                    ]);
                    $ids_enviados[] = (int)$db->lastInsertId();
                }
            }

            // 3. ELIMINAR LAS CUOTAS QUE NO VINIERON
            if (count($ids_enviados) > 0) {
                $placeholders = implode(',', array_fill(0, count($ids_enviados), '?'));
                $sqlD = "DELETE FROM pago_cuotas WHERE pago_id = ? AND id NOT IN ($placeholders)";
                $paramsD = array_merge([(int)$target_id], $ids_enviados);
                $db->prepare($sqlD)->execute($paramsD);
            } else {
                $db->prepare("DELETE FROM pago_cuotas WHERE pago_id = ?")->execute([(int)$target_id]);
            }
        }
        
        $db->commit();
        
        // Auditoría
        audit($db, $user['id'], 'UPDATE', 'pagos', "Editó pago #{$target_id}", $target_id);
        
        echo json_encode(['ok' => true]);
        exit;
    }

// --- ELIMINAR (DELETE) ---
    if ($method === 'DELETE') {
        try {
            $target_id = $id_url;
            if (!$target_id && isset($_SERVER['PATH_INFO'])) {
                $target_id = trim($_SERVER['PATH_INFO'], '/');
            }
            if (!$target_id) {
                throw new Exception("ID de pago no proporcionado");
            }

            $id = (int)$target_id;
            
            // Verificar que existe
            $info = $db->prepare("SELECT descripcion FROM pagos WHERE id = ?");
            $info->execute([$id]);
            $pago = $info->fetch();
            
            if (!$pago) {
                throw new Exception("Pago no encontrado");
            }
            
            if ($esHard) {
                // HARD DELETE
                $db->beginTransaction();
                $db->prepare("DELETE FROM pago_cuotas WHERE pago_id = ?")->execute([$id]);
                $db->prepare("DELETE FROM pagos WHERE id = ?")->execute([$id]);
                $db->commit();
                
                audit($db, $user['id'], 'HARD_DELETE', 'pagos', "Eliminó PERMANENTEMENTE pago #{$id}", $id);
                echo json_encode(['ok' => true, 'message' => 'Pago eliminado permanentemente']);
            } else {
                // SOFT DELETE
                $db->prepare("UPDATE pagos SET deleted_at = NOW() WHERE id = ? AND deleted_at IS NULL")->execute([$id]);
                
                audit($db, $user['id'], 'SOFT_DELETE', 'pagos', "Envió a papelera pago #{$id}: " . ($pago['descripcion'] ?? ''), $id);
                echo json_encode(['ok' => true, 'message' => 'Pago enviado a papelera']);
            }
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            errSafe($e, 500);
        }
        exit;
    }

} catch (Throwable $e) {
    if (isset($db) && $db->inTransaction()) $db->rollBack();
    if (function_exists('logError')) {
        logError('Error en pagos.php', ['message' => $e->getMessage(), 'file' => $e->getFile(), 'line' => $e->getLine()]);
    }
    errSafe($e, 500);
}