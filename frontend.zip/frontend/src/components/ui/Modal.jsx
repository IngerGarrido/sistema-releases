import React, { useEffect, useRef, useId, useState } from 'react'
import { I } from '../../assets/js/helpers.js'
import { Ic } from './Ic.jsx'
import { FOCUSABLE_SELECTOR } from './internal.js'

export function Modal({ title, onClose, children, wide, xl, l }) {
  const modalRef = useRef(null)
  const prevFocusRef = useRef(null)
  const onCloseRef = useRef(onClose)
  const titleId = useId()
  useEffect(() => { onCloseRef.current = onClose }, [onClose])

  useEffect(() => {
    prevFocusRef.current = document.activeElement
    // Focus en el primer elemento focuseable del modal
    if (modalRef.current) {
      const focusables = modalRef.current.querySelectorAll(FOCUSABLE_SELECTOR)
      if (focusables.length > 0) {
        focusables[0].focus()
      } else {
        modalRef.current.focus()
      }
    }
    const handleKey = (e) => {
      if (e.key === 'Escape') {
        onCloseRef.current()
        return
      }
      if (e.key === 'Tab' && modalRef.current) {
        const focusables = Array.from(
          modalRef.current.querySelectorAll(FOCUSABLE_SELECTOR)
        ).filter(el => el.offsetParent !== null)
        if (focusables.length === 0) {
          e.preventDefault()
          return
        }
        const first = focusables[0]
        const last = focusables[focusables.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => {
      window.removeEventListener('keydown', handleKey)
      if (prevFocusRef.current && typeof prevFocusRef.current.focus === 'function') {
        prevFocusRef.current.focus()
      }
    }
  }, [])

  return (
    <div className="modal-bg" onClick={onClose}>
      <div
        ref={modalRef}
        className={['modal-box', wide?'wide':'', xl?'xl':'', l?'l':''].filter(Boolean).join(' ')}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onClick={e => e.stopPropagation()}
        tabIndex={-1}
      >
        <div className="modal-hdr">
          <h3 id={titleId} className="modal-title">{title}</h3>
          <button
            className="modal-close"
            onClick={onClose}
            aria-label="Cerrar"
            type="button"
          >
            <Ic d={I.x} size={15}/>
          </button>
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  )
}

export function Confirm({ msg, onSi, onNo, okLabel = 'Eliminar', icon = '🗑️', color = 'var(--acc2)', requireText = null }) {
  const confirmRef = useRef(null)
  const prevFocusRef = useRef(null)
  const [typed, setTyped] = useState('')
  const requireBlocked = requireText && typed.trim() !== String(requireText).trim()

  useEffect(() => {
    prevFocusRef.current = document.activeElement
    if (confirmRef.current) {
      const firstButton = confirmRef.current.querySelector('button')
      if (firstButton) firstButton.focus()
    }
    const handleKey = (e) => {
      if (e.key === 'Escape') { onNo(); return }
      if (e.key === 'Tab' && confirmRef.current) {
        const focusables = Array.from(
          confirmRef.current.querySelectorAll(FOCUSABLE_SELECTOR)
        ).filter(el => el.offsetParent !== null)
        if (focusables.length === 0) { e.preventDefault(); return }
        const first = focusables[0]
        const last = focusables[focusables.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault(); last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault(); first.focus()
        }
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => {
      window.removeEventListener('keydown', handleKey)
      if (prevFocusRef.current && typeof prevFocusRef.current.focus === 'function') {
        prevFocusRef.current.focus()
      }
    }
  }, [onNo])

  return (
    <div className="confirm-bg" onClick={onNo}>
      <div
        ref={confirmRef}
        className="confirm-box"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="confirm-title"
        aria-describedby="confirm-msg"
        onClick={e => e.stopPropagation()}
      >
        <div className="confirm-icon" aria-hidden="true">{icon}</div>
        <p id="confirm-msg" className="confirm-msg">{msg}</p>
        {requireText && (
          <div className="confirm-require" style={{ margin: '0.5rem 0' }}>
            <p style={{ fontSize: '0.85rem', opacity: 0.85, marginBottom: '0.35rem' }}>
              Para confirmar, escribe: <strong>{requireText}</strong>
            </p>
            <input
              type="text"
              value={typed}
              onChange={e => setTyped(e.target.value)}
              placeholder="Escribe aquí…"
              autoFocus
              style={{ width: '100%', padding: '0.5rem', border: '1px solid var(--bd)', borderRadius: '6px' }}
              aria-label="Texto de confirmación requerido"
            />
          </div>
        )}
        <div className="confirm-btns">
          <button className="btn btn-ghost" onClick={onNo}>Cancelar</button>
          <button
            className="btn"
            style={{
              background: color,
              color: '#fff',
              border: 'none',
              opacity: requireBlocked ? 0.5 : 1,
              cursor: requireBlocked ? 'not-allowed' : 'pointer'
            }}
            onClick={onSi}
            disabled={requireBlocked}
          >
            {okLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
