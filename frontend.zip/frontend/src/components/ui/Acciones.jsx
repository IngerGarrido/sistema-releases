import React from 'react'
import { I } from '../../assets/js/helpers.js'
import { Ic } from './Ic.jsx'

export const IBtn = ({ icon, onClick, color, variant, 'aria-label': ariaLabel }) => (
  <button
    className={variant?`ibtn ibtn-${variant}`:'ibtn'}
    style={color&&!variant?{ background:color+'14', color }:{}}
    onClick={onClick}
    aria-label={ariaLabel}
    type="button"
  >
    <Ic d={icon} size={13}/>
  </button>
)

export const Acciones = React.memo(function Acciones({ onVer, onEdit, onDel }) {
  return (
    <div className="acts">
      {onVer  && <IBtn icon={I.eye}   onClick={onVer}  variant="view" aria-label="Ver detalle"/>}
      {onEdit && <IBtn icon={I.edit}  onClick={onEdit} variant="edit" aria-label="Editar"/>}
      {onDel  && <IBtn icon={I.trash} onClick={onDel}  variant="del"  aria-label="Eliminar"/>}
    </div>
  )
})
