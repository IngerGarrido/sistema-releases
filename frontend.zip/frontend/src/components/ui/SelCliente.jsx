import React from 'react'

export function SelCliente({ clientes=[], value, onChange }) {
  const ag=clientes.filter(c=>c.tipo==='Agencia')
  const dr=clientes.filter(c=>c.tipo==='Directo')
  return (
    <select className="sel" value={String(value||'')} onChange={e=>onChange(e.target.value)}>
      <option value="">— Seleccionar cliente —</option>
      {ag.length>0&&<optgroup label="── Agencias">{ag.map(c=><option key={c.id} value={String(c.id)}>{c.nombre_agencia||c.nombre}</option>)}</optgroup>}
      {dr.length>0&&<optgroup label="── Directos">{dr.map(c=><option key={c.id} value={String(c.id)}>{c.nombre}</option>)}</optgroup>}
    </select>
  )
}
