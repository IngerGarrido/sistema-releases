import React from 'react'
import { I } from '../../assets/js/helpers.js'
import { Ic } from './Ic.jsx'
import { Pagination } from './Pagination.jsx'
import { EmptyState } from './EmptyState.jsx'

export function DataPanel({ title, count, total, busqueda, setBusqueda, placeholder,
  onAdd, addLabel, onExcel, filters, activeFilter, onFilter, cols, rows, vacio, loading, children, pagination, onPageChange, onPrevPage, onNextPage, sort, onPerPageChange }) {
  return (
    <div className="data-panel" aria-busy={loading ? 'true' : undefined}>
      {/* Cabecera */}
      <div className="data-panel__head">
        <div>
          <div className="data-panel__title">{title}</div>
          <div className="data-panel__count">
            {total != null && total !== count
              ? <>Mostrando <b>{count}</b> de <b>{total}</b> registros</>
              : <><b>{count}</b> {count === 1 ? 'registro' : 'registros'}</>
            }
          </div>
        </div>
        <div className="data-panel__controls">
          {/* Buscador inline */}
          <div className="data-panel__search">
            <Ic d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z" size={14} aria-hidden="true" />
            <input
              type="text"
              placeholder={placeholder||'Buscar...'}
              value={busqueda}
              onChange={e=>setBusqueda(e.target.value)}
              aria-label={placeholder||'Buscar'}
            />
            {busqueda && (
              <button
                type="button"
                className="data-panel__search-clear"
                onClick={() => setBusqueda('')}
                aria-label="Limpiar búsqueda"
                title="Limpiar"
              >
                <Ic d={I.x} size={12} />
              </button>
            )}
          </div>
          {onExcel && <button className="btn btn-excel" onClick={onExcel} aria-label="Exportar a Excel"><Ic d={I.xls} size={13} stroke="#fff"/>Excel</button>}
          {onAdd   && <button className="btn btn-green" onClick={onAdd} aria-label={addLabel||'Crear nuevo registro'}><Ic d={I.plus} size={13} stroke="#fff"/>{addLabel||'Nuevo'}</button>}
        </div>
      </div>

      {/* Filtros pill */}
      {filters && filters.length > 0 && (
        <div className="data-panel__filters" role="group" aria-label="Filtros">
          {filters.map(f => (
            <button key={f}
              className={`data-panel__filter-btn${activeFilter===f?' data-panel__filter-btn--on':''}`}
              onClick={()=>onFilter&&onFilter(f)}
              aria-pressed={activeFilter===f}
              aria-label={`Filtrar por ${f}`}>
              {f}
            </button>
          ))}
        </div>
      )}

      {/* Slot extra (ej: activos en Usuarios) */}
      {children}

      {/* Tabla */}
      <div className="tbl-wrap">
        <div className="tbl-scroll">
          <table className="tbl">
            <thead><tr>{cols.map((c,i)=>{
              const sortable = sort && c.sortKey
              const active = sort && c.sortKey && sort.key === c.sortKey
              return (
                <th key={i}
                  className={[c.r?'r':'', sortable?'th-sort':'', active?'th-sort--active':''].filter(Boolean).join(' ')}
                  onClick={sortable ? () => sort.toggle(c.sortKey) : undefined}
                >
                  {c.l}
                  {sortable && <span className="th-sort-icon">{active ? (sort.dir==='asc'?'↑':'↓') : '↕'}</span>}
                </th>
              )
            })}</tr></thead>
            <tbody>
              {loading
                ? Array.from({ length: 6 }).map((_, i) => (
                    <tr key={`sk-${i}`} aria-hidden="true">
                      {cols.map((c, j) => (
                        <td key={j} className={`${c.r ? 'r ' : ''}tbl-skeleton-cell`}>
                          <div className="tbl-skeleton-bar" style={{ width: `${50 + ((i*13 + j*17) % 45)}%`, marginLeft: c.r ? 'auto' : 0 }} />
                        </td>
                      ))}
                    </tr>
                  ))
                : rows.length===0
                  ? <tr><td colSpan={cols.length} className="tbl-empty" style={{ padding:0 }}>
                      {typeof vacio === 'string' || vacio == null
                        ? <EmptyState title={vacio || 'Sin registros'} desc="No hay datos para mostrar con los filtros actuales." />
                        : vacio}
                    </td></tr>
                  : rows.map((r,i)=> (
                    <tr key={i}>
                      {cols.map((c,j)=><td key={j} className={c.r?'r':''}>{r[j]}</td>)}
                    </tr>
                  ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Paginación */}
      {pagination && (
        <Pagination
          pagination={pagination}
          onPageChange={pagination.onChange}
          onPrev={() => pagination.onChange(Math.max(1, pagination.actual - 1))}
          onNext={() => pagination.onChange(Math.min(pagination.totalPaginas, pagination.actual + 1))}
          onPerPageChange={onPerPageChange}
        />
      )}
    </div>
  )
}
