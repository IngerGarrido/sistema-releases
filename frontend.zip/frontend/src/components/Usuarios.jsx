import { useState, useEffect, useRef } from 'react'
import { useUnsavedWarning } from '../hooks/useUnsavedWarning.js'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { api, session } from '../assets/js/api.js'
import { fecha } from '../assets/js/helpers.js'
import { DataPanel,Acciones,Modal,Confirm,Toast,Field,BotonesGuardar,Badge,useToast,Skeleton } from './UI.jsx'
import { useUsuarios, useCrearUsuario, useEditarUsuario, useBorrarUsuario } from '../hooks/useQueryApi.js'
import { usuarioSchema } from '../schemas/validation.js'

export default function Usuarios() {
  const yoRef = useRef(session.getUser()||{})
  const yo = yoRef.current

  const { data: lista, isLoading: loading } = useUsuarios()
  const [activos,setActivos]=useState([])
  const [modal,setModal]=useState(false)
  const [modalKey,setModalKey]=useState(0)
  const [editando,setEditando]=useState(null)
  const [del,setDel]=useState(null)
  const [toast,showToast]=useToast()
  const [busqueda,setBusqueda]=useState('')

  const { register, handleSubmit, reset, formState: { errors, isDirty }, watch, setValue } = useForm({
    resolver: zodResolver(usuarioSchema),
    defaultValues: {
      nombre: '',
      email: '',
      password: '',
      rol: 'usuario',
      activo: '1'
    }
  })

  useEffect(()=>{
    const fn=async()=>{
      try{
        const res=await api.activos()||[]
        const miNombre=yo?.nombre||yo?.user||yo?.username||'Yo'
        const otros=res.filter(u=>u.nombre!==miNombre)
        setActivos([{nombre:`${miNombre} (Tú)`},...otros])
      }catch{ const mn=yo?.nombre||yo?.user||'Yo'; setActivos([{nombre:`${mn} (Tú)`}]) }
    }
    fn(); const t=setInterval(fn,30000); return()=>clearInterval(t)
  },[])

  const filtrados=(lista||[]).filter(u=>
    (u.nombre||'').toLowerCase().includes(busqueda.toLowerCase())||
    (u.email||'').toLowerCase().includes(busqueda.toLowerCase())
  )

  const crearUsuario = useCrearUsuario()
  const editarUsuario = useEditarUsuario()
  const borrarUsuario = useBorrarUsuario()

  const abrir = (u) => {
    if (u) {
      reset({
        ...u,
        activo: u.activo ? '1' : '0',
        password: ''
      })
      setEditando(u)
    } else {
      reset({
        nombre: '',
        email: '',
        password: '',
        rol: 'usuario',
        activo: '1'
      })
      setEditando(null)
    }
    setModalKey(k=>k+1)
    setModal(true)
  }

  const guardar = async (data) => {
    try {
      const dataToSend = {
        ...data,
        activo: data.activo === '1' || data.activo === true ? 1 : 0
      }
      if (data.id) {
        await editarUsuario.mutateAsync({ id: data.id, data: dataToSend })
      } else {
        await crearUsuario.mutateAsync(dataToSend)
      }
      setModal(false)
      showToast('Usuario guardado')
    } catch(err) {
      console.error('Error guardando:', err)
      showToast(err.message)
    }
  }
  const borrar=async()=>{
    if(!del) return
    try{await borrarUsuario.mutateAsync(del);showToast('Eliminado')}catch(err){showToast(err.message)}
    finally{setDel(null)}
  }

  const isEditing = watch('id')
  useUnsavedWarning(modal && isDirty)

  return (
    <div>
      {toast&&<Toast {...toast}/>}
      
      {/* Skeleton loading */}
      {loading && (
        <div className="card" style={{padding:'16px'}}>
          <div style={{marginBottom:'16px'}}>
            <Skeleton className="skeleton-title" />
          </div>
          {[...Array(5)].map((_,i)=>(
            <Skeleton key={i} className="skeleton-row" />
          ))}
        </div>
      )}
      
      {!loading && <DataPanel
        title="Usuarios" count={filtrados.length} total={lista?.length||0}
        busqueda={busqueda} setBusqueda={setBusqueda}
        placeholder="Buscar por nombre o email..."
        onAdd={()=>abrir(null)} addLabel="Nuevo usuario"
        loading={loading}
        cols={[{l:'Nombre'},{l:'Email'},{l:'Rol'},{l:'Estado'},{l:'Último acceso'},{l:'Acciones',r:true}]}
        rows={filtrados.map(u=>[
          <span style={{fontWeight:700,color:'var(--txt)'}}>
            {u.nombre}{u.id==yo?.id&&<span className="tbl-muted" style={{marginLeft:5}}>(tú)</span>}
          </span>,
          <span className="tbl-muted">{u.email}</span>,
          <Badge s={u.rol}/>,
          <span style={{fontSize:12,color:u.activo?'var(--acc3)':'var(--txt2)',fontWeight:600}}>{u.activo?'● Activo':'○ Inactivo'}</span>,
          <span className="tbl-muted">{u.ultimo_acceso?fecha(u.ultimo_acceso.slice(0,10)):'—'}</span>,
          <Acciones onEdit={()=>abrir(u)} onDel={u.id!=yo?.id?()=>setDel(u.id):undefined}/>,
        ])}
        vacio="No se encontraron usuarios"
      >
        {/* Activos ahora — children de DataPanel */}
        {(activos.length>0||yo?.nombre)&&(
          <div className="activos-bar" style={{margin:'0 0 0'}}>
            <span className="activos-lbl">🟢 Conectados ahora:</span>
            {activos.length>0
              ?activos.map((a,i)=><span key={i} className="activos-pill">{a.nombre}</span>)
              :<span className="activos-pill">{yo?.nombre||'Usuario'} (Tú)</span>
            }
          </div>
        )}
      </DataPanel>}
      {modal&&(
        <Modal title={editando ? 'Editar usuario' : 'Nuevo usuario'} onClose={()=>setModal(false)} key={modalKey}>
          <form onSubmit={handleSubmit(guardar)}>
            <div className="form-row">
              <Field label="Nombre" required>
                <input className="inp" {...register('nombre')} />
                {errors.nombre && <span className="field-err">{errors.nombre.message}</span>}
              </Field>
              <Field label="Email" required>
                <input className="inp" type="email" {...register('email')} />
                {errors.email && <span className="field-err">{errors.email.message}</span>}
              </Field>
              <Field label={isEditing ? 'Nueva contraseña (vacío = no cambiar)' : 'Contraseña'} required={!isEditing}>
                <input className="inp" type="password" {...register('password')} />
                {errors.password && <span className="field-err">{errors.password.message}</span>}
              </Field>
              <Field label="Rol" half>
                <select className="sel" {...register('rol')}>
                  <option value="admin">Administrador</option>
                  <option value="usuario">Usuario</option>
                </select>
              </Field>
              <Field label="Estado" half>
                <select className="sel" {...register('activo')}>
                  <option value="1">Activo</option>
                  <option value="0">Inactivo</option>
                </select>
              </Field>
            </div>
            <BotonesGuardar onCancel={()=>setModal(false)} isPending={crearUsuario.isPending || editarUsuario.isPending} />
          </form>
        </Modal>
      )}
      {del&&<Confirm msg="¿Eliminar este usuario?" onSi={borrar} onNo={()=>setDel(null)}/>}
    </div>
  )
}
