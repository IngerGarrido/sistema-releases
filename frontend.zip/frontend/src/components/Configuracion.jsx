import React, { useState, useEffect, useCallback, memo, useRef } from 'react'
import { api, resolveUploadUrl, session } from '../assets/js/api.js'
import { Toast, Field, InpCLP, Ic, Confirm, Modal, Skeleton, NumberInput } from './UI.jsx'
import { FUENTES, I, contrastRatio } from '../assets/js/helpers.js'
import { compressImage } from '../assets/js/imageCompress.js'
import { useUnsavedWarning } from '../hooks/useUnsavedWarning.js'
import MigracionesPanel from './MigracionesPanel.jsx'
import ActualizacionesPanel from './ActualizacionesPanel.jsx'

/* ── Quill WYSIWYG ─────────────────────────────── */
function QuillEditor({ value, onChange }) {
  const ref=useRef(null); const qRef=useRef(null)
  useEffect(()=>{
    if(!ref.current||qRef.current) return
    const init=()=>{
      if(!window.Quill){setTimeout(init,100);return}
      const q=new window.Quill(ref.current,{theme:'snow',modules:{toolbar:[
        ['bold','italic','underline'],[{list:'ordered'},{list:'bullet'}],[{header:[1,2,3,false]}],['clean']
      ]}})
      q.root.innerHTML=value||''
      q.on('text-change',()=>{ const h=q.root.innerHTML; if(h!==value) onChange(h) })
      qRef.current=q
    }
    init()
  },[])
  useEffect(()=>{ if(qRef.current&&qRef.current.root.innerHTML!==value) qRef.current.root.innerHTML=value||'' },[value])
  return (
    <div className="quill-wrapper">
      <div ref={ref} className="quill-editor"/>
    </div>
  )
}

/* ── Modal para Plantilla de Términos ───────────── */
function PlantillaModal({ plantilla, onClose, onSave, showToast }) {
  const [form, setForm] = useState({
    nombre: '',
    descripcion: '',
    terminos_obligaciones: '',
    terminos_desarrollo: '',
    terminos_condiciones: '',
    activa: 1,
    orden: 0,
    ...plantilla
  })

  useEffect(() => {
    setForm({
      nombre: '',
      descripcion: '',
      terminos_obligaciones: '',
      terminos_desarrollo: '',
      terminos_condiciones: '',
      activa: 1,
      orden: 0,
      ...plantilla
    })
  }, [plantilla])

  const handleSubmit = (e) => {
    e.preventDefault()
    if(!form.nombre.trim()){
      showToast?.('El nombre es obligatorio', 'err')
      return
    }
    onSave({...form, id: plantilla?.id})
  }

  return (
    <Modal 
      title={plantilla ? 'Editar Plantilla' : 'Nueva Plantilla'} 
      onClose={onClose} 
      xl
    >
      <form onSubmit={handleSubmit}>
        <div style={{display:'flex',flexDirection:'column',gap:16}}>
          <Field label="Nombre *">
            <input 
              className="inp" 
              value={form.nombre} 
              onChange={e=>setForm({...form,nombre:e.target.value})}
              placeholder="Ej: Ecommerce, Web Corporativa..."
              required
            />
          </Field>
          
          <Field label="Descripción">
            <input 
              className="inp" 
              value={form.descripcion} 
              onChange={e=>setForm({...form,descripcion:e.target.value})}
              placeholder="Breve descripción de cuándo usar esta plantilla"
            />
          </Field>

          <div className="form-row">
            <Field label="Orden" half>
              <NumberInput
                className="inp"
                value={form.orden}
                onChange={e=>setForm({...form,orden:e.target.value})}
                placeholder="0"
              />
            </Field>
            <Field label="Activa" half>
              <select 
                className="sel"
                value={form.activa} 
                onChange={e=>setForm({...form,activa:parseInt(e.target.value)})}
              >
                <option value={1}>Sí</option>
                <option value={0}>No</option>
              </select>
            </Field>
          </div>

          <Field label="Obligaciones del Cliente">
            <QuillEditor
              value={form.terminos_obligaciones||''}
              onChange={v=>setForm(p=>({...p,terminos_obligaciones:v}))}
            />
          </Field>

          <Field label="Desarrollo">
            <QuillEditor
              value={form.terminos_desarrollo||''}
              onChange={v=>setForm(p=>({...p,terminos_desarrollo:v}))}
            />
          </Field>

          <Field label="Términos y Condiciones">
            <QuillEditor
              value={form.terminos_condiciones||''}
              onChange={v=>setForm(p=>({...p,terminos_condiciones:v}))}
            />
          </Field>
        </div>
        <div style={{display:'flex',gap:12,marginTop:24,justifyContent:'flex-end'}}>
          <button type="button" className="btn btn-ghost" onClick={onClose}>Cancelar</button>
          <button type="submit" className="btn btn-primary">
            {plantilla ? 'Guardar Cambios' : 'Crear Plantilla'}
          </button>
        </div>
      </form>
    </Modal>
  )
}

/* ── Color picker row ──────────────────────────── */
const ColorRow = memo(({ label, campo, value, onChange, half }) => {
  const [local,setLocal]=useState(value||'#000000')
  useEffect(()=>setLocal(value||'#000000'),[value])
  const handle=val=>{ setLocal(val); onChange(campo,val) }
  return (
    <Field label={label} half={half}>
      <div className="color-row">
        <input type="color" value={local} onChange={e=>handle(e.target.value)} className="color-swatch"/>
        <input className="inp" value={local} onChange={e=>handle(e.target.value)}/>
      </div>
    </Field>
  )
})

/* ── Card con encabezado consistente ───────────── */
function CfgCard({ ico, title, children }) {
  // Si ico es un string de I (icono Lucide), usar Ic, si no mostrar directo (emoji)
  const iconContent = I[ico] ? <Ic d={I[ico]} size={18}/> : ico
  return (
    <div className="cfg-card">
      <div className="cfg-card-hdr">
        <div className="cfg-card-ico">{iconContent}</div>
        <span className="cfg-card-title">{title}</span>
      </div>
      <div className="cfg-card-body">{children}</div>
    </div>
  )
}

/* ── Picker de fuente con preview ───────────────── */
function FontPicker({ value, onChange }) {
  const [open, setOpen] = useState(false)
  const cur = value || 'DM Sans'
  return (
    <div className="font-picker">
      <button type="button" className="font-picker-btn" onClick={() => setOpen(o=>!o)}>
        <span style={{ fontFamily: `'${cur}',sans-serif` }}>{cur}</span>
        <span style={{ opacity:.5 }}>▾</span>
      </button>
      {open && (
        <>
          <div onClick={()=>setOpen(false)} style={{ position:'fixed', inset:0, zIndex:19 }}/>
          <div className="font-picker-menu">
            {FUENTES.map(f => (
              <div key={f}
                className={`font-picker-opt${f===cur?' is-active':''}`}
                style={{ fontFamily: `'${f}',sans-serif` }}
                onClick={()=>{ onChange(f); setOpen(false) }}>
                {f} <span style={{ opacity:.5, marginLeft:8 }}>— Aa Bb 123</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

/* ── Badge de contraste WCAG ─────────────────────── */
function ContrastBadge({ fg, bg, label }) {
  const r = contrastRatio(fg, bg)
  if (r == null) return null
  const status = r >= 4.5 ? 'ok' : r >= 3 ? 'warn' : 'bad'
  const text = status === 'ok' ? 'Buen contraste' : status === 'warn' ? 'Contraste bajo' : 'Contraste insuficiente'
  return (
    <span className={`cfg-contrast cfg-contrast--${status}`} title={`Ratio ${r.toFixed(2)}:1 (WCAG)`}>
      {status === 'ok' ? '✓' : '!'} {label}: {text} ({r.toFixed(1)}:1)
    </span>
  )
}

/* ── Preview del Login ───────────────────────────── */
function LoginPreview({ form, yo }) {
  const titulo    = form.login_titulo    || form.nombre_empresa || 'Mi Sistema'
  const subtitulo = form.login_subtitulo || 'Inicia sesión para continuar'
  const colorBoton= form.login_color_boton || form.color_activo || '#3b5bdb'
  const fondo     = form.login_color_fondo || ''
  const imgFondo  = form.login_imagen_fondo || ''
  const mostrar   = form.login_mostrar_logo === '0' ? false : true
  const style = imgFondo
    ? { backgroundImage: `url(${resolveUploadUrl(imgFondo)})` }
    : fondo ? { background: fondo } : {}
  const inicial = (titulo || '?').trim()[0]?.toUpperCase() || '?'
  return (
    <div className="cfg-login-preview" style={style}>
      <div className="cfg-login-card">
        {mostrar && (
          form.logo_url
            ? <img src={resolveUploadUrl(form.logo_url)} alt="logo" style={{ maxHeight:34, maxWidth:'80%', objectFit:'contain' }}/>
            : <div className="cfg-login-logo-circle" style={{ background: colorBoton }}>{inicial}</div>
        )}
        <h3>{titulo}</h3>
        <p>{subtitulo}</p>
        <input className="inp" type="email" placeholder="tu@email.com" disabled style={{ marginBottom:8, fontSize:11, padding:'6px 8px' }}/>
        <input className="inp" type="password" placeholder="••••••••" disabled style={{ marginBottom:10, fontSize:11, padding:'6px 8px' }}/>
        <button type="button" className="cfg-login-btn" style={{ background: colorBoton }}>Ingresar</button>
      </div>
    </div>
  )
}

/* ── Defaults por tab para "Restaurar" ──────────── */
const TAB_DEFAULTS = {
  empresa:    { nombre_empresa:'', nombre_propietario:'', rut:'', sitio_web:'', email:'', telefono:'', direccion:'' },
  marca:      { color_primario:'#3b5bdb', color_secundario:'#1e2340' },
  apariencia: { sidebar_bg:'#1e2340', sidebar_text:'#ffffff', color_activo:'#3b5bdb', fuente:'DM Sans',
                login_titulo:'', login_subtitulo:'', login_color_fondo:'', login_color_boton:'',
                login_mostrar_logo:'1' },
  documentos: { cotizacion_prefijo:'COT', terminos_obligaciones:'', terminos_desarrollo:'', terminos_condiciones:'' },
  finanzas:   { meta_mensual:0, retencion_honorarios:'13.75' },
}

/* Mapeo tab → claves para indicador de "dirty" */
const TAB_FIELDS = {
  empresa:    ['nombre_empresa','nombre_propietario','rut','sitio_web','email','telefono','direccion','logo_url'],
  marca:      ['color_primario','color_secundario','logo_cotizaciones_url'],
  apariencia: ['sidebar_bg','sidebar_text','color_activo','fuente','fuente_global','sidebar_lite',
               'login_titulo','login_subtitulo','login_color_fondo','login_color_boton',
               'login_mostrar_logo','login_imagen_fondo'],
  documentos: ['cotizacion_prefijo','terminos_obligaciones','terminos_desarrollo','terminos_condiciones'],
  finanzas:   ['meta_mensual','retencion_honorarios'],
  sistema:    ['backup_auto_enabled','backup_auto_freq_days','backup_auto_retention'],
}

/* Validadores inline */
const VALIDATORS = {
  email: (v) => !v || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
  url:   (v) => !v || /^(https?:\/\/)?[\w.-]+\.[a-z]{2,}(\/.*)?$/i.test(v),
  rut:   (v) => !v || /^[\d]{1,2}(\.?\d{3}){2}-?[\dkK]$/.test(v.replace(/\s/g,'')),
}

/* Diff entre dos objetos planos */
function diffObj(prev, next) {
  const out = {}
  const keys = new Set([...Object.keys(prev||{}), ...Object.keys(next||{})])
  for (const k of keys) {
    const a = prev?.[k] ?? '', b = next?.[k] ?? ''
    if (String(a) !== String(b)) out[k] = next?.[k] ?? ''
  }
  return out
}

/* Zona de drop para imágenes */
function DropZone({ onFile, children }) {
  const [hover, setHover] = useState(false)
  return (
    <div
      onDragOver={e => { e.preventDefault(); setHover(true) }}
      onDragLeave={() => setHover(false)}
      onDrop={e => {
        e.preventDefault(); setHover(false)
        const f = e.dataTransfer.files?.[0]
        if (f && f.type.startsWith('image/')) onFile(f)
      }}
      className={hover ? 'drop-hover' : ''}
      style={{
        border: hover ? '2px dashed var(--accent)' : '2px dashed transparent',
        borderRadius: 8,
        padding: hover ? 8 : 10,
        transition: 'all .15s',
        background: hover ? 'var(--sel-bg)' : 'transparent'
      }}>
      {children}
    </div>
  )
}

/* Input con validación inline */
function ValidatedInput({ type='text', value, onChange, validator, placeholder }) {
  const v = value || ''
  const valid = validator ? validator(v) : true
  const show = v.length > 0
  return (
    <div style={{ position:'relative' }}>
      <input className="inp" type={type} value={v} onChange={onChange}
        placeholder={placeholder}
        style={{ paddingRight: show ? 32 : undefined,
                 borderColor: show && !valid ? 'var(--err)' : undefined }}/>
      {show && (
        <span style={{
          position:'absolute', right:10, top:'50%', transform:'translateY(-50%)',
          fontSize:14, color: valid ? '#16a34a' : 'var(--err)',
          pointerEvents:'none', fontWeight:700
        }}>{valid ? '✓' : '✕'}</span>
      )}
    </div>
  )
}

/* ── Componente principal ──────────────────────── */
export default function Configuracion({ onPanelChange }) {
  const yo = session.getUser() || {}
  const [tab,setTab]           = useState('empresa')
  const [form,setForm]         = useState({})
  const [saved,setSaved]       = useState(false)
  const [toast,setToast]       = useState(null)
  const [resetN,setResetN]     = useState('')
  const [loading,setLoading]   = useState(true)
  const [loadingAct,setLoadAct]= useState(false)
  const [confirmAct,setConfirmAct]=useState(null)
  const logoRef                = useRef()
  const logoCotRef             = useRef()

  // Estados para plantillas de términos
  const [plantillas, setPlantillas] = useState([])
  const [plantillaEdit, setPlantillaEdit] = useState(null)
  const [showPlantillaModal, setShowPlantillaModal] = useState(false)
  const [loadingPlantillas, setLoadingPlantillas] = useState(false)

  // Estados para backups mejorados
  const [backups, setBackups] = useState([])
  const [loadingBackups, setLoadingBackups] = useState(false)
  const [generandoBackup, setGenerandoBackup] = useState(false)
  const [backupEliminar, setBackupEliminar] = useState(null)

  const showT=(msg,type='ok')=>{ setToast({msg,type}); setTimeout(()=>setToast(null),3000) }
  const handleColor=useCallback((campo,valor)=>setForm(p=>({...p,[campo]:valor})),[])

  const [originalForm, setOriginalForm] = useState({})

  useEffect(()=>{
    api.getConfig().then(data => {
      setForm(data)
      setOriginalForm(data)
    }).catch(err => {
      console.error('Error cargando configuración:', err)
      showT('No se pudo cargar la configuración', 'err')
    }).finally(()=>setLoading(false))
  },[])

  const set=k=>e=>setForm(p=>({...p,[k]:e.target.value}))

  // Guardar: optimistic UI + solo deltas
  const guardar=async(silencioso=false)=>{
    const delta = diffObj(originalForm, form)
    if (Object.keys(delta).length === 0) {
      if (!silencioso) showT('Sin cambios para guardar', 'info')
      return
    }
    const snapshot = form // optimistic
    setOriginalForm(snapshot)
    setSaved(true)
    if (!silencioso) showT('Configuración guardada')
    setTimeout(()=>setSaved(false), 2500)
    onPanelChange && onPanelChange(snapshot)
    try {
      await api.saveConfig(delta)
    } catch (e) {
      // Revertir si el server rechaza
      setOriginalForm(originalForm)
      setSaved(false)
      showT('Error: ' + e.message, 'err')
    }
  }

  // Autosave con debounce (si activado)
  useEffect(() => {
    if (!form?.autosave || form.autosave === '0') return
    if (!hasUnsavedChanges) return
    const t = setTimeout(() => guardar(true), 1200)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form])

  // Atajo Ctrl/Cmd + S
  useEffect(() => {
    const onKey = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault()
        if (hasUnsavedChanges) guardar()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form, originalForm])

  // Auditoría de cambios en configuración (para tab Sistema)
  const [auditConfig, setAuditConfig] = useState([])
  const [loadingAudit, setLoadingAudit] = useState(false)
  const cargarAuditConfig = async () => {
    setLoadingAudit(true)
    try {
      const r = await api.getAuditoria({ tabla: 'configuracion', per_page: 10 })
      const list = Array.isArray(r) ? r
                 : Array.isArray(r?.data) ? r.data
                 : Array.isArray(r?.items) ? r.items
                 : Array.isArray(r?.data?.items) ? r.data.items
                 : []
      setAuditConfig(list)
    } catch (e) { /* silent */ } finally { setLoadingAudit(false) }
  }
  useEffect(() => { if (tab === 'sistema') cargarAuditConfig() }, [tab])

  // Búsqueda dentro de configuración
  const [search, setSearch] = useState('')

  const ejecutarMantenimiento=async()=>{
    setConfirmAct(null)
    setLoadAct(true)
    try{ const r=await api.mantenimiento(); showT(r||'Limpieza completada') }
    catch(e){showT(e.message,'err')} finally{setLoadAct(false)}
  }

  const descargarBackup=()=>{
    setConfirmAct(null)
    api.backup()
    showT('Descarga de backup iniciada')
  }

  // Funciones para backups mejorados
  const cargarBackups=async()=>{
    setLoadingBackups(true)
    try{
      const r=await api.listarBackups()
      setBackups(r.backups||r.data?.backups||[])
    }catch(e){showT(e.message,'err')}finally{setLoadingBackups(false)}
  }

  const generarBackup=async()=>{
    setGenerandoBackup(true)
    try{
      const r=await api.generarBackup()
      showT(r.message||r.data?.message||'Backup generado')
      cargarBackups()
    }catch(e){showT(e.message,'err')}finally{setGenerandoBackup(false)}
  }

  const descargarBackupArchivo=(filename)=>{
    api.descargarBackup(filename)
    showT('Descargando backup...')
  }

  const eliminarBackupArchivo=async(filename)=>{
    setBackupEliminar(filename)
  }

  const confirmarEliminarBackup=async()=>{
    if(!backupEliminar)return
    try{
      await api.eliminarBackup(backupEliminar)
      showT('Backup eliminado')
      setBackupEliminar(null)
      cargarBackups()
    }catch(e){showT(e.message,'err')}
  }

  // Cargar backups al abrir pestaña sistema
  useEffect(()=>{
    if(tab==='sistema') cargarBackups()
  },[tab])

  const subirLogo=async e=>{
    const f0=e.target.files[0]; if(!f0) return
    try{
      const f = await compressImage(f0, { maxDim: 800, quality: 0.85 })
      const r=await api.subirLogo(f)
      setForm(p=>({...p,logo_url:r.logo_url}))
      showT('Logo subido')
    } catch(e){showT(e.message,'err')}
  }

  const eliminarLogo=async()=>{
    try{ await api.borrarLogo(); setForm(p=>({...p,logo_url:''})); showT('Logo eliminado') }
    catch(e){showT(e.message,'err')}
  }

  // Funciones para plantillas de términos
  const cargarPlantillas=async()=>{
    setLoadingPlantillas(true)
    try{
      const r=await api.getPlantillasTerminos(true)
      setPlantillas(r.plantillas||[])
    }catch(e){showT(e.message,'err')}finally{setLoadingPlantillas(false)}
  }

  const guardarPlantilla=async(data)=>{
    try{
      if(data.id){
        await api.actualizarPlantillaTerminos(data.id, data)
        showT('Plantilla actualizada')
      }else{
        await api.crearPlantillaTerminos(data)
        showT('Plantilla creada')
      }
      setShowPlantillaModal(false)
      setPlantillaEdit(null)
      cargarPlantillas()
    }catch(e){showT(e.message,'err')}
  }

  const desactivarPlantilla=async(id)=>{
    if(!confirm('¿Desactivar esta plantilla?'))return
    try{
      await api.desactivarPlantillaTerminos(id)
      showT('Plantilla desactivada')
      cargarPlantillas()
    }catch(e){showT(e.message,'err')}
  }

  const activarPlantilla=async(id)=>{
    try{
      await api.actualizarPlantillaTerminos(id, {activa: 1})
      showT('Plantilla activada')
      cargarPlantillas()
    }catch(e){showT(e.message,'err')}
  }

  useEffect(()=>{
    if(tab==='plantillas') cargarPlantillas()
  },[tab])

  const subirLogoCotizaciones=async e=>{
    const f0=e.target.files[0]; if(!f0) return
    try{
      const f = await compressImage(f0, { maxDim: 1200, quality: 0.85 })
      const r=await api.subirLogoCotizaciones(f)
      setForm(p=>({...p,logo_cotizaciones_url:r.logo_cotizaciones_url}))
      showT('Logo de cotizaciones subido')
    } catch(e){showT(e.message,'err')}
  }

  const eliminarLogoCotizaciones=async()=>{
    try{ await api.borrarLogoCotizaciones(); setForm(p=>({...p,logo_cotizaciones_url:''})); showT('Logo de cotizaciones eliminado') }
    catch(e){showT(e.message,'err')}
  }

  const hacerReset=async()=>{
    const n=parseInt(resetN)
    if(!n||n<1){showT('Ingresa un número válido','err');return}
    try{await api.resetNumero(n);showT(`Siguiente cotización: ${n}`);setResetN('')}
    catch(e){showT(e.message,'err')}
  }

  const TABS=[
    {id:'empresa',    ico:'building',label:'Empresa', desc:'Datos básicos',
     keys:'nombre rut email telefono direccion sitio web'},
    {id:'marca',      ico:'palette',label:'Marca', desc:'Logos y colores PDF',
     keys:'logo imagen color primario secundario pdf cotizaciones'},
    {id:'apariencia', ico:'paint',label:'Apariencia', desc:'Sidebar y Login',
     keys:'sidebar color fondo texto activo fuente tipografia login boton contraste lite compacto'},
    {id:'documentos', ico:'fileText',label:'Documentos', desc:'Cotizaciones y términos',
     keys:'cotizacion prefijo numero terminos obligaciones desarrollo condiciones'},
    {id:'plantillas', ico:'clipboard',label:'Plantillas', desc:'Términos por tipo',
     keys:'plantilla terminos tipo proyecto'},
    {id:'finanzas',   ico:'pay',label:'Finanzas', desc:'Metas e impuestos',
     keys:'meta mensual retencion sii impuestos honorarios'},
    {id:'sistema',    ico:'gear',label:'Sistema', desc:'Backups y mantenimiento',
     keys:'backup mantenimiento limpiar bd autosave importar exportar auditoria logs auto'},
  ]

  // Filtrar tabs según búsqueda
  const q = search.trim().toLowerCase()
  const TABS_VIS = !q ? TABS : TABS.filter(t =>
    (t.label + ' ' + t.desc + ' ' + (t.keys||'')).toLowerCase().includes(q)
  )
  // Auto-saltar a primer match cuando se busca y la tab actual no matchea
  useEffect(() => {
    if (q && TABS_VIS.length && !TABS_VIS.find(t => t.id === tab)) {
      setTab(TABS_VIS[0].id)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q])

  const hasUnsavedChanges = JSON.stringify(form) !== JSON.stringify(originalForm)
  useUnsavedWarning(hasUnsavedChanges)

  // ¿Esta tab tiene cambios sin guardar?
  const tabHasDirty = (tabId) => {
    const keys = TAB_FIELDS[tabId]
    if (!keys) return false
    return keys.some(k => (form[k] ?? '') !== (originalForm[k] ?? ''))
  }

  // Restaurar valores de la tab actual a sus defaults
  const restaurarTab = (tabId) => {
    const defs = TAB_DEFAULTS[tabId]
    if (!defs) return
    if (!confirm('¿Restaurar todos los valores de esta sección a los predeterminados? Los cambios no se guardarán hasta que pulses "Guardar".')) return
    setForm(p => ({ ...p, ...defs }))
    showT('Valores restaurados (recuerda guardar)')
  }

  // Exportar configuración como JSON
  const exportarConfig = () => {
    const blob = new Blob([JSON.stringify(form, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `configuracion-${new Date().toISOString().slice(0,10)}.json`
    document.body.appendChild(a); a.click(); a.remove()
    URL.revokeObjectURL(url)
    showT('Configuración exportada')
  }

  const importarConfig = (file) => {
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result)
        if (typeof data !== 'object' || Array.isArray(data)) throw new Error('JSON inválido')
        setForm(p => ({ ...p, ...data }))
        showT('Configuración cargada (recuerda guardar)')
      } catch (e) {
        showT('Archivo inválido: ' + e.message, 'err')
      }
    }
    reader.readAsText(file)
  }

  // Confirmación con texto tipeado para acciones destructivas
  const [typedConfirm, setTypedConfirm] = useState('')

  // Subida de imagen de fondo del Login
  const loginBgRef = useRef()
  const subirLoginBg = async (e) => {
    const f = e.target.files[0]; if (!f) return
    try { const r = await api.subirLoginBg(f); setForm(p=>({...p, login_imagen_fondo: r.login_imagen_fondo})); showT('Imagen de fondo subida') }
    catch(e) { showT(e.message, 'err') }
  }
  const eliminarLoginBg = async () => {
    try { await api.borrarLoginBg(); setForm(p=>({...p, login_imagen_fondo:''})); showT('Imagen de fondo eliminada') }
    catch(e) { showT(e.message, 'err') }
  }
  const importRef = useRef()

  return (
    <div>
      {toast&&<div className={`toast toast-${toast.type}`}>{toast.type==='err'?'✕':'✓'} {toast.msg}</div>}

      {/* Skeleton loading */}
      {loading && (
        <div className="card" style={{padding:'16px'}}>
          <div style={{marginBottom:'16px'}}>
            <Skeleton className="skeleton-title" />
          </div>
          <div style={{display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:'14px', marginBottom:'16px'}}>
            {[...Array(4)].map((_,i)=>(
              <Skeleton key={i} style={{height:'80px'}} />
            ))}
          </div>
          <Skeleton style={{height:'150px'}} />
        </div>
      )}

      {/* Header mejorado */}
      {!loading && (
        <div className="cfg-header">
        <div className="cfg-header-left">
          <h1 className="cfg-header-title"><Ic d={I.settings}/> Configuración</h1>
          <p className="cfg-header-subtitle">Personaliza tu sistema y gestiona preferencias</p>
        </div>
        {tab !== 'sistema' && (
          <div className={`cfg-status-indicator ${saved ? 'cfg-status-saved' : hasUnsavedChanges ? 'cfg-status-unsaved' : 'cfg-status-saved'}`}>
            {saved ? '✓ Cambios guardados' : hasUnsavedChanges ? '● Cambios sin guardar' : '✓ Sin cambios'}
          </div>
        )}
      </div>
      )}

      <div className="cfg-layout">

        {/* ── Nav lateral ── */}
        <div className="cfg-nav">
          <div className="cfg-nav-header">
            <div className="cfg-nav-label">Secciones</div>
            <input
              type="search"
              className="inp"
              value={search}
              onChange={e=>setSearch(e.target.value)}
              placeholder="Buscar opción…"
              style={{ fontSize:12, padding:'6px 8px', marginTop:6 }}/>
          </div>
          <div className="cfg-nav-list">
            {TABS_VIS.length === 0 && (
              <div style={{ padding:'12px', fontSize:12, color:'var(--txt2)' }}>Sin resultados</div>
            )}
            {TABS_VIS.map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)}
                className={`cfg-tab${tab===t.id?' cfg-tab--on':''}`}>
                <span className="cfg-tab-ico">{I[t.ico] ? <Ic d={I[t.ico]} size={16}/> : t.ico}</span>
                <span className="cfg-tab-label">
                  {t.label}{tabHasDirty(t.id) && <span className="cfg-tab-dot" title="Cambios sin guardar"/>}
                  <span className="cfg-tab-desc">{t.desc}</span>
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* ── Contenido ── */}
        <div className="cfg-content">

          {/* ══ EMPRESA ══ */}
          {tab==='empresa'&&(<>
            <CfgCard ico="building" title="Datos de tu empresa">
              <div className="form-row">
                <Field label="Nombre empresa" half>
                  <input className="inp" value={form.nombre_empresa||''} onChange={set('nombre_empresa')}/>
                </Field>
                <Field label="Tu nombre / cargo" half>
                  <input className="inp" value={form.nombre_propietario||''} onChange={set('nombre_propietario')}/>
                </Field>
                <Field label="RUT" half>
                  <ValidatedInput value={form.rut||''} onChange={set('rut')} validator={VALIDATORS.rut} placeholder="12.345.678-9"/>
                </Field>
                <Field label="Sitio web" half>
                  <ValidatedInput value={form.sitio_web||''} onChange={set('sitio_web')} validator={VALIDATORS.url} placeholder="https://..."/>
                </Field>
                <Field label="Email" half>
                  <ValidatedInput type="email" value={form.email||''} onChange={set('email')} validator={VALIDATORS.email} placeholder="tu@email.com"/>
                </Field>
                <Field label="Teléfono" half>
                  <input className="inp" value={form.telefono||''} onChange={set('telefono')}/>
                </Field>
                <Field label="Dirección" half>
                  <input className="inp" value={form.direccion||''} onChange={set('direccion')}/>
                </Field>
              </div>
              <div className="cfg-utility-row">
                <button type="button" className="cfg-restore-btn" onClick={()=>restaurarTab('empresa')}>
                  Restaurar valores
                </button>
              </div>
            </CfgCard>
          </>)}

          {/* ══ MARCA ══ */}
          {tab==='marca'&&(<>
            <CfgCard ico="image" title="Logo Principal">
              <DropZone onFile={(f)=>subirLogo({target:{files:[f]}})}>
                <div className="logo-area">
                  {form.logo_url&&<img src={resolveUploadUrl(form.logo_url)} alt="Logo" className="logo-preview"/>}
                  <div>
                    <p className="cfg-logo-hint">
                      Arrastra una imagen aquí o usa el botón. Aparece en la parte superior del sidebar y se convierte a blanco automáticamente.
                    </p>
                    <input ref={logoRef} type="file" accept="image/*" className="hidden" onChange={subirLogo}/>
                    <div className="cfg-logo-actions">
                      <button type="button" className="btn btn-ghost" onClick={()=>logoRef.current.click()}>
                        <Ic d={I.up} size={14}/>{form.logo_url?'Cambiar logo':'Subir logo'}
                      </button>
                      {form.logo_url&&(
                        <button type="button" className="btn btn-danger" onClick={eliminarLogo}>Eliminar</button>
                      )}
                    </div>
                  </div>
                </div>
              </DropZone>
            </CfgCard>

            <CfgCard ico="fileText" title="Logo Cotizaciones (Opcional)">
              <DropZone onFile={(f)=>subirLogoCotizaciones({target:{files:[f]}})}>
                <div className="logo-area">
                  {form.logo_cotizaciones_url&&<img src={resolveUploadUrl(form.logo_cotizaciones_url)} alt="Logo Cotizaciones" className="logo-preview"/>}
                  <div>
                    <p className="cfg-logo-hint">
                      Arrastra una imagen aquí. Aparece en el encabezado de los PDF de cotizaciones. Si no se sube, solo se muestra el nombre de la empresa.
                    </p>
                    <input ref={logoCotRef} type="file" accept="image/*" className="hidden" onChange={subirLogoCotizaciones}/>
                    <div className="cfg-logo-actions">
                      <button type="button" className="btn btn-ghost" onClick={()=>logoCotRef.current.click()}>
                        <Ic d={I.up} size={14}/>{form.logo_cotizaciones_url?'Cambiar logo':'Subir logo'}
                      </button>
                      {form.logo_cotizaciones_url&&(
                        <button type="button" className="btn btn-danger" onClick={eliminarLogoCotizaciones}>Eliminar</button>
                      )}
                    </div>
                  </div>
                </div>
              </DropZone>
            </CfgCard>

            <CfgCard ico="paint" title="Colores PDF">
              <div className="form-row">
                <ColorRow half label="Color Primario"   campo="color_primario"  value={form.color_primario}  onChange={handleColor}/>
                <ColorRow half label="Color Secundario" campo="color_secundario" value={form.color_secundario} onChange={handleColor}/>
              </div>
              <div className="cfg-utility-row">
                <button type="button" className="cfg-restore-btn"
                  onClick={()=>handleColor('color_activo', form.color_primario)}
                  disabled={!form.color_primario}>
                  Usar primario como "Ítem Activo" del sidebar
                </button>
                <button type="button" className="cfg-restore-btn" onClick={()=>restaurarTab('marca')}>
                  Restaurar valores
                </button>
              </div>
            </CfgCard>
          </>)}

          {/* ══ APARIENCIA ══ */}
          {tab==='apariencia'&&(<>
            <div className="cfg-grid2 mb-2">
              <CfgCard ico="palette" title="Estilos del Sidebar">
                <div className="form-row">
                  <ColorRow half label="Fondo Sidebar"  campo="sidebar_bg"    value={form.sidebar_bg}    onChange={handleColor}/>
                  <ColorRow half label="Texto Sidebar"  campo="sidebar_text"  value={form.sidebar_text}  onChange={handleColor}/>
                  <ColorRow half label="Ítem Activo"    campo="color_activo"  value={form.color_activo}  onChange={handleColor}/>
                  <Field label="Fuente del sistema" half>
                    <FontPicker value={form.fuente||'DM Sans'} onChange={v=>setForm(p=>({...p,fuente:v,fuente_global:v}))}/>
                    <p className="cfg-hint" style={{margin:'6px 0 0'}}>Se aplica a toda la aplicación.</p>
                  </Field>
                </div>
                <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:12 }}>
                  <ContrastBadge fg={form.sidebar_text||'#ffffff'} bg={form.sidebar_bg||'#1e2340'} label="Texto/Fondo"/>
                  <ContrastBadge fg={'#ffffff'} bg={form.color_activo||'#3b5bdb'} label="Activo"/>
                </div>
                <Field label="Modo del sidebar" style={{ marginTop:12 }}>
                  <select className="sel" value={form.sidebar_lite||'0'} onChange={set('sidebar_lite')}>
                    <option value="0">Normal (con texto)</option>
                    <option value="1">Compacto (solo iconos)</option>
                  </select>
                </Field>
                <div className="cfg-utility-row">
                  <button type="button" className="cfg-restore-btn"
                    onClick={()=>handleColor('color_activo', form.color_primario)}
                    disabled={!form.color_primario}>
                    Sincronizar con color primario PDF
                  </button>
                  <button type="button" className="cfg-restore-btn" onClick={()=>restaurarTab('apariencia')}>
                    Restaurar valores
                  </button>
                </div>
              </CfgCard>

              <CfgCard ico="eye" title="Vista Previa del Sidebar">
                <div className="cfg-preview" style={{ marginTop:0 }}>
                  <div className="cfg-preview-sidebar" style={{background:form.sidebar_bg||'#1e2340'}}>
                    <div className="cfg-preview-brand">
                      <div className="cfg-preview-name" style={{fontFamily:form.fuente||'DM Sans'}}>
                        {form.nombre_empresa||'Mi Sistema'}
                      </div>
                      <div className="cfg-preview-user" style={{fontFamily:form.fuente||'DM Sans'}}>
                        {yo.nombre || 'Usuario'}
                      </div>
                    </div>
                    {['Dashboard','Proyectos','Clientes','Configuración'].map((n,i)=>(
                      <div key={n}
                        className={`cfg-preview-item ${i===0?'active':''}`}
                        style={{
                          background: i===0?(form.color_activo||'#3b5bdb'):'transparent',
                          color:      i===0?'#fff':(form.sidebar_text||'rgba(255,255,255,.42)'),
                          opacity:    i===0?1:.5,
                          fontFamily: form.fuente||'DM Sans',
                        }}>
                        <span className="cfg-preview-icon"/>{n}
                      </div>
                    ))}
                  </div>
                </div>
              </CfgCard>
            </div>

            {/* Login: form + preview */}
            <div className="cfg-grid2 mb-2">
              <CfgCard ico="type" title="Personalización del Login">
                <p className="cfg-hint" style={{marginTop:0, marginBottom:16}}>
                  Personaliza la pantalla de inicio de sesión.
                </p>
                <div className="form-row">
                  <Field label="Título" half>
                    <input className="inp" value={form.login_titulo||''}
                      onChange={set('login_titulo')}
                      placeholder={form.nombre_empresa||'Mi Sistema'}/>
                  </Field>
                  <Field label="Subtítulo" half>
                    <input className="inp" value={form.login_subtitulo||''}
                      onChange={set('login_subtitulo')}
                      placeholder="Inicia sesión para continuar"/>
                  </Field>
                  <ColorRow half label="Color de Fondo" campo="login_color_fondo" value={form.login_color_fondo} onChange={handleColor}/>
                  <ColorRow half label="Color del Botón" campo="login_color_boton" value={form.login_color_boton} onChange={handleColor}/>
                  <Field label="Mostrar logo" half>
                    <select className="sel" value={form.login_mostrar_logo||'1'} onChange={set('login_mostrar_logo')}>
                      <option value="1">Sí, mostrar logo</option>
                      <option value="0">No mostrar</option>
                    </select>
                  </Field>
                  <Field label="Imagen de fondo (opcional)" half>
                    <input ref={loginBgRef} type="file" accept="image/*" className="hidden" onChange={subirLoginBg}/>
                    <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                      <button type="button" className="btn btn-ghost" onClick={()=>loginBgRef.current.click()}>
                        <Ic d={I.up} size={14}/>{form.login_imagen_fondo?'Cambiar imagen':'Subir imagen'}
                      </button>
                      {form.login_imagen_fondo && (
                        <button type="button" className="btn btn-danger" onClick={eliminarLoginBg}>Quitar</button>
                      )}
                    </div>
                    <p className="cfg-hint" style={{margin:'6px 0 0'}}>Si subes una imagen, reemplaza el color de fondo.</p>
                  </Field>
                </div>
              </CfgCard>

              <CfgCard ico="eye" title="Vista Previa del Login">
                <LoginPreview form={form} yo={yo}/>
              </CfgCard>
            </div>
          </>)}

          {/* ══ COTIZACIONES ══ */}
          {tab==='documentos'&&(<>
            <CfgCard ico="hash" title="Numeración de Cotizaciones">
              <div className="form-row">
                <Field label="Prefijo" half>
                  <input className="inp" value={form.cotizacion_prefijo||'COT'} onChange={set('cotizacion_prefijo')} placeholder="COT"/>
                </Field>
                <Field label="Resetear contador a" half>
                  <div className="input-row">
                    <input className="inp inp-flex" type="number" min="1"
                      value={resetN} onChange={e=>setResetN(e.target.value)}
                      placeholder="Ej: 100"/>
                    <button type="button" className="btn-reset" onClick={hacerReset}>
                      Aplicar
                    </button>
                  </div>
                </Field>
              </div>
            </CfgCard>

            <CfgCard ico="clipboard" title="Términos y Condiciones (Base)">
              <p style={{fontSize:12,color:'#666',marginBottom:15}}>
                Estos términos se muestran en todas las cotizaciones. Usa las notas específicas de cada cotización para agregar detalles particulares del proyecto.
              </p>
              
              <Field label="Obligaciones del Cliente">
                <QuillEditor
                  value={form.terminos_obligaciones||''}
                  onChange={v=>setForm(p=>({...p,terminos_obligaciones:v}))}
                />
              </Field>

              <Field label="Desarrollo">
                <QuillEditor
                  value={form.terminos_desarrollo||''}
                  onChange={v=>setForm(p=>({...p,terminos_desarrollo:v}))}
                />
              </Field>

              <Field label="Términos y Condiciones">
                <QuillEditor
                  value={form.terminos_condiciones||''}
                  onChange={v=>setForm(p=>({...p,terminos_condiciones:v}))}
                />
              </Field>
              <div className="cfg-utility-row">
                <button type="button" className="cfg-restore-btn" onClick={()=>restaurarTab('documentos')}>
                  Restaurar valores
                </button>
              </div>
            </CfgCard>
          </>)}

          {/* ══ PLANTILLAS DE TÉRMINOS ══ */}
          {tab==='plantillas'&&(<>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
              <h2 style={{margin:0,fontSize:18,fontWeight:700}}>📄 Plantillas de Términos</h2>
              <button 
                className="btn btn-primary" 
                onClick={()=>{setPlantillaEdit(null);setShowPlantillaModal(true)}}
              >
                + Nueva Plantilla
              </button>
            </div>
            
            <CfgCard ico="fileText" title="Listado de Plantillas">
              <p style={{fontSize:12,color:'#666',marginBottom:15}}>
                Crea plantillas de términos para diferentes tipos de proyectos (Ecommerce, Web Corporativa, etc.). 
                Al crear una cotización podrás seleccionar la plantilla y sus términos se cargarán automáticamente.
              </p>
              
              {loadingPlantillas ? (
                <div style={{textAlign:'center',padding:40,color:'#666'}}>Cargando plantillas...</div>
              ) : plantillas.length === 0 ? (
                <div style={{textAlign:'center',padding:40,color:'#666',background:'#f8fafc',borderRadius:8}}>
                  No hay plantillas creadas. Crea tu primera plantilla para empezar.
                </div>
              ) : (
                <div className="plantillas-list">
                  {plantillas.map(p=> (
                    <div key={p.id} className={`plantilla-item ${!p.activa ? 'plantilla-inactiva' : ''}`}>
                      <div className="plantilla-header">
                        <div>
                          <strong>{p.nombre}</strong>
                          {!p.activa && <span className="badge-inactiva">Inactiva</span>}
                          {p.descripcion && <p style={{margin:0,fontSize:12,color:'#666'}}>{p.descripcion}</p>}
                        </div>
                        <div className="plantilla-actions">
                          <button className="btn btn-ghost" onClick={()=>{setPlantillaEdit(p);setShowPlantillaModal(true)}}>
                            <Ic d={I.edit} size={14}/> Editar
                          </button>
                          {p.activa ? (
                            <button className="btn btn-danger" onClick={()=>desactivarPlantilla(p.id)}>
                              Desactivar
                            </button>
                          ) : (
                            <button className="btn btn-primary" onClick={()=>activarPlantilla(p.id)}>
                              Activar
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CfgCard>
          </>)}

          {/* ══ FINANZAS (NUEVO) ══ */}
          {tab==='finanzas'&&(
            <CfgCard ico="wallet" title="Configuración de Metas y SII">
              <div className="form-row">
                <Field label="Meta Mensual (Líquido)" half>
                  <InpCLP 
                    value={form.meta_mensual || 0} 
                    onChange={v => setForm({...form, meta_mensual: v})} 
                  />
                  <p className="field-hint">
                    Este valor se usa en la barra de progreso del Dashboard.
                  </p>
                </Field>
                
                <Field label="% Retención de Impuestos (SII)" half>
                  <NumberInput
                    className="inp"
                    step="0.01"
                    value={form.retencion_honorarios||''}
                    onChange={e=>setForm({...form,retencion_honorarios:e.target.value})}
                    placeholder="Ej: 13.75"
                  />
                  <p className="field-hint">Porcentaje actual para boletas de honorarios (ej: 13.75).</p>
                </Field>
              </div>
              <div className="cfg-utility-row">
                <button type="button" className="cfg-restore-btn" onClick={()=>restaurarTab('finanzas')}>
                  Restaurar valores
                </button>
              </div>
            </CfgCard>
          )}

          {/* ══ SISTEMA ══ */}
          {tab==='sistema'&&(<>
            <CfgCard ico="zap" title="Preferencias rápidas">
              <Field label="Autosave (guardar al editar)">
                <select className="sel" value={form.autosave||'0'} onChange={set('autosave')}>
                  <option value="0">Desactivado (guardar manual con Ctrl/Cmd+S)</option>
                  <option value="1">Activado (1.2s después de editar)</option>
                </select>
                <p className="cfg-hint" style={{margin:'6px 0 0'}}>Atajo: <kbd>Ctrl/Cmd+S</kbd> guarda inmediatamente.</p>
              </Field>
            </CfgCard>

            <CfgCard ico="disk" title="Importar / Exportar configuración">
              <p className="cfg-hint" style={{marginTop:0, marginBottom:16}}>
                Exporta la configuración actual a un archivo JSON para respaldar o clonar a otro entorno.
              </p>
              <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                <button type="button" className="btn btn-ghost" onClick={exportarConfig}>
                  <Ic d={I.download} size={14}/> Exportar configuración
                </button>
                <input ref={importRef} type="file" accept="application/json" className="hidden"
                  onChange={e => { importarConfig(e.target.files[0]); e.target.value='' }}/>
                <button type="button" className="btn btn-ghost" onClick={()=>importRef.current.click()}>
                  <Ic d={I.up} size={14}/> Importar configuración
                </button>
              </div>
            </CfgCard>

            <CfgCard ico="loader" title="Backups automáticos">
              <p className="cfg-hint" style={{marginTop:0, marginBottom:16}}>
                Programa respaldos periódicos. Requiere configurar un cron diario que ejecute
                <code style={{padding:'1px 6px',background:'var(--sel-bg)',borderRadius:4,marginLeft:4}}>backend/scripts/auto_backup.php</code>.
              </p>
              <div className="form-row">
                <Field label="Estado" half>
                  <select className="sel" value={form.backup_auto_enabled||'0'} onChange={set('backup_auto_enabled')}>
                    <option value="0">Desactivado</option>
                    <option value="1">Activado</option>
                  </select>
                </Field>
                <Field label="Frecuencia (días)" half>
                  <NumberInput className="inp" min="1" value={form.backup_auto_freq_days||'7'}
                    onChange={e=>setForm(p=>({...p,backup_auto_freq_days:e.target.value}))}/>
                </Field>
                <Field label="Retención (cuántos mantener)" half>
                  <NumberInput className="inp" min="1" value={form.backup_auto_retention||'5'}
                    onChange={e=>setForm(p=>({...p,backup_auto_retention:e.target.value}))}/>
                </Field>
                <Field label="Último auto-backup" half>
                  <input className="inp" value={form.last_auto_backup_at||'— nunca —'} disabled/>
                </Field>
              </div>
            </CfgCard>

            <CfgCard ico="fileText" title="Últimos cambios en Configuración">
              {loadingAudit ? (
                <div style={{ padding:14, fontSize:12, color:'var(--txt2)' }}>Cargando…</div>
              ) : auditConfig.length === 0 ? (
                <div style={{ padding:14, fontSize:12, color:'var(--txt2)', background:'var(--sel-bg)', borderRadius:8 }}>
                  Sin registros de cambios todavía.
                </div>
              ) : (
                <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                  {auditConfig.slice(0,10).map((a,i) => (
                    <div key={i} style={{ padding:'8px 12px', background: i%2===0?'var(--sel-bg)':'transparent',
                      borderRadius:6, fontSize:12, display:'flex', justifyContent:'space-between', gap:12 }}>
                      <div>
                        <strong>{a.usuario_nombre || a.usuario || 'Usuario'}</strong>
                        <span style={{ color:'var(--txt2)', marginLeft:8 }}>{a.detalle || a.accion}</span>
                      </div>
                      <span style={{ color:'var(--txt2)', whiteSpace:'nowrap' }}>{a.created_at}</span>
                    </div>
                  ))}
                </div>
              )}
            </CfgCard>

            <CfgCard ico="gear" title="Mantenimiento del Sistema">
              <div className="cfg-section" style={{display:'flex', flexDirection:'column', gap:20}}>
                {/* Nuevo sistema de backups */}
                <div>
                  <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12}}>
                    <div>
                      <p className="cfg-danger-title" style={{margin:0}}><Ic d={I.disk}/> Backups de base de datos</p>
                      <p className="cfg-danger-sub" style={{margin:'4px 0 0 0'}}>
                        Genera respaldos en el servidor y descarga cuando los necesites.
                      </p>
                    </div>
                    <button
                      onClick={generarBackup}
                      disabled={generandoBackup}
                      className="btn btn-primary"
                    >
                      {generandoBackup?<><Ic d={I.loader}/> Generando...</>:<><Ic d={I.plus}/> Generar backup</>}
                    </button>
                  </div>

                  {/* Lista de backups */}
                  {loadingBackups ? (
                    <div style={{textAlign:'center', padding:14, color:'var(--txt2)', fontSize:12}}>Cargando backups...</div>
                  ) : backups.length === 0 ? (
                    <div style={{textAlign:'center', padding:14, color:'var(--txt2)', fontSize:12, background:'var(--sel-bg)', borderRadius:8}}>
                      No hay backups generados. Crea tu primer backup.
                    </div>
                  ) : (
                    <div className="backups-list" style={{display:'flex', flexDirection:'column', gap:8}}>
                      {backups.map((b, i) => (
                        <div 
                          key={b.filename} 
                          style={{
                            display:'flex', 
                            justifyContent:'space-between', 
                            alignItems:'center',
                            padding:'12px 16px',
                            background: i % 2 === 0 ? '#f8fafc' : '#fff',
                            borderRadius: 8,
                            border: '1px solid #e8eaed'
                          }}
                        >
                          <div>
                            <strong style={{fontSize:13, fontWeight:600}}>{b.filename}</strong>
                            <div style={{fontSize:11, color:'#666', marginTop:2}}>
                              {b.created_at} • {b.size_formatted}
                            </div>
                          </div>
                          <div style={{display:'flex', gap:8}}>
                            <button 
                              className="btn btn-ghost" 
                              style={{padding:'6px 12px', fontSize:12}}
                              onClick={()=>descargarBackupArchivo(b.filename)}
                            >
                              ↓ Descargar
                            </button>
                            <button 
                              className="btn btn-danger" 
                              style={{padding:'6px 12px', fontSize:12}}
                              onClick={()=>eliminarBackupArchivo(b.filename)}
                            >
                              <Ic d={I.trash}/>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <hr style={{border:'none', borderTop:'1px solid #e8eaed', margin:'8px 0'}} />

                {/* Actualización del sistema (git pull + migraciones) */}
                <CfgCard ico="refresh" title="Actualizaciones del sistema">
                  <ActualizacionesPanel />
                </CfgCard>

                <hr style={{border:'none', borderTop:'1px solid #e8eaed', margin:'8px 0'}} />

                {/* Migraciones del esquema */}
                <CfgCard ico="refresh" title="Migraciones de base de datos">
                  <MigracionesPanel />
                </CfgCard>

                <hr style={{border:'none', borderTop:'1px solid #e8eaed', margin:'8px 0'}} />

                {/* Limpieza de BD */}
                <div className="cfg-danger">
                  <div>
                    <p className="cfg-danger-title">Limpieza de registros huérfanos</p>
                    <p className="cfg-danger-sub">
                      Elimina cuotas sin pagos y pagos sin proyectos. También limpia la papelera automáticamente.
                    </p>
                  </div>
                  <button
                    onClick={()=>{ setTypedConfirm(''); setConfirmAct('mantenimiento') }}
                    disabled={loadingAct}
                    className="btn-danger"
                  >
                    {loadingAct?<><Ic d={I.loader}/> Limpiando…</>:<><Ic d={I.trash}/> Limpiar BD</>}
                  </button>
                </div>
              </div>
            </CfgCard>
          </>)}

          {confirmAct==='backup'&&(
            <Confirm
              msg={'Se descargará un archivo .sql con toda la base de datos.\n\nGuárdalo en un lugar seguro. ¿Continuar?'}
              onSi={descargarBackup}
              onNo={()=>setConfirmAct(null)}
              okLabel="Descargar"
icon="💾"
              color="var(--acc3)"
            />
          )}

          {confirmAct==='mantenimiento'&&(
            <Modal title="Confirmar limpieza de BD" onClose={()=>setConfirmAct(null)}>
              <p style={{ fontSize:13, color:'var(--txt)', marginBottom:10 }}>
                Se eliminarán <strong>permanentemente</strong> cuotas sin pagos, pagos sin proyectos y la papelera automática. Esta acción no se puede deshacer.
              </p>
              <p style={{ fontSize:13, color:'var(--txt2)', marginBottom:14 }}>
                Para confirmar, escribe <strong style={{color:'var(--err)'}}>ELIMINAR</strong> a continuación:
              </p>
              <input className="inp" value={typedConfirm}
                onChange={e=>setTypedConfirm(e.target.value)}
                placeholder="ELIMINAR" autoFocus style={{ marginBottom:16 }}/>
              <div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
                <button className="btn btn-ghost" onClick={()=>setConfirmAct(null)}>Cancelar</button>
                <button className="btn btn-danger"
                  disabled={typedConfirm!=='ELIMINAR'}
                  onClick={ejecutarMantenimiento}>
                  <Ic d={I.trash} size={14}/> Limpiar BD
                </button>
              </div>
            </Modal>
          )}

          {backupEliminar && (
            <Confirm
              msg={`¿Eliminar el backup "${backupEliminar}"? Esta acción no se puede deshacer.`}
              onSi={confirmarEliminarBackup}
              onNo={()=>setBackupEliminar(null)}
              okLabel="Eliminar"
              ico="trash"
              color="var(--acc2)"
            />
          )}

          {/* Modal para Plantilla de Términos */}
          {showPlantillaModal && (
            <PlantillaModal
              plantilla={plantillaEdit}
              onClose={()=>{setShowPlantillaModal(false);setPlantillaEdit(null)}}
              onSave={guardarPlantilla}
              showToast={showT}
            />
          )}

          {/* Sticky save bar — solo aparece si hay cambios */}
          {tab!=='sistema' && hasUnsavedChanges && (
            <div className="cfg-sticky-bar">
              <span className="cfg-sticky-msg">
                <Ic d={I.warn} size={16}/> Tienes cambios sin guardar
              </span>
              <div className="cfg-sticky-actions">
                <button type="button" className="btn btn-ghost"
                  onClick={()=>setForm(originalForm)}>
                  Descartar
                </button>
                <button onClick={guardar} className="cfg-save" disabled={loadingAct}>
                  {loadingAct ? <><Ic d={I.loader}/> Guardando...</> : <><Ic d={I.disk}/> Guardar cambios</>}
                </button>
              </div>
            </div>
          )}
          {tab!=='sistema' && !hasUnsavedChanges && saved && (
            <div className="cfg-footer">
              <div className="cfg-footer-left">
                <span className="cfg-saved">✓ Guardado correctamente</span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  )
}