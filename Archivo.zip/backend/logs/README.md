# Logs

Los logs estructurados (JSON) se escriben en este directorio por el logger en `config.php`.

- Ruta configurable: `LOG_FILE` env var (default: `logs/app.log` relativo a backend/).
- Nivel: `LOG_LEVEL` env var (debug | info | warning | error | critical).
- Formato: 1 JSON por línea (timestamp ISO 8601, level, message, context, request_id).

## Logrotate (Linux producción)

Crear `/etc/logrotate.d/sistema`:

```
/var/www/sistema/backend/logs/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    copytruncate
}
```

`copytruncate` es importante porque PHP mantiene el file handle abierto via `error_log()`.

## macOS / dev

Se puede ignorar: los logs son pequeños y se rotan rara vez. Si crece mucho:

```
> backend/logs/app.log
```

o eliminar manualmente.
