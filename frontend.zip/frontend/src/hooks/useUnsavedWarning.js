import { useEffect, useId } from 'react'

// Map<id, dirty> — soporta múltiples forms simultáneos
const dirtyMap = new Map()

export function isFormDirty() {
  for (const v of dirtyMap.values()) if (v) return true
  return false
}

export function useUnsavedWarning(isDirty) {
  const id = useId()
  useEffect(() => {
    dirtyMap.set(id, isDirty)
    const handleBeforeUnload = (e) => {
      if (isFormDirty()) {
        e.preventDefault()
        e.returnValue = ''
      }
    }
    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => {
      dirtyMap.delete(id)
      window.removeEventListener('beforeunload', handleBeforeUnload)
    }
  }, [id, isDirty])
}
