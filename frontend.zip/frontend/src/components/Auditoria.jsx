import { useState, Fragment } from 'react'
import { useAuditoria, useBorrarAuditoria, useBorrarAuditoriaBulk, useVaciarAuditoria } from '../hooks/useQueryApi.js'
import { useBulkSelect } from '../hooks/useBulkSelect.js'
import { fecha, I } from '../assets/js/helpers.js'
import { Ic, Skeleton, Toast, useToast, Confirm, IBtn, Pagination, EmptyState } from './UI.jsx'

// ── Colores por acción ───────────────────────────────────────
const ACCION_CONFIG = {
  'CREATE':      { label: 'Crear',         color: '#2d9e6b', bg: '#e8f5ef', icon: I.plus     },
  'UPDATE':      { label: 'Editar',        color: '#1e88e5', bg: '#e3f2fd', icon: I.edit     },
  'DELETE':      { label: 'Eliminar',      color: '#e53935', bg: '#ffebee', icon: I.trash    },
  'SOFT_DELETE': { label: 'Papelera',      color: '#fb8c00', bg: '#fff3e0', icon: I.trash    },
  'HARD_DELETE': { label: 'Eliminado def.',color: '#c62828', bg: '#ffebee', icon: I.trash    },
  'LOGIN':       { label: 'Acceso',        color: '#6a1b9a', bg: '#f3e5f5', icon: I.out      },
  'LOGOUT':      { label: 'Salida',        color: '#e65100', bg: '#fff8e1', icon: I.out      },
  'RESTORE':     { label: 'Restaurar',     color: '#00897b', bg: '#e0f2f1', icon: I.download },
}

const getAccion = (a) => ACCION_CONFIG[a] || { label: a, color: '#888', bg: '#f5f5f5', icon: I.info }

const TABLAS = ['clientes', 'proyectos', 'cotizaciones', 'pagos', 'servicios', 'usuarios']

// ── Badge de acción ──────────────────────────────────────────
function AccionBadge({ accion }) {
  const cfg = getAccion(accion)
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 700,
      background: cfg.bg, color: cfg.color
    }}>
      <Ic d={cfg.icon} size={11} stroke={cfg.color} />
      {cfg.label}
    </span>
  )
}

// ── Tarjeta de estadística ───────────────────────────────────
function StatChip({ accion, total }) {
  const cfg = getAccion(accion)
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      background: 'var(--card)', border: '1px solid var(--card-b)',
      borderRadius: 12, padding: '10px 16px', minWidth: 120
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: 8,
        background: cfg.bg, display: 'flex', alignItems: 'center', justifyContent: 'center'
      }}>
        <Ic d={cfg.icon} size={15} stroke={cfg.color} />
      </div>
      <div>
        <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--txt)', lineHeight: 1 }}>{total}</div>
        <div style={{ fontSize: 11, color: 'var(--txt2)', marginTop: 2 }}>{cfg.label}</div>
      </div>
    </div>
  )
}

// ── Componente principal ─────────────────────────────────────
export default function Auditoria() {
  const hoy = () => new Date().toISOString().slice(0, 10)
  const hace30 = () => new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)

  const [desde, setDesde] = useState(hace30)
  const [hasta, setHasta] = useState(hoy)
  const [accion, setAccion] = useState('')
  const [tabla, setTabla] = useState('')
  const [busqueda, setBusqueda] = useState('')
  const [expandido, setExpandido] = useState(null)
  const [confirmDel, setConfirmDel] = useState(null) // { tipo: 'one'|'bulk'|'all', id?, count? }
  const [showFiltros, setShowFiltros] = useState(false)
  const [page, setPage] = useState(1)
  const [perPage, setPerPage] = useState(25)
  const [toast, showToast] = useToast()

  const filtros = {
    desde, hasta,
    ...(accion && { accion }),
    ...(tabla  && { tabla  }),
    page, per_page: perPage
  }

  const { data: respuesta, isLoading: loading, refetch } = useAuditoria(filtros)
  const borrarAuditoria = useBorrarAuditoria()
  const borrarBulk = useBorrarAuditoriaBulk()
  const vaciarAuditoria = useVaciarAuditoria()

  const registros = Array.isArray(respuesta?.registros) ? respuesta.registros : []
  const stats     = Array.isArray(respuesta?.stats) ? respuesta.stats : []
  const pagination = respuesta?.pagination

  const filtrados = registros.filter(r => {
    if (!busqueda) return true
    const q = busqueda.toLowerCase()
    return (
      (r.usuario_nombre || '').toLowerCase().includes(q) ||
      (r.tabla_afectada || '').toLowerCase().includes(q) ||
      (r.detalle        || '').toLowerCase().includes(q) ||
      (r.ip_address     || '').toLowerCase().includes(q)
    )
  })

  const formatFecha = (dt) => {
    if (!dt) return '—'
    const d = new Date(dt)
    return `${fecha(dt.slice(0, 10))} ${d.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })}`
  }

  const formatDetalle = (detalle) => {
    if (!detalle) return null
    try {
      const obj = typeof detalle === 'string' ? JSON.parse(detalle) : detalle
      return obj
    } catch { return detalle }
  }

  const {
    seleccionados,
    toggle: toggleSel,
    toggleAll: toggleSelAll,
    clear: clearSeleccion,
  } = useBulkSelect(filtrados)

  const ejecutarBorrar = () => {
    if (!confirmDel) return
    if (confirmDel.tipo === 'one') {
      borrarAuditoria.mutate(confirmDel.id, {
        onSuccess: () => {
          showToast('Registro eliminado', 'ok')
          toggleSel(confirmDel.id)
          setConfirmDel(null)
        },
        onError: (e) => { showToast(e.message || 'Error al eliminar', 'err'); setConfirmDel(null) }
      })
    } else if (confirmDel.tipo === 'bulk') {
      const ids = Array.from(seleccionados)
      borrarBulk.mutate(ids, {
        onSuccess: () => {
          showToast(`${ids.length} registros eliminados`, 'ok')
          clearSeleccion()
          setConfirmDel(null)
        },
        onError: (e) => { showToast(e.message || 'Error al eliminar', 'err'); setConfirmDel(null) }
      })
    } else if (confirmDel.tipo === 'all') {
      vaciarAuditoria.mutate(undefined, {
        onSuccess: (res) => {
          showToast(`Auditoría vaciada (${res?.deleted ?? 0} registros)`, 'ok')
          clearSeleccion()
          setPage(1)
          setConfirmDel(null)
        },
        onError: (e) => { showToast(e.message || 'Error al vaciar', 'err'); setConfirmDel(null) }
      })
    }
  }

  const totalPaginas = pagination?.total_pages || 1
  const totalRegistros = pagination?.total || 0
  const tieneFiltrosActivos = accion || tabla
  const isBorrando = borrarAuditoria.isPending || borrarBulk.isPending || vaciarAuditoria.isPending

  return (
    <div>
      {toast && <Toast {...toast} />}

      {/* ── Cabecera ── */}
      <div style={{ marginBottom: 16 }}>
        <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800, color: 'var(--txt)', fontFamily: 'var(--font)', display: 'flex', alignItems: 'center', gap: 8 }}>
          <Ic d={I.fileText} size={18} /> Auditoría del Sistema
        </h2>
        <p style={{ margin: '4px 0 0', fontSize: 13, color: 'var(--txt2)' }}>
          Registro de todas las acciones realizadas en el sistema. Solo visible para administradores.
        </p>
      </div>

      {/* ── Stats ── */}
      {!loading && stats.length > 0 && (
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 16 }}>
          {stats.map(s => <StatChip key={s.accion} accion={s.accion} total={s.total} />)}
        </div>
      )}
      {loading && (
        <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
          {[...Array(4)].map((_, i) => <Skeleton key={i} style={{ width: 130, height: 54, borderRadius: 12 }} />)}
        </div>
      )}

      {/* ── Panel principal (estilo unificado con otras pestañas) ── */}
      <div className="data-panel">
        {/* Cabecera con título, contador, buscador, botones */}
        <div className="data-panel__head">
          <div>
            <div className="data-panel__title">Registro de actividad</div>
            <div className="data-panel__count">
              {busqueda
                ? <>Mostrando <b>{filtrados.length}</b> de <b>{totalRegistros}</b> registros</>
                : <><b>{totalRegistros}</b> {totalRegistros === 1 ? 'registro' : 'registros'}</>
              }
              {seleccionados.size > 0 && <> · <b>{seleccionados.size}</b> seleccionado{seleccionados.size !== 1 ? 's' : ''}</>}
            </div>
          </div>
          <div className="data-panel__controls">
            <div className="data-panel__search">
              <Ic d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z" size={14} aria-hidden="true" />
              <input
                type="text"
                placeholder="Usuario, módulo, detalle, IP..."
                value={busqueda}
                onChange={e => setBusqueda(e.target.value)}
                aria-label="Buscar en auditoría"
              />
            </div>
            <button
              className={`btn btn-ghost${showFiltros || tieneFiltrosActivos ? ' is-active' : ''}`}
              onClick={() => setShowFiltros(s => !s)}
              aria-expanded={showFiltros}
              aria-label="Mostrar/ocultar filtros"
              style={tieneFiltrosActivos ? { borderColor: 'var(--accent)', color: 'var(--accent)' } : {}}
            >
              <Ic d={I.filter || 'M3 6h18M6 12h12M10 18h4'} size={13} />
              Filtros {tieneFiltrosActivos && <span style={{ background: 'var(--accent)', color: '#fff', borderRadius: 10, fontSize: 10, padding: '1px 6px', marginLeft: 2 }}>•</span>}
            </button>
            {seleccionados.size > 0 && (
              <button
                className="btn btn-danger"
                onClick={() => setConfirmDel({ tipo: 'bulk', count: seleccionados.size })}
                disabled={isBorrando}
                aria-label="Eliminar seleccionados"
              >
                <Ic d={I.trash} size={13} />
                Eliminar ({seleccionados.size})
              </button>
            )}
            <button
              className="btn btn-primary"
              onClick={() => refetch()}
              aria-label="Actualizar registros"
            >
              <Ic d={I.loader} size={13} stroke="#fff" />
              Actualizar
            </button>
            {totalRegistros > 0 && (
              <button
                className="btn btn-danger"
                onClick={() => setConfirmDel({ tipo: 'all', count: totalRegistros })}
                disabled={isBorrando}
                aria-label="Vaciar toda la auditoría"
              >
                <Ic d={I.trash} size={13} />
                Vaciar todo
              </button>
            )}
          </div>
        </div>

        {/* Filtros avanzados (colapsables) */}
        {showFiltros && (
          <div style={{
            padding: '14px 17px',
            borderBottom: '1px solid var(--card-b)',
            background: 'var(--bg)',
            display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end'
          }}>
            <div>
              <label className="field-lbl">Desde</label>
              <input className="inp" type="date" value={desde} onChange={e => { setDesde(e.target.value); setPage(1) }} style={{ width: 150 }} />
            </div>
            <div>
              <label className="field-lbl">Hasta</label>
              <input className="inp" type="date" value={hasta} onChange={e => { setHasta(e.target.value); setPage(1) }} style={{ width: 150 }} />
            </div>
            <div>
              <label className="field-lbl">Acción</label>
              <select className="sel" value={accion} onChange={e => { setAccion(e.target.value); setPage(1) }} style={{ width: 150 }}>
                <option value="">Todas</option>
                {Object.entries(ACCION_CONFIG).map(([k, v]) => (
                  <option key={k} value={k}>{v.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="field-lbl">Módulo</label>
              <select className="sel" value={tabla} onChange={e => { setTabla(e.target.value); setPage(1) }} style={{ width: 150 }}>
                <option value="">Todos</option>
                {TABLAS.map(t => <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
              </select>
            </div>
            {tieneFiltrosActivos && (
              <button
                className="btn btn-ghost"
                onClick={() => { setAccion(''); setTabla(''); setPage(1) }}
                style={{ height: 36 }}
              >
                <Ic d={I.x} size={12} /> Limpiar
              </button>
            )}
          </div>
        )}

        {/* ── Tabla ── */}
        {loading ? (
          <div style={{ padding: 16 }}>
            {[...Array(8)].map((_, i) => <Skeleton key={i} className="skeleton-row" />)}
          </div>
        ) : filtrados.length === 0 ? (
          <EmptyState
            title={busqueda ? 'Sin coincidencias' : 'Sin registros'}
            desc={busqueda ? `No hay registros que coincidan con "${busqueda}"` : 'No hay registros para los filtros seleccionados'}
          />
        ) : (
          <div className="tbl-wrap">
            <div className="tbl-scroll">
              <table className="tbl">
                <thead>
                  <tr>
                    <th style={{ width: 38 }}>
                      <input
                        type="checkbox"
                        checked={seleccionados.size === filtrados.length && filtrados.length > 0}
                        onChange={toggleSelAll}
                        aria-label="Seleccionar todos"
                      />
                    </th>
                    <th>Fecha y hora</th>
                    <th>Usuario</th>
                    <th>Acción</th>
                    <th>Módulo</th>
                    <th>Detalle</th>
                    <th>IP</th>
                    <th className="r" style={{ width: 60 }}>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {filtrados.map(r => {
                    const detalle = formatDetalle(r.detalle)
                    const isExpanded = expandido === r.id
                    const tieneDetalle = detalle && typeof detalle === 'object' && Object.keys(detalle).length > 0
                    const isSel = seleccionados.has(r.id)
                    return (
                      <Fragment key={r.id}>
                        <tr
                          style={{ background: isSel ? 'var(--sel-bg)' : undefined, cursor: tieneDetalle ? 'pointer' : 'default' }}
                          onClick={(e) => { if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'BUTTON' && tieneDetalle) setExpandido(isExpanded ? null : r.id) }}>
                          <td onClick={e => e.stopPropagation()}>
                            <input
                              type="checkbox"
                              checked={isSel}
                              onChange={() => toggleSel(r.id)}
                              aria-label={`Seleccionar registro ${r.id}`}
                            />
                          </td>
                          <td style={{ whiteSpace: 'nowrap', fontSize: 12, color: 'var(--txt2)' }}>
                            {formatFecha(r.created_at)}
                          </td>
                          <td>
                            <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--txt)' }}>{r.usuario_nombre || '—'}</div>
                            {r.usuario_email && <div style={{ fontSize: 11, color: 'var(--txt2)' }}>{r.usuario_email}</div>}
                          </td>
                          <td><AccionBadge accion={r.accion} /></td>
                          <td>
                            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--txt)', textTransform: 'capitalize' }}>
                              {r.tabla_afectada || '—'}
                            </span>
                            {r.registro_id && <span style={{ fontSize: 11, color: 'var(--txt2)', marginLeft: 4 }}>#{r.registro_id}</span>}
                          </td>
                          <td style={{ maxWidth: 280 }}>
                            {tieneDetalle ? (
                              <span style={{ fontSize: 12, color: 'var(--accent)', display: 'flex', alignItems: 'center', gap: 4 }}>
                                <Ic d={isExpanded ? I.warn : I.info} size={12} />
                                {isExpanded ? 'Ocultar detalle' : 'Ver detalle'}
                              </span>
                            ) : (
                              <span style={{ fontSize: 12, color: 'var(--txt2)' }}>{typeof detalle === 'string' ? detalle : '—'}</span>
                            )}
                          </td>
                          <td style={{ fontSize: 11, color: 'var(--txt2)', fontFamily: 'var(--mono)' }}>
                            {r.ip_address || '—'}
                          </td>
                          <td className="r" onClick={e => e.stopPropagation()}>
                            <div className="acts">
                              <IBtn
                                icon={I.trash}
                                variant="del"
                                onClick={() => setConfirmDel({ tipo: 'one', id: r.id })}
                                aria-label="Eliminar registro"
                              />
                            </div>
                          </td>
                        </tr>
                        {isExpanded && tieneDetalle && (
                          <tr>
                            <td colSpan={8} style={{ background: 'var(--sel-bg)', padding: '12px 16px' }}>
                              <div style={{ fontSize: 12, fontFamily: 'var(--mono)', color: 'var(--txt)', lineHeight: 1.8 }}>
                                {Object.entries(detalle).map(([k, v]) => (
                                  <div key={k} style={{ display: 'flex', gap: 8 }}>
                                    <span style={{ color: 'var(--txt2)', minWidth: 120 }}>{k}:</span>
                                    <span style={{ color: 'var(--txt)', wordBreak: 'break-all' }}>
                                      {v === null ? <em style={{ color: 'var(--txt2)' }}>null</em> : String(v)}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ── Paginación ── */}
        {!loading && pagination && (
          <Pagination
            pagination={{
              actual: pagination.page,
              totalPaginas: pagination.total_pages,
              total: pagination.total,
              perPage: pagination.per_page
            }}
            onPageChange={(p) => { setPage(p); clearSeleccion() }}
            onPrev={() => { setPage(p => Math.max(1, p - 1)); clearSeleccion() }}
            onNext={() => { setPage(p => Math.min(totalPaginas, p + 1)); clearSeleccion() }}
            onPerPageChange={(n) => { setPerPage(n); setPage(1); clearSeleccion() }}
          />
        )}
      </div>

      {/* ── Confirmación de borrado ── */}
      {confirmDel && (
        <Confirm
          msg={
            confirmDel.tipo === 'all'
              ? `⚠️ ¿Vaciar TODA la auditoría? Se eliminarán ${confirmDel.count} registros del historial completo. Esta acción no se puede deshacer.`
              : confirmDel.tipo === 'bulk'
                ? `¿Eliminar ${confirmDel.count} registros de auditoría? Esta acción no se puede deshacer.`
                : '¿Eliminar este registro de auditoría? Esta acción no se puede deshacer.'
          }
          okLabel={isBorrando
            ? (confirmDel.tipo === 'all' ? 'Vaciando…' : 'Eliminando…')
            : (confirmDel.tipo === 'all' ? 'Vaciar todo' : 'Eliminar')}
          onSi={ejecutarBorrar}
          onNo={() => setConfirmDel(null)}
          requireText={confirmDel.tipo === 'all' ? 'VACIAR AUDITORIA' : null}
        />
      )}
    </div>
  )
}
