import React, { useId } from 'react'

export function Field({ label, children, half, third, required, htmlFor, error }) {
  const cls = ['field', half?'field-half':'', third?'field-third':''].filter(Boolean).join(' ')
  const autoId = useId()
  const fieldId = htmlFor || autoId
  const errorId = `${fieldId}-error`

  // Si recibimos un hijo único (input/select/textarea) sin id, lo clonamos para
  // asociar id, aria-invalid y aria-describedby con el label/mensaje de error.
  let content = children
  if (React.isValidElement(children) && !Array.isArray(children)) {
    const extraProps = {}
    if (!children.props.id) extraProps.id = fieldId
    if (error) {
      extraProps['aria-invalid'] = true
      extraProps['aria-describedby'] = errorId
    }
    if (Object.keys(extraProps).length > 0) {
      content = React.cloneElement(children, extraProps)
    }
  }

  return (
    <div className={cls}>
      <label className="field-lbl" htmlFor={fieldId}>
        {label}{required && <span style={{ color:'var(--acc2)', marginLeft:2 }}>*</span>}
      </label>
      {content}
      {error && (
        <span id={errorId} className="field-error" role="alert" style={{ color:'var(--acc2)', fontSize:12, marginTop:4, display:'block' }}>
          {error}
        </span>
      )}
    </div>
  )
}
