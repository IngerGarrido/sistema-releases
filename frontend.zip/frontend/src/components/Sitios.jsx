import { useState, useEffect } from 'react'
import { useDebouncedValue } from '../hooks/useDebouncedValue.js'
import { useLocalState } from '../hooks/useLocalState.js'
import { useBulkSelect } from '../hooks/useBulkSelect.js'
import { api } from '../assets/js/api.js'
import { I } from '../assets/js/helpers.js'
import { Modal, Confirm, Toast, Field, BotonesGuardar, SelCliente, useToast, Skeleton, Acciones, IBtn, Ic, DataPanel } from './UI.jsx'
import {
  useSitios, useAccesos, useClientes,
  useCrearSitio, useEditarSitio, useBorrarSitio,
  useCrearAcceso, useEditarAcceso, useBorrarAcceso,
} from '../hooks/useQueryApi.js'

const TIPOS = [
  { v: 'wp',      l: 'WordPress' },
  { v: 'hosting', l: 'Hosting / cPanel' },
  { v: 'ftp',     l: 'FTP / SFTP' },
  { v: 'bd',      l: 'Base de datos' },
  { v: 'email',   l: 'Email' },
  { v: 'dominio', l: 'Dominio / DNS' },
  { v: 'panel',   l: 'Panel admin' },
  { v: 'otro',    l: 'Otro' },
]
const tipoLabel = (t) => TIPOS.find(x => x.v === t)?.l || t

// ─── Formulario de sitio (crear/editar) ───────────────────────
function SitioForm({ editando, clientes, onSave, onCancel, isPending }) {
  const [data, setData] = useState({
    cliente_id: editando?.cliente_id || '',
    nombre: editando?.nombre || '',
    descripcion: editando?.descripcion || '',
    url_principal: editando?.url_principal || '',
  })
  const upd = (k, v) => setData(d => ({ ...d, [k]: v }))
  return (
    <form onSubmit={(e)=>{ e.preventDefault(); onSave(data) }} style={{ padding: '4px' }}>
      <div className="form-row">
        <Field label="Cliente" required>
          <SelCliente clientes={clientes} value={data.cliente_id} onChange={v => upd('cliente_id', v)} />
        </Field>
        <Field label="Nombre del sitio" required>
          <input className="inp" value={data.nombre} onChange={e=>upd('nombre', e.target.value)} placeholder="Ej: Marchant, Sitio principal de ACME…" autoFocus />
          <small style={{ color: 'var(--txt2)' }}>Si la agencia es <em>PRGRSS</em> y el cliente final es <em>Marchant</em>, este sitio se llamaría "Marchant".</small>
        </Field>
        <Field label="URL principal" half>
          <input className="inp" value={data.url_principal} onChange={e=>upd('url_principal', e.target.value)} placeholder="https://ejemplo.com" />
        </Field>
        <Field label="Descripción" half>
          <input className="inp" value={data.descripcion} onChange={e=>upd('descripcion', e.target.value)} placeholder="Notas internas" />
        </Field>
      </div>
      <div style={{ marginTop: 20 }}>
        <BotonesGuardar onCancel={onCancel} isPending={isPending} />
      </div>
    </form>
  )
}

// ─── Formulario de acceso ─────────────────────────────────────
function AccesoForm({ editando, sitio_id, onSave, onCancel, isPending }) {
  const [data, setData] = useState({
    tipo: editando?.tipo || 'wp',
    etiqueta: editando?.etiqueta || '',
    url: editando?.url || '',
    usuario: editando?.usuario || '',
    password: '',
    notas: editando?.notas || '',
  })
  const [showPass, setShowPass] = useState(false)
  const [touchPass, setTouchPass] = useState(false)
  const upd = (k, v) => setData(d => ({ ...d, [k]: v }))

  const submit = (e) => {
    e.preventDefault()
    const payload = { ...data, sitio_id }
    if (editando && !touchPass) delete payload.password
    onSave(payload)
  }

  return (
    <form onSubmit={submit} style={{ padding: '4px' }}>
      <div className="form-row">
        <Field label="Tipo" half required>
          <select className="sel" value={data.tipo} onChange={e=>upd('tipo', e.target.value)}>
            {TIPOS.map(t => <option key={t.v} value={t.v}>{t.l}</option>)}
          </select>
        </Field>
        <Field label="Etiqueta" half required>
          <input className="inp" value={data.etiqueta} onChange={e=>upd('etiqueta', e.target.value)} placeholder="Ej: WP principal, FTP backup…" autoFocus />
        </Field>
        <Field label="URL">
          <input className="inp" value={data.url} onChange={e=>upd('url', e.target.value)} placeholder="https://ejemplo.com/wp-admin" />
        </Field>
        <Field label="Usuario" half>
          <input className="inp" value={data.usuario} onChange={e=>upd('usuario', e.target.value)} autoComplete="off" />
        </Field>
        <Field label={editando ? 'Contraseña (vacío = mantener)' : 'Contraseña'} half>
          <div style={{ display: 'flex', gap: 6 }}>
            <input
              className="inp"
              type={showPass ? 'text' : 'password'}
              value={data.password}
              onChange={e => { upd('password', e.target.value); setTouchPass(true) }}
              autoComplete="new-password"
              style={{ flex: 1 }}
            />
            <IBtn icon={I.eye} onClick={()=>setShowPass(s=>!s)} aria-label={showPass?'Ocultar':'Mostrar'} variant="view" />
          </div>
        </Field>
        <Field label="Notas">
          <textarea className="tex" rows={3} value={data.notas} onChange={e=>upd('notas', e.target.value)} placeholder="Cualquier detalle adicional" />
        </Field>
      </div>
      <div style={{ marginTop: 20 }}>
        <BotonesGuardar onCancel={onCancel} isPending={isPending} />
      </div>
    </form>
  )
}

// ─── Modal: gestionar accesos de UN sitio ─────────────────────
function AccesosModal({ sitio, onClose }) {
  const { data: lista = [], isLoading } = useAccesos(sitio.id)
  const [modal, setModal] = useState(null)
  const [del, setDel] = useState(null)
  const [reveal, setReveal] = useState({})
  const [toast, showToast] = useToast()

  const crearMut  = useCrearAcceso()
  const editarMut = useEditarAcceso()
  const borrarMut = useBorrarAcceso()

  const revelar = async (id) => {
    if (reveal[id]) { setReveal(r => { const c = { ...r }; delete c[id]; return c }) ; return }
    try {
      const r = await api.revelarAcceso(sitio.id, id)
      setReveal(prev => ({ ...prev, [id]: r.password || '' }))
    } catch (e) { showToast(e.message, 'err') }
  }

  const copy = async (text, msg = 'Copiado') => {
    try { await navigator.clipboard.writeText(text || ''); showToast(msg) }
    catch { showToast('No se pudo copiar', 'err') }
  }

  const guardar = async (payload) => {
    try {
      if (modal && modal !== 'new') await editarMut.mutateAsync({ id: modal.id, data: payload })
      else                            await crearMut.mutateAsync(payload)
      setModal(null); showToast('Acceso guardado')
    } catch (e) { showToast(e.message, 'err') }
  }

  return (
    <Modal title={`Accesos · ${sitio.nombre}`} onClose={onClose} wide>
      {toast && <Toast {...toast} />}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
        <small style={{ color: 'var(--txt2)' }}>
          Cliente: <strong>{sitio.cliente_display || sitio.cliente_nombre}</strong>
          {sitio.url_principal && <> · <a href={sitio.url_principal} target="_blank" rel="noreferrer">{sitio.url_principal}</a></>}
        </small>
        <button className="btn-pri" onClick={()=>setModal('new')}>
          <Ic d={I.plus} size={14}/> Nuevo acceso
        </button>
      </div>

      {isLoading && <Skeleton className="skeleton-row" />}

      {!isLoading && lista.length === 0 && (
        <div style={{ padding: 28, textAlign: 'center', color: 'var(--txt2)' }}>
          Aún no hay accesos guardados para este sitio.
        </div>
      )}

      {!isLoading && lista.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {lista.map(a => (
            <div key={a.id} className="card" style={{ padding: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                    <strong>{a.etiqueta}</strong>
                    <span className="badge" style={{ fontSize: 11 }}>{tipoLabel(a.tipo)}</span>
                  </div>
                  {a.url && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, marginTop: 4 }}>
                      <a href={a.url} target="_blank" rel="noreferrer">{a.url}</a>
                      <IBtn icon={I.copy} onClick={()=>copy(a.url, 'URL copiada')} aria-label="Copiar URL" />
                    </div>
                  )}
                  <div style={{ display: 'flex', gap: 16, marginTop: 6, fontSize: 13, flexWrap: 'wrap' }}>
                    {a.usuario && (
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                        <small style={{ color: 'var(--txt2)' }}>Usuario:</small> <code>{a.usuario}</code>
                        <IBtn icon={I.copy} onClick={()=>copy(a.usuario, 'Usuario copiado')} aria-label="Copiar usuario" />
                      </span>
                    )}
                    {a.tiene_password && (
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                        <small style={{ color: 'var(--txt2)' }}>Pass:</small>
                        <code>{reveal[a.id] ?? '••••••••'}</code>
                        <IBtn icon={I.eye} onClick={()=>revelar(a.id)} aria-label={reveal[a.id]?'Ocultar':'Mostrar'} variant="view" />
                        {reveal[a.id] && <IBtn icon={I.copy} onClick={()=>copy(reveal[a.id], 'Contraseña copiada')} aria-label="Copiar contraseña" />}
                      </span>
                    )}
                  </div>
                  {a.notas && <div style={{ marginTop: 6, fontSize: 12, color: 'var(--txt2)' }}>{a.notas}</div>}
                </div>
                <Acciones onEdit={()=>setModal(a)} onDel={()=>setDel(a.id)} />
              </div>
            </div>
          ))}
        </div>
      )}

      {modal && (
        <Modal title={modal === 'new' ? 'Nuevo acceso' : `Editar: ${modal.etiqueta}`} onClose={()=>setModal(null)}>
          <AccesoForm
            editando={modal === 'new' ? null : modal}
            sitio_id={sitio.id}
            onSave={guardar}
            onCancel={()=>setModal(null)}
            isPending={crearMut.isPending || editarMut.isPending}
          />
        </Modal>
      )}

      {del && (
        <Confirm
          msg="¿Eliminar este acceso? Esta acción no se puede deshacer."
          onSi={async ()=>{ try{ await borrarMut.mutateAsync(del); showToast('Eliminado') } catch(e){ showToast(e.message,'err') } ; setDel(null) }}
          onNo={()=>setDel(null)}
        />
      )}
    </Modal>
  )
}

// ─── Componente principal Sitios ──────────────────────────────
export default function Sitios() {
  const [pagina, setPagina] = useState(1)
  const [perPage, setPerPage] = useLocalState('sitios:perPage', 10)
  const [busqueda, setBusqueda] = useLocalState('sitios:q', '')
  const qDeb = useDebouncedValue(busqueda, 300)

  useEffect(() => { setPagina(1) }, [qDeb])

  const { data: respuesta, isLoading } = useSitios({ page: pagina, per_page: perPage, q: qDeb })
  const lista = Array.isArray(respuesta?.data) ? respuesta.data : []

  const { data: clientesResp } = useClientes({ per_page: 200 })
  const clientes = Array.isArray(clientesResp?.data) ? clientesResp.data : []

  const [modal, setModal] = useState(null)
  const [accesosSitio, setAccesosSitio] = useState(null)
  const [del, setDel] = useState(null)
  const [delMultiple, setDelMultiple] = useState(false)
  const [toast, showToast] = useToast()

  const crearMut  = useCrearSitio()
  const editarMut = useEditarSitio()
  const borrarMut = useBorrarSitio()

  const {
    seleccionados,
    toggle: toggleSeleccion,
    toggleAll: seleccionarTodos,
    clear: clearSeleccion,
  } = useBulkSelect(lista, qDeb)

  const eliminarSeleccionados = async () => {
    setDelMultiple(false)
    try {
      const total = seleccionados.size
      for (const id of Array.from(seleccionados)) {
        await borrarMut.mutateAsync(id)
      }
      showToast(`${total} sitio(s) enviados a papelera`)
      clearSeleccion()
    } catch (e) { showToast(e.message, 'err') }
  }

  const guardar = async (data) => {
    if (!data.cliente_id) { showToast('Selecciona un cliente', 'err'); return }
    if (!data.nombre?.trim()) { showToast('Nombre requerido', 'err'); return }
    try {
      if (modal && modal !== 'new') await editarMut.mutateAsync({ id: modal.id, data })
      else                            await crearMut.mutateAsync(data)
      setModal(null); showToast('Sitio guardado')
    } catch (e) { showToast(e.message, 'err') }
  }

  return (
    <div>
      {toast && <Toast {...toast} />}

      {isLoading && (
        <div className="card" style={{ padding: 16 }}>
          <Skeleton className="skeleton-title" />
          {[...Array(4)].map((_,i)=><Skeleton key={i} className="skeleton-row" />)}
        </div>
      )}

      {!isLoading && (
        <>
          {lista.length > 0 && (
            <div className="bulk-actions-bar">
              <label>
                <input type="checkbox"
                  checked={seleccionados.size === lista.length && lista.length > 0}
                  onChange={seleccionarTodos}
                  aria-label="Seleccionar todos" />
                <span>Todos</span>
              </label>
              {seleccionados.size > 0 && (
                <>
                  <span className="selection-count">| {seleccionados.size} seleccionados</span>
                  <button onClick={() => setDelMultiple(true)} className="btn-bulk-delete">
                    🗑️ Eliminar ({seleccionados.size})
                  </button>
                </>
              )}
            </div>
          )}

          <DataPanel
            title="Sitios"
            count={respuesta?.pagination?.total ?? lista.length}
            busqueda={busqueda} setBusqueda={setBusqueda}
            placeholder="Buscar sitio, cliente, URL…"
            onAdd={() => setModal('new')} addLabel="Nuevo sitio"
            pagination={{
              actual: pagina,
              totalPaginas: respuesta?.pagination?.total_pages || 1,
              total: respuesta?.pagination?.total || 0,
              perPage: respuesta?.pagination?.per_page || perPage,
              onChange: (n) => setPagina(n)
            }}
            onPerPageChange={n => { setPerPage(n); setPagina(1) }}
            cols={[
              { l: <input type="checkbox" checked={seleccionados.size === lista.length && lista.length > 0} onChange={seleccionarTodos} aria-label="Seleccionar todos los sitios" />, w: 40 },
              { l: 'Sitio' },
              { l: 'Cliente' },
              { l: 'URL' },
              { l: 'Proyectos', r: true },
              { l: 'Accesos', r: true },
              { l: 'Acciones', r: true },
            ]}
            rows={lista.map(s => [
              <input type="checkbox" checked={seleccionados.has(s.id)} onChange={() => toggleSeleccion(s.id)} aria-label={`Seleccionar sitio ${s.nombre}`} />,
              <div>
                <div style={{ fontWeight: 700 }}>{s.nombre}</div>
                {s.descripcion && <div className="tbl-muted" style={{ fontSize: 11 }}>{s.descripcion}</div>}
              </div>,
              <span>{s.cliente_display}</span>,
              s.url_principal ? <a href={s.url_principal} target="_blank" rel="noreferrer" style={{ fontSize: 12 }}>{s.url_principal}</a> : <span className="tbl-muted">—</span>,
              <strong>{s.proyectos_count}</strong>,
              <button className="btn-sec" onClick={()=>setAccesosSitio(s)} title="Ver/gestionar accesos" style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <Ic d={I.key} size={13}/>
                <span>{s.accesos_count}</span>
              </button>,
              <Acciones onEdit={()=>setModal(s)} onDel={()=>setDel(s.id)} />,
            ])}
            vacio="Aún no hay sitios. Crea uno para empezar a guardar accesos."
          />
        </>
      )}

      {modal && (
        <Modal title={modal === 'new' ? 'Nuevo sitio' : `Editar sitio: ${modal.nombre}`} onClose={()=>setModal(null)}>
          <SitioForm
            editando={modal === 'new' ? null : modal}
            clientes={clientes}
            onSave={guardar}
            onCancel={()=>setModal(null)}
            isPending={crearMut.isPending || editarMut.isPending}
          />
        </Modal>
      )}

      {accesosSitio && (
        <AccesosModal sitio={accesosSitio} onClose={()=>setAccesosSitio(null)} />
      )}

      {del && (
        <Confirm
          msg="¿Enviar este sitio a la papelera? Los proyectos que lo usan quedarán sin sitio asociado."
          onSi={async ()=>{ try{ await borrarMut.mutateAsync(del); showToast('Sitio enviado a papelera') } catch(e){ showToast(e.message,'err') } ; setDel(null) }}
          onNo={()=>setDel(null)}
        />
      )}

      {delMultiple && (
        <Confirm
          msg={`¿Enviar ${seleccionados.size} sitio(s) a la papelera?`}
          onSi={eliminarSeleccionados}
          onNo={() => setDelMultiple(false)}
        />
      )}
    </div>
  )
}
